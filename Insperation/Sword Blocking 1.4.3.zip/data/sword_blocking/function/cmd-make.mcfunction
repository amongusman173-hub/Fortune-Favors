cgen remove sword_blocking
cgen remove sword_blocking on
cgen remove sword_blocking off


cgen create sword_blocking sword_blocking:toggle
cgen create "sword_blocking on" sword_blocking:toggle
cgen create "sword_blocking off" sword_blocking:toggle