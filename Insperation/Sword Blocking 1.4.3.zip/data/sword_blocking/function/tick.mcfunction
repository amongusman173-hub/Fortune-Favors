function sword_blocking:blocking
execute as @a run scoreboard players enable @s sword_blocking