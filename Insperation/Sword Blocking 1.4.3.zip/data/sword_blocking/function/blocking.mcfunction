# Make swords block attacks
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:wooden_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:stone_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:golden_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:iron_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:diamond_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
execute as @a[scores={sword_blocking=0}] if data entity @s SelectedItem{id:"minecraft:netherite_sword"} run item modify entity @s weapon.mainhand sword_blocking:blocking
function sword_blocking:copper