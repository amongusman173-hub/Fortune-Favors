tellraw @a "Sword Blocking Reloaded"
scoreboard objectives add sword_blocking trigger
scoreboard objectives add sword_block dummy
scoreboard objectives add cmd-check dummy
function sword_blocking:cmd-check
execute if score CMD cmd-check matches 1 run function sword_blocking:cmd-make
