execute as @s if score @s sword_block >= 1 sword_block run scoreboard players set @s sword_block 0
execute as @s if score @s sword_block >= 1 sword_block run tellraw @s "Sword Blocking Disabled"
execute as @s if score @s sword_block = 0 sword_block run scoreboard players set @s sword_block 1
execute as @s if score @s sword_block = 0 sword_block run tellraw @s "Sword Blocking Enabled"