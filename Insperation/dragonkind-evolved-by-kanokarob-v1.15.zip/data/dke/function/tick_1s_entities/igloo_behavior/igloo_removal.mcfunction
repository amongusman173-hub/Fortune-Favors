# Generated with MC-Build

fill ~-5 ~-4 ~-5 ~5 ~9 ~5 air replace packed_ice
scoreboard players reset @s
playsound block.glass.break block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle snowflake ~ ~2 ~ 2 2 2 0.01 20 normal
particle block{block_state: "minecraft:packed_ice"} ~ ~2 ~ 2 2 2 0.05 30 normal
execute as @a[distance=..5.5] run damage @s 6.0 minecraft:freeze by @n[type=minecraft:ender_dragon,tag=dke.started]
kill @s