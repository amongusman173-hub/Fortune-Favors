# Generated with MC-Build

# Setup
execute unless entity @e[tag=dke.crystal,distance=..2] run summon marker ~ ~ ~ {Tags: [dke.crystal,dke.requires_dragon,dke.entity,dke.ticking,dke.entity.technical,smithed.entity,smithed.strict], CustomName: {"translate":"entity.minecraft.end_crystal"}}
# 10k Crystal Invulnerability
execute if entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/10k,distance=2..] run data modify entity @s Invulnerable set value 1b
execute unless entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/10k,distance=2..] run data modify entity @s Invulnerable set value 0b