# Generated with MC-Build

execute if entity @s[predicate=dke:dragon_lair] run data remove entity @s carriedBlockState
execute unless entity @e[type=minecraft:ender_dragon,distance=..128] run tag @s remove dke.entity