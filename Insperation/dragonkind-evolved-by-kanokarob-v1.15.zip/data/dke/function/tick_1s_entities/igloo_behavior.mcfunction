# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.time matches 15.. run function dke:tick_1s_entities/igloo_behavior/igloo_removal