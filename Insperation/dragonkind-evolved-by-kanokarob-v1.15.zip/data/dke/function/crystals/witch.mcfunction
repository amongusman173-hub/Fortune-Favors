# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle witch ~ ~1.5 ~ 1 1 1 0.05 1 force
execute if score @s dke.time matches 300.. if predicate dke:chance/01 as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=1,sort=random] at @s unless data entity @s active_effects run function dke:crystals/witch/effect
# Hat
execute on passengers if entity @s[tag=dke.hat.witch] rotated as @s run rotate @s ~3 0