# Generated with MC-Build

scoreboard players add @s dke.time 0
particle minecraft:electric_spark ~ ~1 ~ 1 1.5 1 0.05 10 force
# Charge
execute unless entity @s[tag=dke.charging] if score @s dke.time matches 300.. if predicate dke:chance/01 run function dke:crystals/item_drop/trigger
execute if entity @s[tag=dke.charging] at @a[predicate=dke:dragon_lair] run particle minecraft:electric_spark ~ ~1 ~ 0.3 0.5 0.3 0.05 5 normal
#Attack when ready
execute if entity @s[tag=dke.charging] if score @s dke.time matches 40.. if predicate dke:chance/05 run function dke:crystals/item_drop/activate
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
# Hat
execute on passengers if entity @s[tag=dke.hat.item_drop] rotated as @s run rotate @s ~-4 0