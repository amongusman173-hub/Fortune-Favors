# Generated with MC-Build

scoreboard players operation @s dke.edk = $$dke.global dke.edk
scoreboard players operation @s dke.difficulty = $$dke.global dke.difficulty
scoreboard players operation @s dke.ominous = $$dke.global dke.ominous
scoreboard players add @s dke.state 0
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
#Cursed crystal destroyed
execute if entity @s[tag=dke.cursed_aura] run function dke:crystals/curse_trigger
#Set max regenerations
execute if score @s dke.difficulty matches ..2 run scoreboard players set @s dke.count 1
execute if score @s dke.difficulty matches 3 run scoreboard players set @s dke.count 2
execute if score @s dke.difficulty matches 4.. run scoreboard players set @s dke.count 3
# Regenerate
execute if score @s dke.state <= @s dke.count if score @s dke.time matches 5..14 if predicate dke:chance/1 run function dke:crystals/regenerate
# End regenerate
execute if score @s dke.state <= @s dke.count if score @s dke.time matches 15.. run function dke:crystals/regenerate
#Become Cursed
execute if entity @e[predicate=dke:end_crystal/cursed,distance=..2] run tag @s add dke.cursed_aura