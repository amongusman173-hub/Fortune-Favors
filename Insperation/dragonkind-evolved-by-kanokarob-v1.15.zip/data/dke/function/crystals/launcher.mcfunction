# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
function dke:crystals/launcher/particles
#Charge
execute unless entity @s[tag=dke.charging] if score @s dke.time matches 100.. if predicate dke:chance/01 run function dke:crystals/launcher/trigger
#Fire when ready
execute if entity @s[tag=dke.charging] if score @s dke.time matches 19.. facing entity @a[predicate=dke:dragon_lair,predicate=dke:flying,distance=..40] feet if predicate dke:chance/05 positioned ^ ^ ^4 run function dke:crystals/launcher/fire
#Discharge after 30 seconds
execute if entity @s[tag=dke.charging] if score @s dke.time matches 300.. run function dke:crystals/launcher/failure
# Hat
execute unless entity @e[predicate=dke:flying,predicate=dke:dragon_lair] on passengers if entity @s[tag=dke.hat.launcher] facing entity @p[predicate=dke:dragon_lair] feet run rotate @s ~ ~
execute on passengers if entity @s[tag=dke.hat.launcher] facing entity @p[predicate=dke:flying,predicate=dke:dragon_lair] feet run rotate @s ~ ~