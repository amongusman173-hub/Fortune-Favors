# Generated with MC-Build

playsound entity.splash_potion.break hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1
playsound entity.evoker.cast_spell hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1
execute store result score @s dke.temp run random value 1..6
execute if score @s dke.temp matches 1 run effect give @s slowness 14 0 false
execute if score @s dke.temp matches 2 run effect give @s mining_fatigue 30 0 false
execute if score @s dke.temp matches 3 run effect give @s nausea 10 0 false
execute if score @s dke.temp matches 4 run effect give @s invisibility 14 0 false
execute if score @s dke.temp matches 5 run effect give @s blindness 5 0 false
execute if score @s dke.temp matches 6 run effect give @s poison 14 0 false
scoreboard players reset @s dke.temp