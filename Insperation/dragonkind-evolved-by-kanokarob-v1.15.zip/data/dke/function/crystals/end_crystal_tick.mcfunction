# Generated with MC-Build

# Projectile Immunity
execute if predicate dke:end_crystal/forcefield run function dke:crystals/forcefield
# Fiery
execute if predicate dke:end_crystal/fiery run function dke:crystals/fiery
# Laser
execute if predicate dke:end_crystal/laser run function dke:crystals/laser
# Item Drop
execute if predicate dke:end_crystal/item_drop run function dke:crystals/item_drop
# Witch
execute if predicate dke:end_crystal/witch run function dke:crystals/witch
# Anti-grav
execute if predicate dke:end_crystal/antigrav run function dke:crystals/antigrav
# Launcher
execute if predicate dke:end_crystal/launcher run function dke:crystals/launcher
# Portal
execute if predicate dke:end_crystal/portal run function dke:crystals/portal
# 10k
execute if predicate dke:end_crystal/10k run function dke:crystals/10k