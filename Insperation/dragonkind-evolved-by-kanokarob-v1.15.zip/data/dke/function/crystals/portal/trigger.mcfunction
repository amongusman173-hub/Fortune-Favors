# Generated with MC-Build

scoreboard players reset @s dke.time
execute as @a[predicate=dke:dragon_lair,limit=3,sort=random,gamemode=!creative,gamemode=!spectator] at @e[tag=dke.crystal,limit=1,sort=random,distance=6..] facing 0 ~ 0 run function dke:crystals/portal/trigger/teleport