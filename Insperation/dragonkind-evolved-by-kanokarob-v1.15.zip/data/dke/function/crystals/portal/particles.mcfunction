# Generated with MC-Build

execute rotated ~0 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~15 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~30 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~45 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~60 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~75 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~90 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~105 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~120 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~135 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~150 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~165 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~180 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~195 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~210 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~225 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~240 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~255 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~270 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~285 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~300 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~315 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~330 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~345 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force
execute rotated ~360 0 positioned ^ ^ ^0.5 run particle portal ~ ~ ~ ^ ^ ^1000000000 0.000000005 0 force