# Generated with MC-Build

particle portal ~ ~1 ~ 0.3 0.5 0.3 0.05 20 force
playsound entity.enderman.teleport block @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1
tp ^ ^1 ^2.5
execute at @s run particle portal ~ ~1 ~ 0.3 0.5 0.3 0.05 20 force
execute at @s run playsound entity.enderman.teleport block @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1