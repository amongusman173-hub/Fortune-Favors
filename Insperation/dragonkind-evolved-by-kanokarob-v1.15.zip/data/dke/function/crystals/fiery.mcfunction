# Generated with MC-Build

execute if predicate dke:chance/50 run particle flame ~ ~1.5 ~ 1.25 1 1.25 0.05 5 force
execute if predicate dke:chance/20 run particle lava ~ ~1.5 ~ 0.5 1 0.5 0.01 2 normal
damage @a[distance=..3.5,limit=1,sort=nearest] 3.0 minecraft:in_fire by @s
# Hat
execute on passengers if entity @s[tag=dke.hat.fiery] rotated as @s run rotate @s ~3 0