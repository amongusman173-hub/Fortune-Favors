# Generated with MC-Build

particle dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~1.5 ~ 1 1 1 0.05 5 force
particle end_rod ~ ~1.5 ~ 1 1 1 0.05 2 force
# Hat
execute on passengers if entity @s[tag=dke.hat.10k] rotated as @s run rotate @s ~-2 0