# Generated with MC-Build

execute if score @s dke.time matches 1 run playsound entity.guardian.attack block @a[predicate=dke:dragon_lair] ~ ~ ~ 5 1 1
#Aiming raycast
execute if score @s dke.time matches 1..59 positioned ~ ~2.5 ~ run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_aim
#Firing raycast
execute if score @s dke.time matches 60 positioned ~ ~2.5 ~ facing entity @p[gamemode=!creative,gamemode=!spectator,predicate=dke:dragon_lair,predicate=dke:on_ground] feet run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_fire
execute if score @s dke.time matches 61.. run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_reset