# Generated with MC-Build

particle dust{color:[1,0,0],scale:0.5} ^ ^ ^ 0 0 0 0 1 normal
execute if entity @a[distance=..3] run return 0
execute if block ^ ^ ^ #dke:laser_barrier run return 0
execute if entity @s[distance=75..] run return 0
execute unless entity @s[distance=75..] facing entity @p[gamemode=!creative,gamemode=!spectator,predicate=dke:dragon_lair,predicate=dke:on_ground] feet positioned ^ ^ ^0.99 unless block ^ ^ ^ #dke:laser_barrier run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_aim