# Generated with MC-Build

tag @s remove dke.firing
tag @s remove dke.charging
scoreboard players reset @s dke.time