# Generated with MC-Build

tag @s add dke.firing
particle dust{color:[1,0,0],scale:0.5} ^ ^ ^ 0.2 0.2 0.2 0 5 normal
particle end_rod ^ ^ ^ 0.1 0.1 0.1 0.01 2 normal
execute if entity @a[distance=..1.5] run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_fire/end_crystal_laser_hit
execute if entity @s[distance=150..] run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_fire/end_crystal_laser_hit
execute if block ^ ^ ^ #dke:laser_barrier run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_fire/end_crystal_laser_hit
execute unless entity @s[distance=150..] positioned ^ ^ ^0.99 run function dke:crystals/laser/end_crystal_laser_charging/end_crystal_laser_fire