# Generated with MC-Build

particle explosion ^ ^ ^ 0.5 0.5 0.5 0 20 normal
playsound entity.generic.explode block @a[predicate=dke:dragon_lair] ^ ^ ^ 2 1.2
execute as @a[distance=..4,predicate=dke:on_ground] run damage @s 5.0 minecraft:mob_projectile by @n[tag=dke.firing]
tag @s remove dke.firing
tag @s remove dke.charging
scoreboard players reset @s dke.time