# Generated with MC-Build

tag @s add dke.charging
scoreboard players reset @s dke.time
execute as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run playsound block.end_portal_frame.fill block @s ~ ~ ~ 1 1.6