# Generated with MC-Build

tag @s remove dke.cursed_aura
execute at @p[predicate=dke:dragon_lair] run playsound entity.elder_guardian.curse hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 0.75
damage @p[predicate=dke:dragon_lair] 15.0 minecraft:indirect_magic by @s