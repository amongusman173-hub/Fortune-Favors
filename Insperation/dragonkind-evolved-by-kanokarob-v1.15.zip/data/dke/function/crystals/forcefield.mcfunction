# Generated with MC-Build

execute positioned ~ ~0.5 ~ run function dke:crystals/forcefield/arrow_particles
execute positioned ~ ~2.5 ~ run function dke:crystals/forcefield/arrow_particles
#Repel projectiles
execute positioned ~ ~1 ~ as @e[type=#dke:projectile,distance=..5.5,tag=!dke.trident.bounced] at @s run function dke:crystals/forcefield/end_crystal_arrow_repel
execute positioned ~ ~1 ~ as @e[type=minecraft:trident,distance=..3.5,tag=dke.trident.bounced] at @s run tp @s ^ ^ ^1 ~180 ~