# Generated with MC-Build

#Update scores
scoreboard players reset @s dke.time
scoreboard players add @s dke.state 1
execute if score @s dke.difficulty matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.state 1
#Summon new End Crystal
summon end_crystal ~ ~ ~ {ShowBottom: 1b, Tags: [dke.end_crystal,dke.entity,dke.ticking,smithed.entity,smithed.strict]}
# Determine random effects
execute as @n[type=minecraft:end_crystal,tag=dke.end_crystal,distance=..2] run function dke:crystals/regenerate/set_type
# Inform players
execute as @a[predicate=dke:dragon_lair] at @s run function dke:crystals/regenerate/end_crystal_effects
particle explosion ~ ~1.5 ~ 3 3 3 0 50 normal
particle dragon_breath ~ ~1.5 ~ 3 3 3 0.05 50 normal