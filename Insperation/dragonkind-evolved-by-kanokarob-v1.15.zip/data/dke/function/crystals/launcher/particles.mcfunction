# Generated with MC-Build

execute rotated ~0 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~30 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~60 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~90 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~120 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~150 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~180 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~210 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~240 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~270 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~300 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~330 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
execute rotated ~360 -75 run particle glow_squid_ink ^ ^-3.75 ^ ^ ^ ^1000000000 0.0000000005 0 force
#execute rotated ~ 0 positioned ^ ^ ^0.25 run particle smoke ~ ~0.75 ~ ^ ^ ^100000000 0.000000004 0 force