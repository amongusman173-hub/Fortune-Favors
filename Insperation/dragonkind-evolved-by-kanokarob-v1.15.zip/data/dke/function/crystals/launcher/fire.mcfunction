# Generated with MC-Build

playsound entity.drowned.shoot block @a[predicate=dke:dragon_lair,predicate=dke:flying] ~ ~ ~ 3 1 1
summon item_display ~ ~ ~ {Tags:[dke.projectile,dke.projectile.eye,dke.entity,dke.ticking,dke.requires_dragon,smithed.entity,smithed.strict],Glowing:1b,item:{id:"minecraft:ender_eye",count:1},brightness:{block:15,sky:15},glow_color_override:50287,teleport_duration:1,billboard:"fixed",transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[2f,2f,2f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~ ~ ~ as @n[tag=dke.projectile.eye] run tp @s ~ ~ ~ ~ ~