# Generated with MC-Build

execute on passengers if entity @s[tag=dke.hat.launcher] run data modify entity @s Glowing set value 0b
tag @s remove dke.charging
scoreboard players reset @s dke.time
execute as @a[predicate=dke:dragon_lair] at @s run playsound item.crossbow.loading_end block @s ~ ~ ~ 3 0.8 1