# Generated with MC-Build

tag @s add dke.charging
scoreboard players reset @s dke.time
execute on passengers if entity @s[tag=dke.hat.launcher] run data modify entity @s Glowing set value 1b
execute as @a[predicate=dke:dragon_lair] at @s run playsound item.crossbow.loading_middle block @s ~ ~ ~ 3 0.8 1