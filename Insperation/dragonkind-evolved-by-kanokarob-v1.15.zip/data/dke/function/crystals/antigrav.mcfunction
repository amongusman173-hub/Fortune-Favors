# Generated with MC-Build

particle cloud ~ ~-8 ~ 2 5 2 0.05 5 force
execute positioned ~-4 0 ~-4 run effect give @a[dx=9,dy=128,dz=9,gamemode=!creative,gamemode=!spectator] levitation 2 2 true