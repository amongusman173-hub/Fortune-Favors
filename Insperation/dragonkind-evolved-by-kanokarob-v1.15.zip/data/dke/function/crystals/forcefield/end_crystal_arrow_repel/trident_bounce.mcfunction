# Generated with MC-Build

tag @s add dke.trident.bounced
#Get current motion
execute store result score @s dke.x run data get entity @s Motion[0] 100
execute store result score @s dke.y run data get entity @s Motion[1] 100
execute store result score @s dke.z run data get entity @s Motion[2] 100
#Invert motion
scoreboard players set @s dke.temp -1
scoreboard players operation @s dke.x *= @s dke.temp
scoreboard players operation @s dke.y *= @s dke.temp
scoreboard players operation @s dke.z *= @s dke.temp
#Reapply motion
execute store result entity @s Motion[0] double 0.001 run scoreboard players get @s dke.x
execute store result entity @s Motion[1] double 0.001 run scoreboard players get @s dke.y
execute store result entity @s Motion[2] double 0.001 run scoreboard players get @s dke.z