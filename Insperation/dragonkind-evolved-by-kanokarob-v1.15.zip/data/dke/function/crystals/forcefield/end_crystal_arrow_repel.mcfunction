# Generated with MC-Build

particle poof ~ ~ ~ 0 0 0 0.05 5 force
playsound item.trident.hit_ground block @a[predicate=dke:dragon_lair] ~ ~ ~ 3 1
kill @s[type=!trident]
execute as @e[type=minecraft:trident] at @s run function dke:crystals/forcefield/end_crystal_arrow_repel/trident_bounce