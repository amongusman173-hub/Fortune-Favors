# Generated with MC-Build

execute rotated ~0 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~15 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~30 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~45 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~60 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~75 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~90 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~105 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~120 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~135 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~150 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~165 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~180 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~195 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~210 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~225 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~240 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~255 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~270 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~285 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~300 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~315 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~330 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~345 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force
execute rotated ~360 ~ run particle enchant ^ ^ ^3.5 0.1 0.1 0.1 0.01 1 force