# Generated with MC-Build

tag @s add dke.charging
scoreboard players reset @s dke.time
execute as @a[predicate=dke:dragon_lair] at @s run playsound minecraft:entity.bee.death hostile @s ~ ~ ~ 1 1 1