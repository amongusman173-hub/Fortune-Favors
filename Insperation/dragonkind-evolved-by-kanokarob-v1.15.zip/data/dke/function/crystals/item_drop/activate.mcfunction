# Generated with MC-Build

# Drop held items
execute as @r[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:crystals/item_drop/activate/effect
scoreboard players reset @s dke.time
tag @s remove dke.charging