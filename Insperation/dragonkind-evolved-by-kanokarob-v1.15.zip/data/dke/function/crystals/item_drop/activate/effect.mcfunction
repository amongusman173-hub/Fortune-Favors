# Generated with MC-Build

summon minecraft:item ~ ~ ~ {Tags:[dke.entity,dke.item,dke.item.mainhand,smithed.entity,smithed.strict],Invulnerable:1b,PickupDelay:40s,Item:{id:"minecraft:stone",count:1}}
summon minecraft:item ~ ~ ~ {Tags:[dke.entity,dke.item,dke.item.offhand,smithed.entity,smithed.strict],Invulnerable:1b,PickupDelay:40s,Item:{id:"minecraft:stone",count:1}}
item replace entity @n[tag=dke.item.mainhand,distance=..1] contents from entity @s weapon.mainhand
item replace entity @n[tag=dke.item.offhand,distance=..1] contents from entity @s weapon.offhand
item replace entity @s weapon.mainhand with air 1
item replace entity @s weapon.offhand with air 1
playsound minecraft:entity.bee.sting hostile @a[distance=..16] ~ ~ ~ 1 1
playsound minecraft:entity.bee.death hostile @a[distance=..16] ~ ~ ~ 1 0.6
particle minecraft:enchanted_hit ~ ~1 ~ 0.3 0.5 0.3 0.05 10 normal