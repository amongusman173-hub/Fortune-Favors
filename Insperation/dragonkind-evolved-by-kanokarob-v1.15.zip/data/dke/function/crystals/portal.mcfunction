# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
execute positioned ~ ~0.5 ~ run function dke:crystals/portal/particles
#Teleport 3 random players to a different tower
execute if score @s dke.time matches 200.. if predicate dke:chance/003 run function dke:crystals/portal/trigger