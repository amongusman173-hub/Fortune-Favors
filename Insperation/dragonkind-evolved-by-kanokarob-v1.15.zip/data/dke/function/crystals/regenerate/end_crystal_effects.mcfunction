# Generated with MC-Build

playsound block.enchantment_table.use hostile @s ~ ~ ~ 1 0.7
playsound entity.generic.explode hostile @s ~ ~ ~ 0.65 1.2
tellraw @s ["",{"translate":"message.dke.end_crystal.regenerate","color":"light_purple"}]
execute if entity @e[predicate=dke:dragon_lair,predicate=dke:end_crystal/10k,tag=!dke.informed] run tellraw @a ["",{"translate":"message.dke.end_crystal.10k","color":"#f7da63"}]
tag @n[predicate=dke:dragon_lair,predicate=dke:end_crystal/10k,tag=!dke.informed] add dke.informed