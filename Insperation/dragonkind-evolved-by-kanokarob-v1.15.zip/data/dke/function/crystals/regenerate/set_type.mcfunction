# Generated with MC-Build

scoreboard players operation @s dke.type = $$dke.global dke.type
scoreboard players operation @s dke.edk = $$dke.global dke.edk
scoreboard players operation @s dke.difficulty = $$dke.global dke.difficulty
tag @s add dke.entity
tag @s add dke.end_crystal
tag @s add smithed.entity
tag @s add smithed.strict
scoreboard players reset @s dke.ability_1
scoreboard players reset @s dke.ability_2
scoreboard players reset @s dke.ability_3
#Roll abilities
execute if score @s dke.difficulty matches ..1 if predicate dke:chance/50 store result score @s dke.ability_1 run random value 1..4
execute if score @s dke.difficulty matches ..1 if predicate dke:chance/50 store result score @s dke.ability_2 run random value 2..3
execute if score @s dke.difficulty matches 2..4 if predicate dke:chance/50 store result score @s dke.ability_1 run random value 1..5
execute if score @s dke.difficulty matches 2..4 if predicate dke:chance/50 store result score @s dke.ability_2 run random value 2..7
execute if score @s dke.difficulty matches 3..4 store result score @s dke.ability_3 run random value 2..8
execute if score @s dke.difficulty matches 5 if predicate dke:chance/50 store result score @s dke.ability_1 run random value 1..7
execute if score @s dke.difficulty matches 5 store result score @s dke.ability_2 run random value 2..8
execute if score @s dke.difficulty matches 5 store result score @s dke.ability_3 run random value 2..10
execute if score @s dke.difficulty matches 6.. store result score @s dke.ability_1 run random value 1..7
execute if score @s dke.difficulty matches 6.. store result score @s dke.ability_2 run random value 2..8
execute if score @s dke.difficulty matches 6.. store result score @s dke.ability_3 run random value 5..10
#10k crystal chance
execute if score @s dke.type matches 101 if predicate dke:chance/20 unless entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/10k] run function dke:crystals/regenerate/set_type/10k_chance
#Ensure certain crystals are unique at any given time
execute if entity @s[predicate=dke:end_crystal/portal] if entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/portal,distance=2..] run function dke:crystals/regenerate/set_type/unique_portal
execute if entity @s[predicate=dke:end_crystal/cursed] if entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/cursed,distance=2..] run function dke:crystals/regenerate/set_type/unique_cursed
execute if entity @s[predicate=dke:end_crystal/item_drop] if entity @e[type=minecraft:end_crystal,predicate=dke:end_crystal/item_drop,distance=2..] run function dke:crystals/regenerate/set_type/unique_item_drop
#Prevent overlap
execute if score @s dke.ability_1 matches 1 if score @s dke.ability_1 = @s dke.ability_2 run scoreboard players add @s dke.ability_2 1
execute if score @s dke.ability_1 matches 1 if score @s dke.ability_1 = @s dke.ability_3 run scoreboard players add @s dke.ability_3 2
execute if score @s dke.ability_1 matches 2.. if score @s dke.ability_1 = @s dke.ability_2 run scoreboard players remove @s dke.ability_2 1
execute if score @s dke.ability_1 matches 2.. if score @s dke.ability_1 = @s dke.ability_3 run scoreboard players remove @s dke.ability_3 1
execute if score @s dke.ability_2 matches ..6 if score @s dke.ability_2 = @s dke.ability_3 run scoreboard players add @s dke.ability_3 1
execute if score @s dke.ability_2 matches 7.. if score @s dke.ability_2 = @s dke.ability_3 run scoreboard players remove @s dke.ability_3 1
#Apply Cosmetics
# Caged
execute if predicate dke:end_crystal/caged run place template dke:cage ~-3 ~-2 ~-3 none
# Forcefield
execute if predicate dke:end_crystal/forcefield run function dke:crystals/regenerate/set_type/summon_hat_forcefield
# Fiery
execute if predicate dke:end_crystal/fiery run function dke:crystals/regenerate/set_type/summon_hat_fiery
# Item Drop
execute if predicate dke:end_crystal/item_drop run function dke:crystals/regenerate/set_type/summon_hat_item_drop
# Witch
execute if predicate dke:end_crystal/witch run function dke:crystals/regenerate/set_type/summon_hat_witch
# Launcher
execute if predicate dke:end_crystal/launcher run function dke:crystals/regenerate/set_type/summon_hat_launcher
# Portal
execute if predicate dke:end_crystal/portal run function dke:crystals/regenerate/set_type/summon_hat_portal
# 10,000
execute if predicate dke:end_crystal/10k run function dke:crystals/regenerate/set_type/summon_hat_10k