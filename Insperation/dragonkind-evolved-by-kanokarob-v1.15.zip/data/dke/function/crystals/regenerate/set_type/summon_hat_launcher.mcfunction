# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.launcher,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:launcher_eye"}},transformation:{scale:[3.25f,3.25f,3.25f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,2.5f,1.0f]},billboard:"fixed",teleport_duration:1,brightness:{block:15,sky:15},glow_color_override:50287}
ride @n[type=minecraft:item_display,tag=dke.hat.launcher,distance=..1] mount @s