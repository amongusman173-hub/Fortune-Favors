# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.fiery,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:blaze_rods"}},transformation:{scale:[3.5f,3.5f,3.5f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,-1.0f,0.0f]},billboard:"fixed",teleport_duration:1,brightness:{block:15,sky:15},Glowing:1b,glow_color_override:15964425}
ride @n[type=minecraft:item_display,tag=dke.hat.fiery,distance=..1] mount @s