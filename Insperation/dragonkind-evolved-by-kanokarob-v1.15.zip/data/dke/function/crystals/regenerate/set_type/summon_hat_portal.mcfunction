# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.portal,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:portal"}},transformation:{scale:[4.0f,4.0f,4.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,-2.0f,-2.75f]},billboard:"center",teleport_duration:1,brightness:{block:15,sky:15},Glowing:1b,glow_color_override:11078131}
ride @n[type=minecraft:item_display,tag=dke.hat.portal,distance=..1] mount @s