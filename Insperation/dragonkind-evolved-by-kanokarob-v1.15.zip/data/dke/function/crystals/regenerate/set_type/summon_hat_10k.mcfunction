# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.10k,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:crown"}},transformation:{scale:[5.0f,5.0f,5.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,1.5f,0.0f]},billboard:"fixed",teleport_duration:1,brightness:{block:15,sky:15},Glowing:1b,glow_color_override:16764928}
ride @n[type=minecraft:item_display,tag=dke.hat.10k,distance=..1] mount @s