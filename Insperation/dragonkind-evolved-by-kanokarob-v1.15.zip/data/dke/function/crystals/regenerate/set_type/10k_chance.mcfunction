# Generated with MC-Build

execute store result score @s dke.random run random value 1..3
execute if score @s dke.random matches 1 run scoreboard players set @s dke.ability_1 101
execute if score @s dke.random matches 2 run scoreboard players set @s dke.ability_2 101
execute if score @s dke.random matches 3 run scoreboard players set @s dke.ability_3 101
scoreboard players reset @s dke.random