# Generated with MC-Build

execute if score @s dke.ability_1 matches 10 store result score @s dke.ability_1 run random value 1..9
execute if score @s dke.ability_2 matches 10 store result score @s dke.ability_2 run random value 1..9
execute if score @s dke.ability_3 matches 10 store result score @s dke.ability_3 run random value 1..9