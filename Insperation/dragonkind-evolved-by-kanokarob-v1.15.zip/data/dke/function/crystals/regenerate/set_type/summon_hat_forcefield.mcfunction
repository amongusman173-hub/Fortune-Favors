# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.forcefield,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:forcefield"}},transformation:{scale:[7.0f,7.0f,7.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,-0.75f,0.0f]},billboard:"center",teleport_duration:1,brightness:{block:15,sky:15}}
ride @n[type=minecraft:item_display,tag=dke.hat.forcefield,distance=..1] mount @s