# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.witch,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:witch_hat"}},transformation:{scale:[3.0f,3.0f,3.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,1.0f,0.0f]},billboard:"fixed",teleport_duration:1,brightness:{block:15,sky:15},Glowing:1b,glow_color_override:11078131}
ride @n[type=minecraft:item_display,tag=dke.hat.witch,distance=..1] mount @s