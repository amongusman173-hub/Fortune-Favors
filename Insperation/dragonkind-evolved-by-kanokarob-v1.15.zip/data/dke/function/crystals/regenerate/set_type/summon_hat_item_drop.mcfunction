# Generated with MC-Build

summon minecraft:item_display ~ ~ ~ {Tags:[dke.entity,dke.hat,dke.hat.item_drop,dke.ticking,smithed.entity,smithed.strict],item:{id:"minecraft:brick",count:1,components:{"minecraft:item_model":"dke:bee_angry"}},transformation:{scale:[3.5f,3.5f,3.5f],left_rotation:[0.0f,0.0f,0.0f,1.0f],right_rotation:[0.0f,0.0f,0.0f,1.0f],translation:[0.0f,-1.0f,0.0f]},billboard:"fixed",teleport_duration:1,brightness:{block:15,sky:15},Glowing:1b,glow_color_override:6750429}
ride @n[type=minecraft:item_display,tag=dke.hat.item_drop,distance=..1] mount @s