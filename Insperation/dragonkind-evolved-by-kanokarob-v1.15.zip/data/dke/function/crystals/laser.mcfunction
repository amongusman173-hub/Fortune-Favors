# Generated with MC-Build

particle dust{color:[1,0,0],scale:1.0} ~ ~1.5 ~ 1 1 1 0 1 force
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
execute unless entity @e[predicate=dke:end_crystal/laser,tag=dke.charging] if score @s dke.time matches 100.. if predicate dke:chance/01 run function dke:crystals/laser/end_crystal_laser_trigger
execute if entity @s[tag=dke.charging] run function dke:crystals/laser/end_crystal_laser_charging