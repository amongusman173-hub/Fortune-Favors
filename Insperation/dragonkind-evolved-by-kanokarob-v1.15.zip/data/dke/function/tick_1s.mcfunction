# Generated with MC-Build

# Death Check
execute in minecraft:the_end positioned 6.5 0 0 if loaded ~ ~ ~ positioned over motion_blocking if score $$dke.global dke.alive matches 1 unless entity @e[type=minecraft:ender_dragon,tag=dke.started] run function dke:ender_dragon_death
# Player 1s
execute as @a at @s run function dke:tick_1s_player
# Entities 1s
execute as @e[type=#dke:entities_1s,tag=dke.ticking] at @s run function dke:tick_1s_entities
#Reschedule function
schedule function dke:tick_1s 1s replace