# Generated with MC-Build

tag @s add dke.entity
tag @s add dke.ticking