# Generated with MC-Build

# Forced Landing Countdown
execute if entity @s[tag=dke.grounded] run function dke:tick_1s_player/forced_land_countdown
execute unless predicate dke:enchantments/dragonsight if predicate dke:extreme_night_vision run effect clear @s night_vision