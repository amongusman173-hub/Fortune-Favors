# Generated with MC-Build

scoreboard players reset @s dke.time
scoreboard players reset @s dke.time.sound
scoreboard players reset @s dke.time.generic
scoreboard players reset @s dke.time.meteors
scoreboard players reset @s dke.cooldown
scoreboard players reset @s dke.state
scoreboard players reset @s dke.alive
scoreboard players reset @s dke.success
scoreboard players reset @s dke.temp
scoreboard players reset @s dke.edk
scoreboard players reset @s dke.difficulty
scoreboard players reset @s dke.has_end_crystals
scoreboard players reset @s dke.type
scoreboard players reset @s dke.next_type
scoreboard players reset @s dke.count
scoreboard players reset @s dke.health
scoreboard players reset @s dke.player_health
scoreboard players reset @s dke.ability_1
scoreboard players reset @s dke.ability_2
scoreboard players reset @s dke.ability_3
scoreboard players reset @s dke.pickaxe_count
scoreboard players reset @s dke.w_stick
scoreboard players reset @s dke.pickaxe
scoreboard players reset @s dke.anchor_id