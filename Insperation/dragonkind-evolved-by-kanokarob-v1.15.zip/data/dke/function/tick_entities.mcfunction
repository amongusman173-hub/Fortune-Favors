# Generated with MC-Build

# Cleanup Marker
execute if entity @s[tag=dke.cleanup_crew] if loaded ~ ~ ~ if score @s dke.cooldown matches 1.. run function dke:tick_entities/clean_island
# End Crystal Special Powers
execute if entity @s[type=minecraft:end_crystal,tag=dke.end_crystal,predicate=dke:dragon_lair] run function dke:crystals/end_crystal_tick
execute if entity @s[type=minecraft:item_display,tag=dke.hat,predicate=dke:dragon_lair] unless predicate dke:has_vehicle run kill @s
# Ender Dragon Behavior
execute if entity @s[type=minecraft:ender_dragon,predicate=dke:dragon_lair,tag=dke.started] run function dke:dragons/dragon_tick
# Evoker Fang Origin
execute if entity @s[tag=dke.evoker_fang.origin] run function dke:tick_entities/evoker_fang_origin
# End Rod Origin
execute if entity @s[tag=dke.end_rod.origin] run function dke:tick_entities/end_rod_origin
# End Rods
execute if entity @s[tag=dke.end_rod] run function dke:tick_entities/end_rod_movement
# Projectiles
execute if entity @s[tag=dke.projectile] run function dke:tick_entities/projectile_behavior
# Landmines
execute if entity @s[tag=dke.landmine] run function dke:tick_entities/landmine
# Shockwave Center
execute if entity @s[tag=dke.shockwave.active] if score @s dke.cooldown matches 1.. run function dke:tick_entities/shockwave_active
# Hazards
execute if entity @s[tag=dke.hazard] run function dke:tick_entities/hazards
# Dragon-Sinew Crossbow Arrows
execute if entity @s[tag=dke.exhalation_arrow] run function dke:items/exhalation_arrows
# Scan Entities
execute if entity @s[tag=dke.scan] run function dke:tick_entities/scan_removal
# Dragonheart Anchor
execute if entity @s[tag=dke.anchor_marker] if predicate dke:in_end run function dke:items/anchor_summon
execute if entity @s[tag=dke.anchor_marker] unless predicate dke:in_end run function dke:items/anchor_fail
execute if entity @s[tag=dke.anchor] run function dke:items/anchor_behavior
# Cloud Behaviors
execute if entity @s[tag=dke.cloud,tag=!dke.cloud_copy] run function dke:tick_entities/breath_cloud_behavior
execute if entity @s[tag=dke.cloud_copy] in the_end if blocks ~-1 ~-1 ~-1 ~1 ~-1 ~1 -1 3 -1 all run tp @s ~ ~-1 ~