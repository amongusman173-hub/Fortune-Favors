# Generated with MC-Build

data modify entity @s Invulnerable set value 0b
damage @s 1.0