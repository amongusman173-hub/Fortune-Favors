# Generated with MC-Build

scoreboard players operation @s dke.type = $$dke.global dke.type
scoreboard players operation @s dke.difficulty = $$dke.global dke.difficulty
loot spawn ~ ~3 ~ loot dke:ender_dragon
execute if score $$dke.global dke.ominous matches 1 run loot spawn ~ ~3 ~ loot dke:ender_dragon
scoreboard players reset @s dke.type
scoreboard players reset @s dke.difficulty
scoreboard players reset $$dke.global dke.ominous