# Generated with MC-Build

execute if entity @s[type=minecraft:area_effect_cloud,predicate=dke:dragon_breath] run function dke:tag_entities/tag_clouds
execute if entity @s[type=minecraft:ender_dragon] run function dke:tag_entities/tag_ticking
execute if entity @s[type=minecraft:end_crystal,nbt={ShowBottom: 1b}] run function dke:tag_entities/tag_ticking
execute if entity @s[type=minecraft:enderman] if entity @e[type=minecraft:ender_dragon,distance=..128] run function dke:tag_entities/tag_ticking