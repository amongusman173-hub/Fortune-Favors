# Generated with MC-Build

#Removes End Crystal Invulnerability
execute as @e[type=minecraft:end_crystal,predicate=dke:dragon_lair] run data modify entity @s Invulnerable set value 0b
#Clean up scores
scoreboard players reset $$dke.global
scoreboard players reset $$dke.total
execute as @e run function dke:reset_scores
#Remove scores
scoreboard objectives remove dke.time
scoreboard objectives remove dke.time.sound
scoreboard objectives remove dke.time.generic
scoreboard objectives remove dke.time.meteors
scoreboard objectives remove dke.cooldown
scoreboard objectives remove dke.state
scoreboard objectives remove dke.alive
scoreboard objectives remove dke.success
scoreboard objectives remove dke.temp
scoreboard objectives remove dke.edk
scoreboard objectives remove dke.difficulty
scoreboard objectives remove dke.has_end_crystals
scoreboard objectives remove dke.type
scoreboard objectives remove dke.next_type
scoreboard objectives remove dke.count
scoreboard objectives remove dke.health
scoreboard objectives remove dke.player_health
scoreboard objectives remove dke.ability_1
scoreboard objectives remove dke.ability_2
scoreboard objectives remove dke.ability_3
scoreboard objectives remove dke.pickaxe_count
scoreboard objectives remove dke.w_stick
scoreboard objectives remove dke.pickaxe
scoreboard objectives remove dke.anchor_id
# Remove excess entities and items
kill @e[tag=dke.crystal]
kill @e[tag=dke.cloud]
kill @e[tag=dke.mob]
kill @e[tag=dke.requires_dragon]
kill @e[tag=dke.hat]