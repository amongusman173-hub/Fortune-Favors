# Generated with MC-Build

# Ender Dragon Initialize
execute if entity @s[type=minecraft:ender_dragon,tag=!dke.started] run function dke:dragons/ender_dragon_start
# End Crystal Setup
execute if entity @s[type=minecraft:end_crystal,predicate=dke:dragon_lair,nbt={ShowBottom:1b}] run function dke:tick_1s_entities/direct_end_crystal
# End Crystal Regeneration
execute if entity @s[type=minecraft:marker,tag=dke.crystal] unless entity @e[type=minecraft:end_crystal,distance=..2] run function dke:crystals/end_crystal_1s
# Enderman item removal
execute if entity @s[type=minecraft:enderman] run function dke:tick_1s_entities/enderman_behavior
# Igloos
execute if entity @s[tag=dke.igloo] run function dke:tick_1s_entities/igloo_behavior