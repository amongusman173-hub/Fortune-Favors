# Generated with MC-Build

execute rotated ~0 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~30 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~60 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~90 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~120 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~150 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~180 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~210 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~240 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~270 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~300 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~330 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal
execute rotated ~360 0 run particle portal ^ ^ ^0.5 ^ ^ ^1000000000 0.000000003 0 normal