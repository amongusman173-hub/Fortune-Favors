# Generated with MC-Build

# Draconic Scepter
execute if predicate dke:items/draconic_scepter unless predicate dke:sneaking run function dke:items/draconic_scepter_use
execute if predicate dke:items/draconic_scepter if predicate dke:sneaking run tag @s add dke.scepter_charging