# Generated with MC-Build

tag @s add dke.anchored
playsound entity.enderman.teleport block @a ~ ~ ~ 1 1
particle reverse_portal ~ ~1 ~ 3 3 3 0.05 30 normal
execute positioned over motion_blocking run tp @s ~ ~ ~
execute at @s run playsound block.respawn_anchor.deplete block @a ~ ~-1 ~ 1 1
execute at @s run playsound block.portal.travel block @s ~ ~-1 ~ 0.4 2
execute at @s run particle reverse_portal ~ ~1 ~ 3 3 3 0.05 30 normal
effect give @s resistance 1 100 false
effect give @s fire_resistance 5 0 false
effect give @s instant_health 1 0 false
effect give @s regeneration 5 0 false