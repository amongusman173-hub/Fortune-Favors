# Generated with MC-Build

execute rotated ~0 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~15 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~30 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~45 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~60 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~75 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~90 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~105 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~120 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~135 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~150 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~165 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~180 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~195 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~210 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~225 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~240 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~255 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~270 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~285 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~300 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~315 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~330 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~345 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
execute rotated ~360 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0.1 10 normal
execute rotated ~375 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.1 10 normal
tag @s add dke.scepter_caster
particle dragon_breath ~ ~ ~ 0.5 0.5 0.5 0.1 30 normal
playsound entity.dragon_fireball.explode player @a ~ ~ ~ 2 1
playsound entity.ender_dragon.growl player @a ~ ~ ~ 0.7 1.3
execute as @e[distance=0.75..5,type=!#dke:end_mobs,tag=!dke.scepter_caster] run damage @s 12.0 magic by @p[tag=dke.scepter_caster,limit=1]
execute as @e[distance=0.75..8,type=#dke:end_mobs,tag=!dke.scepter_caster] run damage @s 48.0 player_attack by @p[tag=dke.scepter_caster,limit=1]
item modify entity @s weapon.mainhand dke:damage_scepter_large
execute if predicate dke:items/offhand_broken run function dke:items/draconic_scepter_use/break_mainhand
tag @s remove dke.scepter_charging
tag @s remove dke.scepter_caster
scoreboard players reset @s dke.cooldown