# Generated with MC-Build

stopsound @a[distance=..10] block block.respawn_anchor.ambient
playsound block.respawn_anchor.ambient block @a ~ ~ ~ 1 1
scoreboard players reset @s dke.time.sound