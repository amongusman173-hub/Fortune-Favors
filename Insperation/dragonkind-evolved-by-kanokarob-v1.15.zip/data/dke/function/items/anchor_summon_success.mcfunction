# Generated with MC-Build

playsound block.respawn_anchor.charge block @a ~ ~ ~ 1 1
setblock ~ ~ ~ obsidian
execute align xyz run summon item_display ~0.5 ~1.005 ~0.5 {Tags:[dke.anchor,dke.entity,dke.ticking,dke.entity.technical,smithed.entity,smithed.strict],item:{id:"minecraft:polar_bear_spawn_egg",count:1,components:{"minecraft:item_model":"dke:dragonheart_anchor"}},transformation:{translation:[0f,-0.5f,0f],left_rotation:[0f,0f,0f,1f],scale:[1.01f,1.01f,1.01f],right_rotation:[0f,0f,0f,1f]}}
forceload add ~ ~
kill @s