# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
particle dragon_breath ~ ~ ~ 0 0 0 0 1 normal
execute if score @s dke.time matches 6.. as @e[distance=..1,type=!#dke:arrow_ignore] at @s run function dke:items/hit
execute as @e[distance=..8,type=#dke:end_mobs,predicate=!dke:end_crystal/forcefield] at @s run function dke:items/hit_dragon
execute if score @s dke.time matches 6.. if entity @e[distance=..1,type=!#dke:arrow_ignore] run tag @s remove dke.exhalation_arrow
execute if entity @e[distance=..8,type=#dke:end_mobs,predicate=!dke:end_crystal/forcefield] run tag @s remove dke.exhalation_arrow
execute if entity @s[nbt={inGround: 1b}] if score @s dke.time matches 20.. run tag @s remove dke.exhalation_arrow