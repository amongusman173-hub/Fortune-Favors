# Generated with MC-Build

playsound entity.dragon_fireball.explode player @a ~ ~ ~ 3 1.2
playsound entity.ender_dragon.growl player @a ~ ~ ~ 1 1.6
particle dragon_breath ~ ~ ~ 0.3 0.3 0.3 0.05 50 normal
damage @s 1.0 minecraft:arrow by @p[predicate=dke:enchantments/exhalation] from @n[tag=dke.exhalation_arrow,distance=..8]