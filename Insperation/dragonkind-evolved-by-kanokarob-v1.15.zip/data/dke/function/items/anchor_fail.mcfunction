# Generated with MC-Build

summon creeper ~ ~ ~ {Fuse: 1s, ignited: 1b, CustomName: {"translate":"death.dke.intentional_game_design"}, Invulnerable: 1b, DeathLootTable: "dke:empty", ExplosionRadius: 5, Silent: 1b}
particle dragon_breath ~ ~ ~ 0.3 0.3 0.3 0.1 20 normal
kill @s