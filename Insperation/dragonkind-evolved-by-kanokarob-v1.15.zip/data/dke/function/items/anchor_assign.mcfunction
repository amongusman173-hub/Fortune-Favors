# Generated with MC-Build

playsound block.respawn_anchor.set_spawn block @s ~ ~ ~
particle reverse_portal ~ ~1 ~ 0.3 0.3 0.3 0.01 10 normal
tellraw @s {"translate":"message.dke.dragonheart_anchor.set","color":"white"}
scoreboard players operation @s dke.anchor_id = $$dke.global dke.anchor_id