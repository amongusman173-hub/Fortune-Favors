# Generated with MC-Build

execute rotated ~0 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~15 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~30 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~45 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~60 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~75 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~90 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~105 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~120 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~135 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~150 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~165 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~180 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~195 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~210 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~225 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~240 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~255 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~270 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~285 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~300 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~315 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~330 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~345 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal
execute rotated ~360 0 run particle dragon_breath ^ ^ ^3 0.1 0.1 0.1 0 1 normal
execute rotated ~375 0 run particle enchant ^ ^ ^2.5 0.1 0.1 0.1 0.01 1 normal