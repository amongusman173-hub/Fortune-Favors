# Generated with MC-Build

scoreboard players add @s dke.cooldown 0
scoreboard players add @s dke.cooldown 2
execute if score @s dke.cooldown matches 2 run playsound entity.evoker.cast_spell player @a ~ ~ ~ 0.85 0.85
execute if score @s dke.cooldown matches 1..59 positioned ~ ~1 ~ run function dke:items/draconic_charge_particles
execute if score @s dke.cooldown matches 60.. positioned ~ ~1 ~ run function dke:items/draconic_charge_dispel