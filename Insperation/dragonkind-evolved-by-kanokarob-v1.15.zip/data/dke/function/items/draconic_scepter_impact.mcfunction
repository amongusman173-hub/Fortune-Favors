# Generated with MC-Build

particle dragon_breath ^ ^ ^ 0.3 0.3 0.3 0.1 40 force
particle explosion ^ ^ ^ 1 1 1 0 10 force
playsound entity.dragon_fireball.explode player @a ^ ^ ^ 2 1
execute as @e[type=!#dke:end_mobs,distance=..4] run damage @s 8.0 magic by @p[tag=dke.scepter_active]
execute as @e[type=#dke:end_mobs,distance=..4] run damage @s 32.0 player_attack by @p[tag=dke.scepter_active]