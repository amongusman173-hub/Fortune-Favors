# Generated with MC-Build

tag @a[distance=..4] remove dke.anchored
scoreboard players add @s dke.state 0
scoreboard players add @s dke.state 1
execute if score @s dke.state matches 3.. at @s run setblock ~ ~-0.4 ~ crying_obsidian