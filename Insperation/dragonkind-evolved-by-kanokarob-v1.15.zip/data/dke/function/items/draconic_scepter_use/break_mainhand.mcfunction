# Generated with MC-Build

item replace entity @s weapon.mainhand with air 1
playsound entity.item.break player @s ~ ~ ~ 1 1
execute anchored eyes run particle item{item:{id:"minecraft:poisonous_potato",components:{"minecraft:item_model":"dke:dragon_scepter"}}} ^ ^ ^1.5 0.2 0.2 0.2 0.01 5 normal