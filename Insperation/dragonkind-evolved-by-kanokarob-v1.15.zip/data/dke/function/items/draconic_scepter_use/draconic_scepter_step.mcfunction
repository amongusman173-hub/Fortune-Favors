# Generated with MC-Build

scoreboard players add @s dke.count 0
scoreboard players add @s dke.count 1
particle dragon_breath ^ ^ ^ 0.1 0.1 0.1 0.01 5 normal
execute unless block ^ ^ ^ #dke:nonsolid run function dke:items/draconic_scepter_impact
execute if entity @e[type=!#dke:no_knockback,distance=..1.9,tag=!dke.scepter_active] run function dke:items/draconic_scepter_impact
execute if score @s dke.count matches 24.. run function dke:items/draconic_scepter_impact
execute if block ^ ^ ^ #dke:nonsolid unless entity @e[type=!#dke:no_knockback,distance=..1.9,tag=!dke.scepter_active] unless score @s dke.count matches 24.. positioned ^ ^ ^2 run function dke:items/draconic_scepter_use/draconic_scepter_step