# Generated with MC-Build

execute as @n[type=minecraft:item] if items entity @s contents obsidian run kill @s
playsound block.beacon.deactivate block @a ~ ~ ~ 1 1
forceload remove ~ ~
kill @s