advancement revoke @s only dke:dragon_scepter_use
execute unless score @s dke.cooldown matches 1.. unless predicate dke:sneaking run function dke:items/draconic_scepter_use
execute unless score @s dke.cooldown matches 1.. if predicate dke:sneaking run tag @s add dke.scepter_charging