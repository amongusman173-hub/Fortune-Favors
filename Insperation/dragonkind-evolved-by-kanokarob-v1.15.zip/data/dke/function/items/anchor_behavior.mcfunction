# Generated with MC-Build

scoreboard players add @s dke.time.sound 0
scoreboard players add @s dke.time.sound 1
execute store result score @s dke.anchor_id run data get entity @s UUID[0]
execute positioned ~ ~-0.5 ~ run function dke:items/anchor_particles
#Sounds
execute if score @s dke.time.sound matches 80.. if predicate dke:chance/01 run function dke:items/anchor_sound
#Seek anchored players
scoreboard players operation $$dke.global dke.anchor_id = @s dke.anchor_id
#Anchor nearby players
execute as @a[predicate=dke:sneaking,distance=..4] unless score @s dke.anchor_id = $$dke.global dke.anchor_id run function dke:items/anchor_assign
#Test if broken
execute positioned over motion_blocking if entity @a[tag=dke.anchored,distance=..4] run function dke:items/anchor_deplete
execute unless block ~ ~-0.4 ~ obsidian run function dke:items/anchor_break
#Teleport anchored players if injured
execute as @a[scores={dke.player_health=1..4},gamemode=!spectator] unless entity @s[distance=..4] if score @s dke.anchor_id = $$dke.global dke.anchor_id run function dke:items/anchor_trigger
execute as @a[predicate=dke:in_void,gamemode=!spectator] if score @s dke.anchor_id = $$dke.global dke.anchor_id run function dke:items/anchor_trigger