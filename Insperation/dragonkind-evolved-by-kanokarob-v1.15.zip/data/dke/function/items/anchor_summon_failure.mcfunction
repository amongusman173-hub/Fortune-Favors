# Generated with MC-Build

loot spawn ~ ~0.2 ~ loot dke:dragonheart_anchor
tellraw @a[distance=..5] {"translate":"message.dke.dragonheart_anchor.distance","color":"white"}
kill @s