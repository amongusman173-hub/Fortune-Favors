# Generated with MC-Build

tag @s add dke.scepter_active
playsound entity.ender_dragon.shoot player @a ~ ~ ~ 0.75 0.25
scoreboard players set @s dke.cooldown 30
execute anchored eyes positioned ^ ^ ^2 run function dke:items/draconic_scepter_use/draconic_scepter_step
item modify entity @s weapon.mainhand dke:damage_scepter
execute if predicate dke:items/mainhand_broken run function dke:items/draconic_scepter_use/break_mainhand
tag @s remove dke.scepter_active
scoreboard players reset @s dke.count