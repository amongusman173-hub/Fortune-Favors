# Generated with MC-Build

execute if entity @e[tag=dke.anchor,distance=0.4..8] run function dke:items/anchor_summon_failure
execute unless entity @e[tag=dke.anchor,distance=0.4..8] run function dke:items/anchor_summon_success