# Generated with MC-Build

advancement grant @a[predicate=dke:dragon_lair] only dke:root
tag @s add dke.entity
tag @s add dke.started
scoreboard players set $$dke.global dke.alive 1
scoreboard players add $$dke.total dke.edk 0
scoreboard players add $$dke.total dke.edk 1
# Set difficulty tier
function dke:dragons/set_difficulty
# Fledgeling
execute if score @s dke.difficulty matches 1 run function dke:dragons/dragon_buff_easy
# Powerful
execute if score @s dke.difficulty matches 2 run function dke:dragons/dragon_buff_medium
# Cruel
execute if score @s dke.difficulty matches 3 run function dke:dragons/dragon_buff_hard
# Immortal
execute if score @s dke.difficulty matches 4 run function dke:dragons/dragon_buff_immortal
# Ferocious
execute if score @s dke.difficulty matches 5 run function dke:dragons/dragon_buff_ferocious
# Primordial
execute if score @s dke.difficulty matches 6 run function dke:dragons/dragon_buff_primordial
# Ascended
execute if score @s dke.difficulty matches 7 run function dke:dragons/dragon_buff_ascended
# Set Ominous Name
execute if score @s dke.ominous matches 1 run function dke:dragons/set_ominous_name
# Reset
scoreboard players reset $$dke.global dke.next_type
#Unique dragon effects
execute if entity @s[tag=dke.type.elder] run data modify entity @s active_effects set value [{id:"minecraft:glowing",duration:72000}]
execute if entity @s[tag=dke.type.beacon] run data modify entity @s active_effects set value [{id:"minecraft:glowing",duration:72000}]
execute if entity @s[tag=dke.type.wight] run data modify entity @s Silent set value 1b
# Set End Crystal Powers
scoreboard players operation $$dke.global dke.type = @s dke.type
tag @e[type=minecraft:end_crystal,predicate=dke:dragon_lair] add dke.end_crystal
execute if score @s dke.edk matches 4.. as @e[type=minecraft:end_crystal,predicate=dke:dragon_lair,tag=!smithed.entity,tag=!smithed.strict] at @s run function dke:crystals/regenerate/set_type
execute as @e[tag=dke.crystal] at @s if entity @e[predicate=dke:end_crystal/cursed,distance=..2] run tag @s add dke.cursed_aura