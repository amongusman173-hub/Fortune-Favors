# Generated with MC-Build

data modify entity @s DragonPhase set value 2
scoreboard players reset @s dke.time