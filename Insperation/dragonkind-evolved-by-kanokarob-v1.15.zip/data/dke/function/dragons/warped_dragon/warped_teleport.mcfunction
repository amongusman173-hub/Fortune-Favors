# Generated with MC-Build

data modify entity @s DragonPhase set value 0
particle minecraft:reverse_portal ~ ~2 ~ 1.5 1.5 1.5 0.05 20 force
execute at @e[tag=dke.crystal,limit=1,sort=random] facing 0 100 0 positioned ^ ^ ^-12 run tp @s ~ ~ ~
execute at @s run playsound entity.enderman.teleport hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 1 1
execute at @s run particle minecraft:portal ~ ~2 ~ 1.5 1.5 1.5 0.05 20 force