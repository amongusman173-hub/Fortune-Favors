# Generated with MC-Build

execute if entity @s[type=player] run scoreboard players set $$dke.global dke.next_type 100
function dke:dragons/reset_tag
tag @s[type=minecraft:ender_dragon] add dke.type.last
data modify entity @s CustomName set value [{"text":"","color":"light_purple"},{"translate":"dragon.dke.type.last"}]
data modify entity @s[type=minecraft:ender_dragon] Silent set value 0b
effect clear @s[type=minecraft:ender_dragon]