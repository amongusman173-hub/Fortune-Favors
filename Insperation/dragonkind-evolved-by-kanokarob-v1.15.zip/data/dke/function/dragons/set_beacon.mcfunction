# Generated with MC-Build

execute if entity @s[type=player] run scoreboard players set $$dke.global dke.next_type 11
function dke:dragons/reset_tag
tag @s[type=minecraft:ender_dragon] add dke.type.beacon
execute if predicate dke:scores/edk_easy run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.fledgeling"},{"translate":"dragon.dke.type.beacon"}]
execute if predicate dke:scores/edk_med run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.powerful"},{"translate":"dragon.dke.type.beacon"}]
execute if predicate dke:scores/edk_hard run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.cruel"},{"translate":"dragon.dke.type.beacon"}]
execute if predicate dke:scores/edk_immortal run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.immortal"},{"translate":"dragon.dke.type.beacon"}]
execute if predicate dke:scores/edk_ferocious run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.beacon"}]
data modify entity @s[type=minecraft:ender_dragon] Silent set value 0b
data modify entity @s[type=minecraft:ender_dragon] active_effects set value [[{id:"minecraft:glowing",duration:72000}]]