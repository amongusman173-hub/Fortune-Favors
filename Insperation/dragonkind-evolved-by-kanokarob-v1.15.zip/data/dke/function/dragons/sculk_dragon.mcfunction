# Generated with MC-Build

scoreboard players set $$dke.global dke.type 4
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:sculk_charge{roll:0.0f} ~ ~2 ~ 1 1 1 0.05 10 normal
execute positioned over motion_blocking run place feature dke:sculk_patch
#Sonic Boom
execute if predicate dke:generic_flight unless entity @s[tag=dke.charging] if score @s dke.time matches 300.. if predicate dke:chance/003 run function dke:dragons/sculk_dragon/sonic_boom_trigger
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/sculk_dragon/sonic_boom