# Generated with MC-Build

scoreboard players reset @s dke.time
tag @s remove dke.charging
playsound entity.wither.hurt hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85
playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
particle minecraft:soul ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
particle minecraft:large_smoke ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
execute at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:spawns/summon_tyrant_servants