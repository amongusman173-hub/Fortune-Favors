# Generated with MC-Build

function dke:dragons/last_dragon/last_dragon_power/summon_amethyst_projectiles
execute if entity @a[predicate=dke:flying,predicate=dke:dragon_lair] as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/shared_behavior/attack_generic/ground_flying_players
scoreboard players reset @s dke.time