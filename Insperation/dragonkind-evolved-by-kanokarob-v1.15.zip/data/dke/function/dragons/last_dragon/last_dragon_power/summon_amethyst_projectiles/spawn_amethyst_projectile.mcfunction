# Generated with MC-Build

summon item_display ~ ~ ~ {Tags:[dke.projectile,dke.projectile.amethyst,dke.entity,dke.ticking,dke.requires_dragon,smithed.entity,smithed.strict],Glowing:1b,item:{id:"minecraft:amethyst_shard",count:1},brightness:{block:15,sky:15},glow_color_override:14524405,teleport_duration:1,transformation:{translation:[0f,0f,0f],left_rotation:[0.706f,0f,0f,0.708f],scale:[2f,2f,2f],right_rotation:[0f,0f,-0.401f,0.916f]}}
execute positioned ~ ~ ~ as @n[tag=dke.projectile.amethyst,tag=!dke.marked] run tp @s ~ ~ ~ ~ ~