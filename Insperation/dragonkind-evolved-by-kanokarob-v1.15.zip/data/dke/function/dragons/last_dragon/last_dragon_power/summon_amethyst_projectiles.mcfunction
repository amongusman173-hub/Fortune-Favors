# Generated with MC-Build

playsound block.amethyst_block.break hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.75 1
playsound entity.ender_dragon.shoot hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.7 1
execute facing entity @a[predicate=dke:dragon_lair,limit=5,sort=random,gamemode=!spectator] feet positioned ^ ^ ^4 run function dke:dragons/last_dragon/last_dragon_power/summon_amethyst_projectiles/spawn_amethyst_projectile