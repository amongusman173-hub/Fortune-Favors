# Generated with MC-Build

execute if score @s dke.type matches 0 run tag @s add dke.type.vanilla
execute if score @s dke.type matches 1 run tag @s add dke.type.zombie
execute if score @s dke.type matches 2 run tag @s add dke.type.moss
execute if score @s dke.type matches 3 run tag @s add dke.type.warped
execute if score @s dke.type matches 4 run tag @s add dke.type.sculk
execute if score @s dke.type matches 5 run tag @s add dke.type.frost
execute if score @s dke.type matches 6 run tag @s add dke.type.tyrant
execute if score @s dke.type matches 7 run tag @s add dke.type.skeletal
execute if score @s dke.type matches 8 run tag @s add dke.type.nether
execute if score @s dke.type matches 9 run tag @s add dke.type.elder
execute if score @s dke.type matches 10 run tag @s add dke.type.wight
execute if score @s dke.type matches 11 run tag @s add dke.type.beacon
execute if score @s dke.type matches 12 run tag @s add dke.type.desert
execute if score @s dke.type matches 13 run tag @s add dke.type.thunder
execute if score @s dke.type matches 14 run tag @s add dke.type.artillery
execute if score @s dke.type matches 100 run tag @s add dke.type.last
execute if score @s dke.type matches 101 run tag @s add dke.type.10k