# Generated with MC-Build

tag @s remove dke.type.vanilla
tag @s remove dke.type.zombie
tag @s remove dke.type.warped
tag @s remove dke.type.sculk
tag @s remove dke.type.frost
tag @s remove dke.type.tyrant
tag @s remove dke.type.skeletal
tag @s remove dke.type.nether
tag @s remove dke.type.elder
tag @s remove dke.type.wight
tag @s remove dke.type.beacon
tag @s remove dke.type.last
tag @s remove dke.type.10k