# Generated with MC-Build

execute store result entity @s Health float 1 run scoreboard players remove @s dke.health 40
playsound entity.skeleton.hurt hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85
playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
particle minecraft:soul_fire_flame ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
particle minecraft:block{block_state: "minecraft:bone_block"} ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
execute positioned ^7 ^ ^7 positioned over motion_blocking run function dke:spawns/skeletal_servant
execute positioned ^7 ^ ^-7 positioned over motion_blocking run function dke:spawns/skeletal_servant
execute positioned ^-7 ^ ^7 positioned over motion_blocking run function dke:spawns/skeletal_servant
execute positioned ^-7 ^ ^-7 positioned over motion_blocking run function dke:spawns/skeletal_servant