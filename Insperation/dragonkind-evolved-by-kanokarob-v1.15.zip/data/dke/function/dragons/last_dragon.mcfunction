# Generated with MC-Build

scoreboard players set $$dke.global dke.type 100
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:falling_dust{block_state:"minecraft:amethyst_block"} ~ ~2 ~ 1 1 1 0.05 5 normal
particle minecraft:dust{color:[0.824,0.514,0.976],scale:2.0} ~ ~2 ~ 1 1 1 0.05 5 normal
execute positioned over motion_blocking run place feature dke:amethyst_patch
#Choose power
execute if predicate dke:generic_flight if score @s dke.time matches 100..299 if predicate dke:chance/01 run function dke:dragons/last_dragon/last_dragon_power
execute if score @s dke.time matches 300.. if predicate dke:chance/1 run function dke:dragons/last_dragon/all_last_powers