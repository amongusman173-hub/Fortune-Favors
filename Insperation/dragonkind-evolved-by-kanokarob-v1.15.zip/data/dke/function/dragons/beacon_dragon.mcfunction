# Generated with MC-Build

scoreboard players set $$dke.global dke.type 11
scoreboard players add @s dke.state 0
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:dust_color_transition{from_color:[0.769f,1.0f,0.969f],scale:2.5,to_color:[1.0f,1.0f,1.0f]} ~ ~2 ~ 1 1 1 0.05 10 normal
execute unless predicate dke:landing_phases if block ~ ~-25 ~ #dke:end_ground unless entity @s[tag=dke.attack.slam] run tp @s ^ ^ ^0.44
#Select laser target
execute if score @s dke.time matches 40.. if predicate dke:chance/01 run function dke:dragons/beacon_dragon/beacon_dragon_select
execute if score @s dke.time matches 60.. if score @s dke.state matches 2 run function dke:dragons/beacon_dragon/beacon_dragon_select
execute if score @s dke.time matches 100.. if predicate dke:chance/1 run function dke:dragons/beacon_dragon/beacon_dragon_select
execute if score @s dke.time matches 300.. run function dke:dragons/beacon_dragon/beacon_dragon_select
#Forwards laser
execute if predicate dke:generic_flight if score @s dke.state matches 0 unless entity @s[nbt={DragonPhase:9}] rotated ~ 120 positioned ^ ^ ^ run function dke:dragons/beacon_dragon/beacon_dragon_laser
#Downwards laser
execute if predicate dke:generic_flight if score @s dke.state matches 1 unless entity @s[nbt={DragonPhase: 9}] rotated ~ 90 positioned ^ ^ ^ run function dke:dragons/beacon_dragon/beacon_dragon_laser
execute if predicate dke:landing_phases unless entity @s[nbt={DragonPhase: 9}] rotated ~ 90 positioned ^ ^ ^ run function dke:dragons/beacon_dragon/beacon_dragon_laser
#Laser at player
execute if predicate dke:generic_flight if score @s dke.state matches 2 unless entity @s[nbt={DragonPhase: 9}] facing entity @p[predicate=dke:dragon_lair,gamemode=!spectator] feet positioned ^ ^ ^ run function dke:dragons/beacon_dragon/beacon_dragon_laser