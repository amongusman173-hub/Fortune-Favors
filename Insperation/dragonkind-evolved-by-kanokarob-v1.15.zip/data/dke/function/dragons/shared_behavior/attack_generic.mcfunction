# Generated with MC-Build

# Roll attack
function dke:dragons/shared_behavior/attack_generic/roll_attack
#Ground fliers
execute unless score $$dke.global dke.has_end_crystals matches 1.. if entity @a[predicate=dke:flying,predicate=dke:dragon_lair] as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/shared_behavior/attack_generic/ground_flying_players
execute if score @s dke.ominous matches 1 if entity @a[predicate=dke:flying,predicate=dke:dragon_lair] as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/shared_behavior/attack_generic/ground_flying_players
#Slam
execute if score @s dke.temp matches 1 positioned over motion_blocking if block ~ ~-1 ~ #dke:end_ground run tag @s add dke.attack.slam
#End Rod Spikes
execute if score @s dke.temp matches 2 if predicate dke:landing_phases positioned over motion_blocking run summon marker ~ ~ ~ {Tags:[dke.end_rod.origin,dke.entity,dke.ticking,dke.requires_dragon,dke.entity.technical]}
#Shulker Bullets
execute if score @s dke.temp matches 3 unless entity @e[tag=dke.bullet,distance=..150] run function dke:dragons/shared_behavior/attack_generic/summon_shulker_bullets
# Meteor Storm
execute if score @s dke.temp matches 4 run tag @s add dke.attack.meteors
execute if entity @s[tag=dke.type.warped] if score @s dke.temp matches 5 run kill @e[type=minecraft:area_effect_cloud,predicate=dke:dragon_lair]
scoreboard players reset @s dke.time.generic