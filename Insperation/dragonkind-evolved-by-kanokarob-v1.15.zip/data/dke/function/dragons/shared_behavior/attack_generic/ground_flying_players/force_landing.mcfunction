# Generated with MC-Build

scoreboard players set @s dke.time.forced_land 20
attribute @s minecraft:gravity modifier add dke:forced_land 10.0 add_value
attribute @s minecraft:fall_damage_multiplier base set 0
tag @s add dke.grounded