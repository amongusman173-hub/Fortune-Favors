# Generated with MC-Build

execute store result score @s dke.temp run random value 1..4
execute if entity @s[tag=!dke.type.vanilla,tag=!dke.ominous] if score $$dke.global dke.has_end_crystals matches 1.. store result score @s dke.temp run random value 1..3
# Reroll based on status
execute if score @s dke.temp matches 1 if predicate dke:landing_phases run scoreboard players set @s dke.temp 2
execute if score @s dke.temp matches 1 positioned over motion_blocking unless block ~ ~-2 ~ #dke:end_ground run scoreboard players set @s dke.temp 2
execute if score @s dke.temp matches 2 unless predicate dke:landing_phases run scoreboard players add @s dke.temp 1
execute if score @s dke.temp matches 3 if entity @e[tag=dke.bullet,distance=..150] positioned over motion_blocking run scoreboard players add @s dke.temp 1
execute if score @s dke.temp matches 4 if entity @s[tag=dke.attack.meteors] run scoreboard players set @s dke.temp 2
execute if score @s dke.temp matches 4 if entity @s[tag=!dke.type.vanilla,tag=!dke.ominous] if score $$dke.global dke.has_end_crystals matches 1.. run scoreboard players set @s dke.temp 2