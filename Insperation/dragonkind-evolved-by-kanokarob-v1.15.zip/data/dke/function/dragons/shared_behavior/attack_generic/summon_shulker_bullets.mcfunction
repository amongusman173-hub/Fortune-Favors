# Generated with MC-Build

playsound entity.shulker.shoot hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85 1
execute rotated ~0 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~30 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~60 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~90 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~120 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~150 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~180 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~210 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~240 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~270 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~300 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~330 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute rotated ~360 0 run summon shulker_bullet ^ ^ ^10 {Steps:128,Tags:[dke.bullet,dke.entity,dke.requires_dragon],Invulnerable:1b}
execute as @e[tag=dke.bullet] at @s run data modify entity @s Target set from entity @a[limit=1,sort=random,gamemode=!creative,gamemode=!spectator,predicate=dke:dragon_lair] UUID