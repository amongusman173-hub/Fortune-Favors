# Generated with MC-Build

execute store success score @s dke.success positioned over motion_blocking if block ~ ~-1 ~ #dke:laser_barrier
execute if score @s dke.success matches 1.. run function dke:dragons/shared_behavior/attack_generic/ground_flying_players/force_landing
particle minecraft:cloud ~ ~2.5 ~ 0.5 0.2 0.5 0.01 20 normal
playsound entity.ender_dragon.ambient hostile @s ~ ~ ~ 1 1
playsound entity.elder_guardian.curse hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.7 1
scoreboard players reset @s dke.success