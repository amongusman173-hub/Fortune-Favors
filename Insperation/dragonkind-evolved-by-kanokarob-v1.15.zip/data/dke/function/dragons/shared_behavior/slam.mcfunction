# Generated with MC-Build

execute if score @s dke.time matches 1 as @a[predicate=dke:dragon_lair] at @s run playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 3 0.7
data modify entity @s Motion[1] set value -1.0d
execute if block ~ ~-4 ~ #dke:end_ground run function dke:dragons/shared_behavior/slam/slam_effect
execute positioned over motion_blocking unless block ~ ~-2 ~ #dke:end_ground run function dke:dragons/shared_behavior/slam/slam_effect