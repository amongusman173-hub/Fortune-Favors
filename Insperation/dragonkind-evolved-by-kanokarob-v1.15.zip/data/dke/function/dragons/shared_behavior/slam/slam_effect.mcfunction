# Generated with MC-Build

data modify entity @s Motion[1] set value 2.0d
execute as @a[predicate=dke:dragon_lair] at @s run playsound entity.dragon_fireball.explode hostile @s ~ ~ ~ 3 0.7
particle minecraft:explosion ~ ~ ~ 3 0.3 3 0 30 force
particle minecraft:dragon_breath ~ ~ ~ 3 0.3 3 0.1 50 force
particle minecraft:falling_dust{block_state:"minecraft:end_stone"} ~ ~ ~ 3 0.3 3 0.1 50 force
tag @s remove dke.attack.slam
scoreboard players reset @s dke.time