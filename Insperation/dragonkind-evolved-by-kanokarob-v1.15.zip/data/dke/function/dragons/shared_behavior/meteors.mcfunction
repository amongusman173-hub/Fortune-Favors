# Generated with MC-Build

execute if score @s dke.time.meteors matches 0 as @a[predicate=dke:dragon_lair] at @s run playsound entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.7
# Summon Meteor
execute if score @s dke.time.meteors matches 20 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 30 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 40 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 50 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 60 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 70 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 80 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 90 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 100 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 110 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 120 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 130 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
execute if score @s dke.time.meteors matches 140 summon minecraft:marker run function dke:dragons/shared_behavior/meteors/select_location
# Increment
scoreboard players add @s dke.time.meteors 1
# Expire
execute if score @s dke.time.meteors matches 140.. run function dke:dragons/shared_behavior/meteors/expire