# Generated with MC-Build

execute as @a[predicate=dke:dragon_lair] at @s run playsound minecraft:entity.ender_dragon.shoot hostile @s ~ ~ ~ 1.2 0.8 1
data merge entity @s {Tags:[dke.entity,dke.marker.meteor,smithed.entity,smithed.strict]}
spreadplayers 0 0 1 40 false @s
execute at @s positioned ~ 90 ~ summon minecraft:dragon_fireball run function dke:dragons/shared_behavior/meteors/select_location/summon_meteor
kill @s