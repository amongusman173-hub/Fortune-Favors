# Generated with MC-Build

data merge entity @s {Tags:[dke.entity,dke.requires_dragon,smithed.entity,smithed.strict],Motion:[0.0d,-0.125d,0.0d],acceleration_power:0.125d,attributes:[{id:"minecraft:scale",base:4}]}
data modify entity @s Owner set from entity @n[type=minecraft:ender_dragon,predicate=dke:dragon_lair] UUID