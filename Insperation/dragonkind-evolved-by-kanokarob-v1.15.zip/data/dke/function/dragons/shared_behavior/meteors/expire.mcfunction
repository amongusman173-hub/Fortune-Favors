# Generated with MC-Build

tag @s remove dke.attack.meteors
scoreboard players reset @s dke.time.meteors