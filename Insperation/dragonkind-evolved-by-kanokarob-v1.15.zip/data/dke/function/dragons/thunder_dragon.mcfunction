# Generated with MC-Build

scoreboard players set $$dke.global dke.type 13
scoreboard players add @s dke.state 0
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time.sound 0
scoreboard players add @s dke.time 1
scoreboard players add @s dke.time.sound 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
execute if predicate dke:generic_flight unless entity @s[tag=dke.attack.slam] run tp @s ^ ^ ^-0.44
# Aesthetics
particle minecraft:falling_dust{block_state:"minecraft:light_blue_concrete_powder"} ~ ~2 ~ 1 1 1 0.05 5 normal
particle minecraft:wax_off ~ ~2 ~ 1 1 1 0.01 10 normal
execute if score @s dke.time.sound matches 100.. if predicate dke:chance/003 run function dke:dragons/thunder_dragon/sound
# Hazards
execute if score @s dke.time matches 600.. run function dke:dragons/thunder_dragon/reset_hazards
execute unless entity @e[tag=dke.hazard.center] positioned 0 0 0 positioned over motion_blocking rotated 0 0 run function dke:dragons/thunder_dragon/summon_hazards
# Perch minimzation
execute if entity @s[tag=dke.attempting_perch,nbt={DragonPhase:0}] run tag @s remove dke.attempt_perch
execute if entity @s[tag=!dke.attempting_perch,nbt={DragonPhase:3}] run function dke:dragons/thunder_dragon/attempt_perch
# Lightning Breath
execute if entity @s[nbt={DragonPhase:5}] run function dke:dragons/thunder_dragon/lightning_breath