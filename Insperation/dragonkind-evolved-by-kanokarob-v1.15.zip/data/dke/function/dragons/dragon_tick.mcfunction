# Generated with MC-Build

execute positioned ~ ~15 ~ run fill ~-6 ~-20 ~-6 ~6 ~-5 ~6 air replace minecraft:water[level=8]
execute store success score @s dke.success run fill ~-5 ~-5 ~-5 ~5 ~ ~5 air replace #dke:explosives
execute if score @s dke.success matches 1.. run function dke:dragons/bed_destroyed
scoreboard players operation $$dke.global dke.difficulty = @s dke.difficulty
execute store success score $$dke.global dke.has_end_crystals if entity @e[type=minecraft:end_crystal,tag=dke.entity,predicate=dke:dragon_lair]
# Health Regeneration
execute store result score @s dke.health run data get entity @s Health
execute if score $$dke.global dke.has_end_crystals matches 1.. if predicate dke:chance/05 unless score @s dke.health >= @s dke.max_health store result entity @s Health float 1.002 run scoreboard players operation @s dke.health += @s dke.difficulty
# Shared Behavior
function dke:dragons/shared_behavior
# Zombie
execute if entity @s[tag=dke.type.zombie] run function dke:dragons/zombie_dragon
# Moss
execute if entity @s[tag=dke.type.moss] run function dke:dragons/moss_dragon
# Warped
execute if entity @s[tag=dke.type.warped] run function dke:dragons/warped_dragon
# Sculk
execute if entity @s[tag=dke.type.sculk] run function dke:dragons/sculk_dragon
# Frost
execute if entity @s[tag=dke.type.frost] run function dke:dragons/frost_dragon
# Tyrant
execute if entity @s[tag=dke.type.tyrant] run function dke:dragons/tyrant_dragon
# Skeletal
execute if entity @s[tag=dke.type.skeletal] run function dke:dragons/skeletal_dragon
# Nether
execute if entity @s[tag=dke.type.nether] run function dke:dragons/nether_dragon
# Elder
execute if entity @s[tag=dke.type.elder] run function dke:dragons/elder_dragon
# Wight
execute if entity @s[tag=dke.type.wight] run function dke:dragons/wight_dragon
# Beacon
execute if entity @s[tag=dke.type.beacon] run function dke:dragons/beacon_dragon
# Desert
execute if entity @s[tag=dke.type.desert] run function dke:dragons/desert_dragon
# Thunder
execute if entity @s[tag=dke.type.thunder] run function dke:dragons/thunder_dragon
# Artillery Dragon
execute if entity @s[tag=dke.type.artillery] run function dke:dragons/artillery_dragon
# Last Dragon
execute if entity @s[tag=dke.type.last] run function dke:dragons/last_dragon
# 10,000 Dragon
execute if entity @s[tag=dke.type.10k] run function dke:dragons/10k_dragon