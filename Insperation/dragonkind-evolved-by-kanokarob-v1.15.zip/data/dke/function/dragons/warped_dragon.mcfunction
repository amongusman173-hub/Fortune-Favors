# Generated with MC-Build

scoreboard players set $$dke.global dke.type 3
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:portal ~ ~2 ~ 1 1 1 0.05 10 normal
particle minecraft:enchanted_hit ~ ~2 ~ 1 1 1 0.05 10 normal
execute unless predicate dke:landing_phases unless entity @s[tag=dke.attack.slam] run tp @s ^ ^ ^0.44
execute positioned over motion_blocking run place feature dke:warped_patch
#Perching
execute if predicate dke:generic_flight if score @s dke.time matches 500.. if predicate dke:chance/01 run function dke:dragons/warped_dragon/warped_perch
execute unless predicate dke:landing_phases if score @s dke.time matches 60.. if predicate dke:chance/003 run function dke:dragons/warped_dragon/warped_teleport