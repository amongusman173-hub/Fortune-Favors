# Generated with MC-Build

damage @s 1.0 magic by @n[type=minecraft:ender_dragon,tag=dke.started]
stopsound @s hostile block.beacon.power_select
playsound block.beacon.power_select hostile @s ~ ~ ~ 1 2
particle minecraft:entity_effect{color:[0.78f,1.0f,1.0f,1.0f]} ~ ~0.75 ~ 0.3 0.5 0.3 0.05 1 normal