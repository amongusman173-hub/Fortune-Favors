# Generated with MC-Build

scoreboard players reset @s dke.time
scoreboard players operation @s dke.temp = @s dke.state
execute if score @s dke.temp matches 2 store result score @s dke.state run random value 0..1
execute unless score @s dke.temp matches 2 store result score @s dke.state run random value 0..2
playsound block.beacon.activate hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 1.3 1