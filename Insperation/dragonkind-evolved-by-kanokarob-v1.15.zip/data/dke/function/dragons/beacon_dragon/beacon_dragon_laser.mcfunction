# Generated with MC-Build

particle minecraft:electric_spark ^ ^ ^ 0.5 0.5 0.5 0 5 force
execute as @e[type=!#dke:arrow_ignore,distance=..2.5,nbt={HurtTime:0s}] run function dke:dragons/beacon_dragon/beacon_dragon_laser/beacon_laser_hit
execute if block ^ ^ ^ #dke:laser_barrier run return 0
execute if entity @s[distance=75..] run return 0
execute unless entity @s[distance=75..] positioned ^ ^ ^0.49 unless block ^ ^ ^ #dke:laser_barrier run function dke:dragons/beacon_dragon/beacon_dragon_laser