# Generated with MC-Build

playsound minecraft:entity.lightning_bolt.thunder hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1
scoreboard players reset @s dke.time.sound