# Generated with MC-Build

execute if predicate dke:chance/50 run data modify entity @s DragonPhase set value 1
tag @s add dke.attempting_perch