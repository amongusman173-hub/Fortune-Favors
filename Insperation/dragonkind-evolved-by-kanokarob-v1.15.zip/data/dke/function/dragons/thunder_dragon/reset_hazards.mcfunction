# Generated with MC-Build

scoreboard players reset @s dke.time
kill @e[tag=dke.hazard]
kill @e[tag=dke.hazard.center]