# Generated with MC-Build

kill @e[type=area_effect_cloud,tag=dke.cloud,distance=..9]
execute if predicate dke:chance/1 positioned ^ ^ ^-7 positioned over motion_blocking run summon lightning_bolt ~ ~ ~