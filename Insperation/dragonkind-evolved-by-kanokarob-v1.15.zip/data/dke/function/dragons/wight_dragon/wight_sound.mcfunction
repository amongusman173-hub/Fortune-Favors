# Generated with MC-Build

execute store result score @s dke.temp run random value 1..4
execute if score @s dke.temp matches 1 as @a[predicate=dke:dragon_lair] at @s run playsound ambient.cave hostile @s ~ ~ ~ 2 1.3
execute if score @s dke.temp matches 2 as @a[predicate=dke:dragon_lair] at @s run playsound entity.phantom.swoop hostile @s ~ ~ ~ 2 0.45
execute if score @s dke.temp matches 3 as @a[predicate=dke:dragon_lair] at @s run playsound entity.phantom.ambient hostile @s ~ ~ ~ 2 0.45
execute if score @s dke.temp matches 4 as @a[predicate=dke:dragon_lair] at @s run playsound entity.wither.death hostile @s ~ ~ ~ 0.65 0.45
scoreboard players reset @s dke.time.sound