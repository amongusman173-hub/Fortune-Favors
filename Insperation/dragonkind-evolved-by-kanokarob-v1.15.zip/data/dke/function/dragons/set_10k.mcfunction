# Generated with MC-Build

execute if entity @s[type=player] run scoreboard players set $$dke.global dke.next_type 101
function dke:dragons/reset_tag
tag @s[type=minecraft:ender_dragon] add dke.type.10k
data modify entity @s CustomName set value [{"text":"","color":"#f7da63"},{"translate":"dragon.dke.type.10k"}]
data modify entity @s[type=minecraft:ender_dragon] Silent set value 0b
effect clear @s[type=minecraft:ender_dragon]