# Generated with MC-Build

scoreboard players set $$dke.global dke.type 9
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:entity_effect{color:[1.0f,1.0f,1.0f,1.0f]} ~ ~2 ~ 1 1 1 0.05 10 normal
particle minecraft:enchant ~ ~2 ~ 1 0.3 1 0.01 10 normal
#Spellcasting
execute unless entity @s[nbt={DragonPhase:5}] unless entity @s[nbt={DragonPhase:9}] if score @s dke.time matches 140.. if predicate dke:chance/01 run function dke:dragons/elder_dragon/elder_spell_trigger
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/elder_dragon/elder_spell_cast
execute if entity @s[nbt={DragonPhase: 5}] if predicate dke:chance/003 run function dke:dragons/elder_dragon/elder_spell_cast