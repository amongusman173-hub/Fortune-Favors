# Generated with MC-Build

scoreboard players set $$dke.global dke.type 14
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:campfire_cosy_smoke ~ ~2 ~ 1 1 1 0.01 5 normal
particle minecraft:lava ~ ~2 ~ 1 1 1 0.05 1 normal
#Choose power
execute if entity @s[tag=!dke.attack.missiles] if score @s dke.time matches 200..499 if predicate dke:chance/01 run function dke:dragons/artillery_dragon/select_attack
# Missiles
execute if entity @s[tag=dke.attack.missiles] run function dke:dragons/artillery_dragon/fire_missiles
#Use all powers at once
execute if entity @s[tag=!dke.attack.missiles] if score @s dke.time matches 400.. if predicate dke:chance/1 run function dke:dragons/artillery_dragon/all_powers