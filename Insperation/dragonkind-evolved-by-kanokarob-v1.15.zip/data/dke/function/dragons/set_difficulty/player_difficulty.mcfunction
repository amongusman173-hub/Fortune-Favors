# Generated with MC-Build

scoreboard players add @s dke.edk 0
scoreboard players add @s dke.edk 1
scoreboard players operation $$dke.global dke.edk += @s dke.edk