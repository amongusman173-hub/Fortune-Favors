# Generated with MC-Build

tag @s add dke.10k.lasers
function dke:dragons/10k_dragon/10k_dragon_power/shockwave_start
execute if entity @a[predicate=dke:flying,predicate=dke:dragon_lair] as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/shared_behavior/attack_generic/ground_flying_players
scoreboard players reset @s dke.time