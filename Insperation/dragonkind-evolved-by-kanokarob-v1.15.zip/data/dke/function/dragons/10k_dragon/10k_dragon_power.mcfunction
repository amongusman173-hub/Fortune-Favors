# Generated with MC-Build

execute store result score @s dke.temp run random value 1..2
#Ground Players
execute if entity @a[predicate=dke:flying,predicate=dke:dragon_lair] as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/shared_behavior/attack_generic/ground_flying_players
#Lasers
execute if score @s dke.temp matches 1 run function dke:dragons/10k_dragon/10k_dragon_power/laser_start
# Shockwave
execute if score @s dke.temp matches 2 run function dke:dragons/10k_dragon/10k_dragon_power/shockwave_start
#Reset
scoreboard players reset @s dke.time