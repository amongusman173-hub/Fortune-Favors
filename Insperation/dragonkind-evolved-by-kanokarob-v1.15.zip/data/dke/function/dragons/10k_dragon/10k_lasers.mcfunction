# Generated with MC-Build

particle minecraft:dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~ ~ 0.3 0.3 0.3 0 2
execute if score @s dke.time matches 100.. if predicate dke:chance/05 run function dke:dragons/10k_dragon/10k_lasers/end
execute if entity @a[distance=..1] run function dke:dragons/10k_dragon/10k_lasers/hit
execute if entity @a[distance=..1] run return fail
execute if entity @s[distance=150..] run return run function dke:dragons/10k_dragon/10k_lasers/hit
execute positioned ^ ^ ^0.99 if block ~ ~ ~ #dke:laser_barrier run return run function dke:dragons/10k_dragon/10k_lasers/hit
execute unless entity @s[distance=150..] positioned ^ ^ ^0.99 run return run function dke:dragons/10k_dragon/10k_lasers