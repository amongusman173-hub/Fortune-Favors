# Generated with MC-Build

execute as @a[predicate=dke:dragon_lair] at @s run playsound minecraft:entity.ender_dragon.shoot hostile @s ~ ~ ~ 1.2 1.15 1
execute positioned 0 ~ 0 positioned over motion_blocking align xyz run summon minecraft:marker ~0.5 ~0.5 ~0.5 {Tags:[dke.entity,dke.ticking,dke.shockwave.center,smithed.entity,smithed.strict]}
execute facing entity @n[type=minecraft:marker,tag=dke.shockwave.center,predicate=dke:dragon_lair,distance=..150] feet summon minecraft:marker run function dke:dragons/10k_dragon/10k_dragon_power/shockwave_start/summon_projectile