# Generated with MC-Build

data merge entity @s {Tags:[dke.entity,dke.projectile,dke.projectile.shockwave,dke.ticking,smithed.entity,smithed.strict]}
rotate @s ~ ~