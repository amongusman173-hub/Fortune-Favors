# Generated with MC-Build

tag @s add dke.10k.lasers
execute as @a[predicate=dke:dragon_lair] at @s run playsound minecraft:item.totem.use hostile @s ~ ~ ~ 0.45 1.7