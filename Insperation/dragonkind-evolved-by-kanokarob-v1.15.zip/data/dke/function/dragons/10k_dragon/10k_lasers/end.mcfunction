# Generated with MC-Build

tag @s remove dke.10k.lasers
scoreboard players reset @s dke.time