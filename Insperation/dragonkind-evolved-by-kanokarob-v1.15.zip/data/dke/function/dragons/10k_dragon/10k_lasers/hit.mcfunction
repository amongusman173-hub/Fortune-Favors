# Generated with MC-Build

particle minecraft:totem_of_undying ~ ~ ~ 0.5 0.5 0.5 0.05 10 normal
playsound minecraft:block.beacon.power_select hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 0.8 2
execute as @a[distance=..4,predicate=dke:on_ground] run damage @s 3.0 minecraft:magic by @n[tag=dke.type.10k]