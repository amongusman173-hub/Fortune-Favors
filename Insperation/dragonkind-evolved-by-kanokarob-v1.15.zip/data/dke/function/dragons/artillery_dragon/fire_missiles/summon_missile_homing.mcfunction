# Generated with MC-Build

data merge entity @s {Tags:[dke.projectile,dke.projectile.missile,dke.missile.homing,dke.entity,dke.ticking,dke.requires_dragon,smithed.entity,smithed.strict],item:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:item_model":"dke:missile"}},teleport_duration:1,transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[2f,2f,2f],right_rotation:[0f,0f,0f,1f]}}
rotate @s ~ ~