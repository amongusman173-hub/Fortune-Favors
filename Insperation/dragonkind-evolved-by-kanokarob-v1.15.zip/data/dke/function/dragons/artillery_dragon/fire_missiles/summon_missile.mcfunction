# Generated with MC-Build

data merge entity @s {Tags:[dke.projectile,dke.projectile.missile,dke.entity,dke.ticking,dke.requires_dragon,smithed.entity,smithed.strict],item:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:item_model":"dke:missile"}},teleport_duration:1,transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[2f,2f,2f],right_rotation:[0f,0f,0f,1f]}}
rotate @s ~ ~
execute as @a[predicate=dke:dragon_lair] at @s run playsound minecraft:entity.firework_rocket.launch hostile @s ~ ~ ~ 1 0.65
particle minecraft:large_smoke ~ ~ ~ 0.5 0.5 0.5 0.05 10 force