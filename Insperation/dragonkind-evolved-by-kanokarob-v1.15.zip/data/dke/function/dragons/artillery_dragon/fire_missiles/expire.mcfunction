# Generated with MC-Build

tag @s remove dke.attack.missiles
scoreboard players reset @s dke.time