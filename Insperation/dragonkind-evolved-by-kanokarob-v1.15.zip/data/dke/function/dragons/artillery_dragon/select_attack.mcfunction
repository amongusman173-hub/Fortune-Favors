# Generated with MC-Build

#Reset
scoreboard players reset @s dke.time
# Landmines
execute unless entity @e[type=minecraft:item_display,tag=dke.landmine,predicate=dke:dragon_lair] run function dke:dragons/artillery_dragon/select_attack/place_landmines
# Missiles
execute if entity @e[type=minecraft:item_display,tag=dke.landmine,predicate=dke:dragon_lair] run tag @s add dke.attack.missiles