# Generated with MC-Build

execute if score @s dke.time matches 30 rotated 0 -90 summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile
execute if score @s dke.time matches 35 rotated 72 -90 summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile
execute if score @s dke.time matches 40 rotated 144 -90 summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile
execute if score @s dke.time matches 45 rotated 216 -90 summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile
execute if score @s dke.time matches 50 rotated 288 -90 summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile
execute if score @s dke.time matches 55 facing entity @a[predicate=dke:flying,predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] feet summon minecraft:item_display run function dke:dragons/artillery_dragon/fire_missiles/summon_missile_homing
execute if score @s dke.time matches 55.. run function dke:dragons/artillery_dragon/fire_missiles/expire