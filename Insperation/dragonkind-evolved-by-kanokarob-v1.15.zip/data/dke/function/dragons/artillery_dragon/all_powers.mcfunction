# Generated with MC-Build

kill @e[type=minecraft:item_display,tag=dke.landmine,predicate=dke:dragon_lair]
function dke:dragons/artillery_dragon/select_attack/place_landmines
tag @s add dke.attack.missiles
scoreboard players reset @s dke.time