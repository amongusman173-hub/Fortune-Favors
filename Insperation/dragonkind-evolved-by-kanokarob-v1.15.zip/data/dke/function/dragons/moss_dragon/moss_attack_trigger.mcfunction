# Generated with MC-Build

scoreboard players reset @s dke.time
execute store result score @s dke.temp run random value 1..5
# Summon Moss Servants
execute if score @s dke.temp matches 4..5 run function dke:dragons/moss_dragon/moss_attack_trigger/moss_servants_select
# Bounce players
execute if score @s dke.temp matches 1..3 as @a[predicate=dke:dragon_lair,predicate=!dke:flying,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/moss_dragon/moss_attack_trigger/bounce_players