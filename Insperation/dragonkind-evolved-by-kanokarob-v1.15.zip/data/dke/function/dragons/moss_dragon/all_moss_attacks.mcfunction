# Generated with MC-Build

scoreboard players reset @s dke.time
function dke:dragons/moss_dragon/moss_attack_trigger/moss_servants_select
execute as @a[predicate=dke:dragon_lair,predicate=!dke:flying,gamemode=!creative,gamemode=!spectator] at @s run function dke:dragons/moss_dragon/moss_attack_trigger/bounce_players