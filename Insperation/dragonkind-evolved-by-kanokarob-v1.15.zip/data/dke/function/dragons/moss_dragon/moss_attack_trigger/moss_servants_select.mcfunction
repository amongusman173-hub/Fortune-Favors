# Generated with MC-Build

tag @s add dke.charging
playsound minecraft:entity.ravager.roar hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65