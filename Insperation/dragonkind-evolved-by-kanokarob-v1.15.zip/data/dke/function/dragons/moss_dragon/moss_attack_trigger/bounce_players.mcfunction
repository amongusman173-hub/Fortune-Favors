# Generated with MC-Build

particle minecraft:item_slime ~ ~0.2 ~ 0.5 0.1 0.5 0.02 10 normal
particle minecraft:spore_blossom_air ~ ~0.2 ~ 0.5 0.1 0.5 0.01 5 normal
playsound minecraft:entity.ravager.stunned hostile @s ~ ~ ~ 1 1.15
playsound minecraft:entity.slime.jump hostile @s ~ ~ ~ 1 0.85
effect give @s minecraft:levitation 1 20 true
damage @s 3.0 minecraft:wind_charge by @n[type=minecraft:ender_dragon,predicate=dke:dragon_lair,tag=dke.entity]