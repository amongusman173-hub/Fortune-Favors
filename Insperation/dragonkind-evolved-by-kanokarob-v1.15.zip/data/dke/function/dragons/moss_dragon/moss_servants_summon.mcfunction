# Generated with MC-Build

scoreboard players reset @s dke.time
tag @s remove dke.charging
playsound minecraft:entity.ravager.attack hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
playsound minecraft:entity.frog.death hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
particle minecraft:falling_spore_blossom ~ ~2 ~ 1.5 1.5 1.5 0.1 50 force
particle minecraft:tinted_leaves{color:-11550937} ~ ~2 ~ 1.5 1.5 1.5 0.05 25 force
execute at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:spawns/summon_moss_servants