# Generated with MC-Build

scoreboard players set $$dke.global dke.type 5
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:snowflake ~ ~2 ~ 1 1 1 0.05 10 normal
execute positioned over motion_blocking run place feature dke:frost_patch
#Summon Igloo
execute if score @s dke.time matches 150.. if predicate dke:chance/01 run function dke:dragons/frost_dragon/summon_igloo