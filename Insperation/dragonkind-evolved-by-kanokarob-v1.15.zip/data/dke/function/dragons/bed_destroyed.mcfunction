# Generated with MC-Build

particle minecraft:block{block_state: "minecraft:white_bed"} ~ ~-3 ~ 1 0.3 1 0.05 10 normal
playsound entity.wither.break_block hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1.4
scoreboard players reset @s dke.success