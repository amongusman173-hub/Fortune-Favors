# Generated with MC-Build

scoreboard players reset @s dke.time
tag @s remove dke.charging
playsound entity.zombie.ambient hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
particle minecraft:falling_spore_blossom ~ ~2 ~ 1.5 1.5 1.5 0.1 50 force
particle minecraft:dust{color:[0.141,0.486,0.243],scale:1.5} ~ ~2 ~ 1.5 1.5 1.5 0.1 50 force
execute at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:spawns/summon_zombie_servants