# Generated with MC-Build

scoreboard players set $$dke.global dke.type 2
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:spore_blossom_air ~ ~2 ~ 1 0.1 1 0 10 normal
execute positioned over motion_blocking run place feature dke:moss_patch
#Attack
execute if entity @s[nbt={DragonPhase:0}] if score @s dke.time matches 300.. if predicate dke:chance/01 run function dke:dragons/moss_dragon/moss_attack_trigger
execute if entity @s[nbt={DragonPhase:0}] if score @s dke.time matches 400.. run function dke:dragons/moss_dragon/all_moss_attacks
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/moss_dragon/moss_servants_summon