# Generated with MC-Build

playsound minecraft:entity.generic.burn hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 1.1 1
playsound entity.ender_dragon.shoot hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.3 1
execute facing entity @a[predicate=dke:dragon_lair,limit=1,sort=nearest,gamemode=!spectator] feet positioned ^ ^ ^4 run function dke:dragons/desert_dragon/shoot_fireball/spawn_fireball_projectile