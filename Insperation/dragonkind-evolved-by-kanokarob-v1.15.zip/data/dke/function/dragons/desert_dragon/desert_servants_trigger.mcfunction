# Generated with MC-Build

tag @s add dke.charging
scoreboard players reset @s dke.time
playsound entity.blaze.ambient hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85