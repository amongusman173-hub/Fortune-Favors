# Generated with MC-Build

summon item_display ~ ~ ~ {Tags:[dke.projectile,dke.projectile.fireball,dke.entity,dke.ticking,dke.requires_dragon,smithed.entity,smithed.strict],item:{id:"minecraft:fire_charge",count:1},brightness:{block:15,sky:15},teleport_duration:1,billboard:"fixed",transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[2f,2f,2f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~ ~ ~ as @n[tag=dke.projectile.fireball,tag=!dke.marked] run tp @s ~ ~ ~ ~ ~