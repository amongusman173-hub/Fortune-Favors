# Generated with MC-Build

scoreboard players reset @s dke.time
tag @s remove dke.charging
playsound entity.blaze.death hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85
playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
particle minecraft:falling_dust{block_state:"minecraft:sand"} ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
particle minecraft:lava ~ ~2 ~ 1.5 1.5 1.5 0.1 5 force
execute at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:spawns/summon_desert_servants