# Generated with MC-Build

# Determine average of and increment number of dragons killed
scoreboard players set $$dke.global dke.edk 0
execute store result score @s dke.temp if entity @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator]
execute if score @s dke.temp matches 0 store result score @s dke.temp if entity @a[predicate=dke:dragon_lair,gamemode=!survival,gamemode=!adventure]
execute as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] run function dke:dragons/set_difficulty/player_difficulty
execute if score $$dke.global dke.edk matches 0 as @a[predicate=dke:dragon_lair,gamemode=!survival,gamemode=!adventure] run function dke:dragons/set_difficulty/player_difficulty
scoreboard players operation $$dke.global dke.edk /= @s dke.temp
scoreboard players operation @s dke.edk = $$dke.global dke.edk
# Set Ominous status
execute if entity @a[predicate=dke:dragon_lair,predicate=dke:bad_omen] run scoreboard players set $$dke.global dke.ominous 1
effect clear @a[predicate=dke:dragon_lair] bad_omen
scoreboard players operation @s dke.ominous = $$dke.global dke.ominous
# Set difficulty
execute if predicate dke:scores/edk_easy run scoreboard players set @s dke.difficulty 1
execute if predicate dke:scores/edk_med run scoreboard players set @s dke.difficulty 2
execute if predicate dke:scores/edk_hard run scoreboard players set @s dke.difficulty 3
execute if predicate dke:scores/edk_immortal run scoreboard players set @s dke.difficulty 4
execute if predicate dke:scores/edk_ferocious run scoreboard players set @s dke.difficulty 5
execute if predicate dke:scores/edk_primordial run scoreboard players set @s dke.difficulty 6
execute if score @s dke.ominous matches 1 run scoreboard players add @s dke.difficulty 1
# Exceptions
execute if score $$dke.total dke.edk matches 1 run scoreboard players set @s dke.difficulty 1
execute if score $$dke.total dke.edk matches 20 run scoreboard players set @s dke.difficulty 4
execute if score $$dke.total dke.edk matches 30 run scoreboard players set @s dke.difficulty 5
# Set globally
scoreboard players operation $$dke.global dke.difficulty = @s dke.difficulty