# Generated with MC-Build

scoreboard players set $$dke.global dke.type 101
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:falling_dust{block_state:"minecraft:glowstone"} ~ ~2 ~ 1 1 1 0.05 5 normal
particle minecraft:dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~2 ~ 1 1 1 0.05 5 normal
execute positioned over motion_blocking run place feature dke:gold_patch
#Choose power
execute if entity @s[tag=!dke.10k.lasers] if predicate dke:generic_flight if score @s dke.time matches 100..299 if predicate dke:chance/01 run function dke:dragons/10k_dragon/10k_dragon_power
#Lasers
execute if entity @s[tag=dke.10k.lasers] facing entity @a[predicate=dke:dragon_lair,limit=5,sort=nearest,gamemode=!spectator] feet positioned ^ ^ ^0.99 run function dke:dragons/10k_dragon/10k_lasers
#Use all powers at once
execute if entity @s[tag=!dke.10k.lasers] if predicate dke:generic_flight if score @s dke.time matches 300.. if predicate dke:chance/1 run function dke:dragons/10k_dragon/all_10k_powers