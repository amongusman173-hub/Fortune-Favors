# Generated with MC-Build

scoreboard players set $$dke.global dke.type 8
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:flame ~ ~2 ~ 1 0.3 1 0.05 10 normal
execute positioned over motion_blocking run place feature dke:fire_patch
#Summon Blaze Servants
execute unless predicate dke:landing_phases if score @s dke.time matches 500.. if predicate dke:chance/01 run function dke:dragons/nether_dragon/nether_servants_trigger
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/nether_dragon/nether_servants_summon
execute if predicate dke:landing_phases unless entity @s[nbt={DragonPhase: 9}] if predicate dke:chance/003 unless entity @e[tag=dke.mob.nether_servant,predicate=dke:dragon_lair] at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:dragons/nether_servants_summon
#Phase control
execute unless entity @s[nbt={DragonPhase: 1}] unless entity @s[nbt={DragonPhase: 9}] if predicate dke:chance/003 run data modify entity @s DragonPhase set value 1