# Generated with MC-Build

#Set stats and determine type
execute store result score @s dke.max_health run attribute @s minecraft:max_health base set 850.0
data modify entity @s Health set value 850.0f
execute unless score $$dke.global dke.next_type matches 0.. store result score @s dke.type run random value 1..13
execute unless score $$dke.global dke.next_type matches 0.. if score @s dke.type matches 1..10 if predicate dke:chance/20 store result score @s dke.type run random value 9..13
execute if score $$dke.total dke.edk matches 20 run scoreboard players set @s dke.type 100
execute if score $$dke.total dke.edk matches 30 run scoreboard players set @s dke.type 101
execute if score $$dke.global dke.next_type matches 0.. run scoreboard players operation @s dke.type = $$dke.global dke.next_type
function dke:dragons/dragon_buff_easy/assign_tag
#Set name
execute if entity @s[tag=dke.type.vanilla] run data modify entity @s CustomName set value [{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"entity.minecraft.ender_dragon"}]
execute if entity @s[tag=dke.type.zombie] run data modify entity @s CustomName set value [{"text":"","color":"#428c47"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.zombie"}]
execute if entity @s[tag=dke.type.moss] run data modify entity @s CustomName set value [{"text":"","color":"green"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.moss"}]
execute if entity @s[tag=dke.type.warped] run data modify entity @s CustomName set value [{"text":"","color":"#2dc2ba"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.warped"}]
execute if entity @s[tag=dke.type.sculk] run data modify entity @s CustomName set value [{"text":"","color":"aqua"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.sculk"}]
execute if entity @s[tag=dke.type.frost] run data modify entity @s CustomName set value [{"text":"","color":"blue"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.frost"}]
execute if entity @s[tag=dke.type.tyrant] run data modify entity @s CustomName set value [{"text":"","color":"dark_gray"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.tyrant"}]
execute if entity @s[tag=dke.type.skeletal] run data modify entity @s CustomName set value [{"text":"","color":"#fff8de"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.skeletal"}]
execute if entity @s[tag=dke.type.nether] run data modify entity @s CustomName set value [{"text":"","color":"gold"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.nether"}]
execute if entity @s[tag=dke.type.elder] run data modify entity @s CustomName set value [{"text":"","color":"dark_purple"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.elder"}]
execute if entity @s[tag=dke.type.wight] run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.wight"}]
execute if entity @s[tag=dke.type.beacon] run data modify entity @s CustomName set value [{"text":"","color":"#b8feff"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.beacon"}]
execute if entity @s[tag=dke.type.desert] run data modify entity @s CustomName set value [{"text":"","color":"#ffebb5"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.desert"}]
execute if entity @s[tag=dke.type.thunder] run data modify entity @s CustomName set value [{"text":"","color":"#9ebdff"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.thunder"}]
execute if entity @s[tag=dke.type.artillery] run data modify entity @s CustomName set value [{"text":"","color":"gray"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.artillery"}]
execute if entity @s[tag=dke.type.last] run data modify entity @s CustomName set value [{"text":"","color":"light_purple"},{"translate":"dragon.dke.type.last"}]
execute if entity @s[tag=dke.type.10k] run data modify entity @s CustomName set value [{"text":"","color":"#f7da63"},{"translate":"dragon.dke.type.10k"}]