# Generated with MC-Build

scoreboard players add @s dke.time.generic 0
# Select attack
execute if score @s dke.difficulty matches 1 if score @s dke.time.generic matches 100.. if predicate dke:chance/003 run function dke:dragons/shared_behavior/attack_generic
execute if score @s dke.difficulty matches 2 if score @s dke.time.generic matches 200.. if predicate dke:chance/01 run function dke:dragons/shared_behavior/attack_generic
execute if score @s dke.difficulty matches 3.. if score @s dke.time.generic matches 100.. if predicate dke:chance/01 run function dke:dragons/shared_behavior/attack_generic
#Slam
execute if entity @s[tag=dke.attack.slam] run function dke:dragons/shared_behavior/slam
# Meteors
execute if entity @s[tag=dke.attack.meteors] run function dke:dragons/shared_behavior/meteors
# Increment time
scoreboard players add @s dke.time.generic 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time.generic 1