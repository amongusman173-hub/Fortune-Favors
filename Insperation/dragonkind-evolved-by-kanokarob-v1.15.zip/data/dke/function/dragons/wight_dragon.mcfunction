# Generated with MC-Build

scoreboard players set $$dke.global dke.type 10
scoreboard players add @s dke.time.sound 0
scoreboard players add @s dke.time.sound 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
execute unless entity @s[nbt={DragonPhase:9}] unless entity @s[tag=dke.attack.slam] run tp @s ^ ^ ^-0.77
particle minecraft:end_rod ~ ~2 ~ 1 1 1 0.05 5 normal
#Sounds
execute if predicate dke:wight_phases if score @s dke.time.sound matches 100.. if predicate dke:chance/01 run function dke:dragons/wight_dragon/wight_sound
#Phase control
execute unless entity @s[nbt={DragonPhase:1}] unless entity @s[nbt={DragonPhase:9}] if predicate dke:chance/003 run data modify entity @s DragonPhase set value 1
execute unless entity @s[nbt={DragonPhase:1}] unless entity @s[nbt={DragonPhase:9}] if predicate dke:chance/01 run data modify entity @s DragonPhase set value 8
execute unless predicate dke:wight_phases run data modify entity @s DragonPhase set value 0
execute if entity @s[nbt={DragonPhase:9}] run data modify entity @s Silent set value 0b