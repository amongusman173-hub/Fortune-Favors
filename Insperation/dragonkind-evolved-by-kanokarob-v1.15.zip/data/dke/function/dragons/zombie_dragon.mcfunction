# Generated with MC-Build

scoreboard players set $$dke.global dke.type 1
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:entity_effect{color:-11960273} ~ ~2 ~ 1 1 1 0 10 normal
execute positioned over motion_blocking run place feature dke:mud_patch
#Summon Zombie Servants
execute if entity @s[nbt={DragonPhase:0}] if score @s dke.time matches 500.. if predicate dke:chance/01 run function dke:dragons/zombie_dragon/zombie_servants_trigger
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/zombie_dragon/zombie_servants_summon