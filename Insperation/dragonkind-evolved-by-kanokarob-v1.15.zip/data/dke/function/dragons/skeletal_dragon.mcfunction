# Generated with MC-Build

scoreboard players set $$dke.global dke.type 7
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:soul_fire_flame ~ ~2 ~ 1 1 1 0.05 10 normal
#Regeneration
execute unless score $$dke.global dke.has_end_crystals matches 1.. if predicate dke:chance/01 unless score @s dke.health >= @s dke.max_health unless entity @e[tag=dke.mob.skeletal_servant,predicate=dke:dragon_lair] store result entity @s Health float 1 run scoreboard players operation @s dke.health += @s dke.difficulty
#Invulnerability
execute if entity @s[nbt={Invulnerable:0b}] if entity @e[tag=dke.mob.skeletal_servant,predicate=dke:dragon_lair] run data modify entity @s Invulnerable set value 1b
execute if entity @s[nbt={Invulnerable:1b}] unless entity @e[tag=dke.mob.skeletal_servant,predicate=dke:dragon_lair] run data modify entity @s Invulnerable set value 0b
#Perching
execute if predicate dke:generic_flight if score @s dke.time matches 100.. if predicate dke:chance/01 run function dke:dragons/warped_dragon/warped_perch
#Summon Skeletal Servants
execute if predicate dke:landing_phases if score @s dke.health matches 81.. if predicate dke:chance/003 positioned 0 0 0 positioned over motion_blocking unless entity @e[tag=dke.mob.skeletal_servant,distance=..40] run function dke:dragons/skeletal_dragon/skeletal_servants_summon