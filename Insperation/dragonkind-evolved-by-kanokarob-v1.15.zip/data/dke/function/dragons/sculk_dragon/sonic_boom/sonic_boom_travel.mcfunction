# Generated with MC-Build

particle minecraft:sonic_boom ~ ~ ~ 0 0 0 0 1
execute if entity @a[distance=..3] run function dke:dragons/sculk_dragon/sonic_boom/sonic_boom_travel/sonic_boom_hit
execute if entity @s[distance=150..] run return run function dke:dragons/sculk_dragon/sonic_boom/sonic_boom_travel/sonic_boom_hit
execute positioned ^ ^ ^0.99 if block ~ ~ ~ #dke:laser_barrier run return run function dke:dragons/sculk_dragon/sonic_boom/sonic_boom_travel/sonic_boom_hit
execute positioned ^ ^ ^0.99 run function dke:dragons/sculk_dragon/sonic_boom/sonic_boom_travel