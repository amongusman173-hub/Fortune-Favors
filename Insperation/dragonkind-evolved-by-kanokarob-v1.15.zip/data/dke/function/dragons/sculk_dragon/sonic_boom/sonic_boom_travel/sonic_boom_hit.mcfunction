# Generated with MC-Build

particle minecraft:explosion ~ ~ ~ 0.5 0.5 0.5 0 20 normal
playsound entity.generic.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.2
playsound minecraft:entity.warden.sonic_boom block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 0.85
execute as @a[distance=..4,predicate=dke:on_ground] run damage @s 7.0 minecraft:magic by @n[type=minecraft:ender_dragon,tag=dke.type.sculk]
scoreboard players reset @s dke.time