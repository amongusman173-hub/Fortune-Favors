# Generated with MC-Build

scoreboard players reset @s dke.time
tag @s remove dke.charging
# Cosmetic
playsound minecraft:entity.warden.sonic_boom hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85 1
playsound minecraft:entity.warden.roar hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85 1
particle minecraft:sculk_soul ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
particle minecraft:sculk_charge_pop ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
# Raycast
execute facing entity @p[gamemode=!creative,gamemode=!spectator,predicate=dke:dragon_lair,predicate=dke:on_ground,tag=!dke.grounded] feet positioned ^ ^ ^0.99 run function dke:dragons/sculk_dragon/sonic_boom/sonic_boom_travel