# Generated with MC-Build

tag @s add dke.charging
scoreboard players reset @s dke.time
playsound minecraft:entity.warden.sonic_charge hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85 1