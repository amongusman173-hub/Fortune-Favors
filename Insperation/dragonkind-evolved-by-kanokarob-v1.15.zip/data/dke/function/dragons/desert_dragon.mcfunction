# Generated with MC-Build

scoreboard players set $$dke.global dke.type 12
scoreboard players add @s dke.state 0
scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.ominous matches 1 if predicate dke:chance/50 run scoreboard players add @s dke.time 1
particle minecraft:falling_dust{block_state:"minecraft:sand"} ~ ~2 ~ 1 1 1 0.05 10 normal
execute positioned over motion_blocking run place feature dke:desert_patch
#Summon Hoglin Servants
execute unless entity @s[nbt={DragonPhase:5}] if score @s dke.time matches 500.. if predicate dke:chance/01 run function dke:dragons/desert_dragon/desert_servants_trigger
execute if entity @s[tag=dke.charging] if score @s dke.time matches 60.. run function dke:dragons/desert_dragon/desert_servants_summon
execute if entity @s[nbt={DragonPhase: 5}] if predicate dke:chance/003 unless entity @e[tag=dke.mob.desert_servant,distance=..25] at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:dragons/desert_servants_summon
# Shoot fireballs
execute if predicate dke:generic_flight unless score @s dke.ominous matches 1 if predicate dke:chance/01 run function dke:dragons/desert_dragon/shoot_fireball
execute if predicate dke:generic_flight if score @s dke.ominous matches 1 if predicate dke:chance/03 run function dke:dragons/desert_dragon/shoot_fireball