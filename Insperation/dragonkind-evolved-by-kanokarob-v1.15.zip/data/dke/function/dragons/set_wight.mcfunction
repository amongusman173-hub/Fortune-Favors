# Generated with MC-Build

execute if entity @s[type=player] run scoreboard players set $$dke.global dke.next_type 10
function dke:dragons/reset_tag
tag @s[type=minecraft:ender_dragon] add dke.type.wight
execute if predicate dke:scores/edk_easy run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.fledgeling"},{"translate":"dragon.dke.type.wight"}]
execute if predicate dke:scores/edk_med run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.powerful"},{"translate":"dragon.dke.type.wight"}]
execute if predicate dke:scores/edk_hard run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.cruel"},{"translate":"dragon.dke.type.wight"}]
execute if predicate dke:scores/edk_immortal run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.immortal"},{"translate":"dragon.dke.type.wight"}]
execute if predicate dke:scores/edk_ferocious run data modify entity @s CustomName set value [{"text":"","color":"#ffe0fe"},{"translate":"dragon.dke.difficulty.ferocious"},{"translate":"dragon.dke.type.wight"}]
data modify entity @s[type=minecraft:ender_dragon] Silent set value 1b
effect clear @s[type=minecraft:ender_dragon]