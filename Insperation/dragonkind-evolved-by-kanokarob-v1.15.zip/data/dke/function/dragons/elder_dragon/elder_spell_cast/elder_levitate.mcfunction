# Generated with MC-Build

particle minecraft:poof ~ ~0.3 ~ 0.3 0.3 0.3 0.01 10 normal
particle minecraft:enchant ~ ~0.3 ~ 0.3 0.3 0.3 0.05 10 normal
playsound entity.shulker.shoot hostile @s ~ ~ ~ 1 1.3
playsound entity.evoker.cast_spell hostile @s ~ ~ ~ 1 1.3
effect give @s levitation 2 12 true