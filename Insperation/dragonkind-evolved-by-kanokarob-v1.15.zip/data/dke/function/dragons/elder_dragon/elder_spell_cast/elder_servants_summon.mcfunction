# Generated with MC-Build

particle minecraft:enchant ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
particle minecraft:totem_of_undying ~ ~2 ~ 1.5 1.5 1.5 0.1 30 force
execute at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run function dke:spawns/elder_servants