# Generated with MC-Build

playsound entity.evoker.cast_spell hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.85
playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 5 0.65
execute unless entity @e[tag=dke.mob.elder_servant] store result score @s dke.temp run random value 1..3
execute if entity @e[tag=dke.mob.elder_servant] store result score @s dke.temp run random value 2..3
#Summon Vex servants
execute if score @s dke.temp matches 1 run function dke:dragons/elder_dragon/elder_spell_cast/elder_servants_summon
#Summon Evoker Fangs
execute if score @s dke.temp matches 2 at @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] run summon marker ~ ~ ~ {Tags: [dke.evoker_fang.origin,dke.entity.technical,dke.entity,dke.ticking,dke.requires_dragon]}
#Levitate 3 random players
execute if score @s dke.temp matches 3 as @a[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator,limit=3,sort=random] at @s if entity @s[predicate=dke:on_ground] run function dke:dragons/elder_dragon/elder_spell_cast/elder_levitate
scoreboard players reset @s dke.temp
scoreboard players reset @s dke.time
tag @s remove dke.charging