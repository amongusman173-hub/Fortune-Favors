# Generated with MC-Build

execute at @a[predicate=dke:dragon_lair] run playsound entity.ender_dragon.growl hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 0.85 1.45
execute at @a[predicate=dke:dragon_lair] run playsound block.snow.break hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 0.85
particle minecraft:snowflake ~ ~2 ~ 1 1 1 0.1 20 force
particle minecraft:block{block_state: "minecraft:ice"} ~ ~2 ~ 1 1 1 0.1 30 force
scoreboard players reset @s dke.temp
execute store result score @s dke.temp run random value 1..3
#Choose Player
execute if score @s dke.temp matches 1 at @a[predicate=dke:dragon_lair,predicate=!dke:near_portal,limit=3,sort=random,gamemode=!creative,gamemode=!spectator] run function dke:dragons/frost_dragon/summon_igloo/place_igloo
execute if score @s dke.temp matches 1 unless entity @s[tag=dke.igloo_summoned] run scoreboard players add @s dke.temp 1
#Choose Fountain
execute if score @s dke.temp matches 2 unless predicate dke:near_portal positioned 0 0 0 positioned over motion_blocking unless block ~ ~-1 ~ packed_ice positioned ~ ~-3 ~ run function dke:dragons/frost_dragon/summon_igloo/place_igloo
execute if score @s dke.temp matches 2 unless entity @s[tag=dke.igloo_summoned] run scoreboard players add @s dke.temp 1
#Choose Crystals
execute if score @s dke.temp matches 3 at @e[type=minecraft:end_crystal,tag=dke.entity,predicate=!dke:end_crystal/caged,limit=3,sort=random] positioned ~ ~-1 ~ run function dke:dragons/frost_dragon/summon_igloo/place_igloo
#Reset scores
tag @s remove dke.igloo_summoned
scoreboard players reset @s dke.time