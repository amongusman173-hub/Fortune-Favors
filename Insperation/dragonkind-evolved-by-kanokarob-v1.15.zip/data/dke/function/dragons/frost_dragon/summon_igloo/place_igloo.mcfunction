# Generated with MC-Build

tag @s add dke.igloo_summoned
place template dke:igloo ~-4 ~ ~-4 none
particle minecraft:snowflake ~ ~2 ~ 2 2 2 0.05 20 normal
particle minecraft:block{block_state: "minecraft:ice"} ~ ~2 ~ 2 2 2 0.05 30 normal
playsound entity.dragon_fireball.explode hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 3 1.7
playsound block.glass.break hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.3
summon marker ~ ~ ~ {Tags: [dke.igloo,dke.entity,dke.ticking,dke.entity.technical,smithed.entity,smithed.strict]}