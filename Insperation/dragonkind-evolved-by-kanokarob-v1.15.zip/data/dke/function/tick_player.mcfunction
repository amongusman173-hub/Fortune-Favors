# Generated with MC-Build

#Wstick
scoreboard players add @s dke.cooldown 0
execute if score @s dke.cooldown matches 1.. run scoreboard players remove @s dke.cooldown 1
execute if score @s dke.w_stick matches 1.. unless score @s dke.cooldown matches 1.. run function dke:items/w_stick
scoreboard players reset @s dke.w_stick
#Pillaring Enchantment
execute if predicate dke:enchantments/pillaring anchored eyes run function dke:enchantments/pillaring
scoreboard players reset @s dke.pickaxe
execute unless predicate dke:enchantments/pillaring run scoreboard players reset @s dke.pickaxe_count
#Draconic Scepter Charging
execute if entity @s[tag=dke.scepter_charging] run function dke:items/draconic_scepter_charge