# Generated with MC-Build

#Thunder
execute if entity @s[tag=dke.hazard.thunder] run function dke:tick_entities/hazards/thunder