# Generated with MC-Build

fill ~-8 ~-3 ~-8 ~8 ~3 ~8 air replace #dke:remove_features
fill ~-8 ~-3 ~-8 ~8 ~3 ~8 end_stone replace #dke:end_ground
particle dragon_breath ~ ~ ~ 3 0.5 3 0.05 10 normal