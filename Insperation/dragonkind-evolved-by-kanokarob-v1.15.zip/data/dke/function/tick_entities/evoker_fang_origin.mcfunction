# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.time matches 31 run function dke:spawns/elder_fang
execute if score @s dke.time matches 26 run function dke:tick_entities/evoker_fang_origin/evoker_fang_ring_1
execute if score @s dke.time matches 21 run function dke:tick_entities/evoker_fang_origin/evoker_fang_ring_2
execute if score @s dke.time matches 16 run function dke:tick_entities/evoker_fang_origin/evoker_fang_ring_3
execute if score @s dke.time matches 11 run function dke:tick_entities/evoker_fang_origin/evoker_fang_ring_4
execute if score @s dke.time matches 6 run function dke:tick_entities/evoker_fang_origin/evoker_fang_ring_5