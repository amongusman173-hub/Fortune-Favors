# Generated with MC-Build

execute if block ~ ~ ~ air run kill @s
execute positioned ~-24 ~-24 ~-24 unless entity @a[predicate=dke:enchantments/dragonsight,dx=48,dy=48,dz=48] run kill @s