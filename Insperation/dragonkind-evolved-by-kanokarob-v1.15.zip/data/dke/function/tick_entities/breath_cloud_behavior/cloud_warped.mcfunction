# Generated with MC-Build

execute unless entity @e[tag=dke.cloud_copy,distance=..1] summon area_effect_cloud run data merge entity @s {Tags: [dke.cloud, dke.cloud_copy, dke.entity, dke.requires_dragon], potion_contents:{custom_effects: [{id: "minecraft:poison", duration: 100}, {id: "minecraft:slowness", duration: 200}]}, RadiusPerTick: 0.0f, Duration: 12000, DurationOnUse: 0, RadiusOnUse: 0.0f, Radius: 5.0f, WaitTime: 20, ReapplicationDelay: 1, custom_particle: {type:"minecraft:dust",color:[0.157f,0.557f,0.511f],scale:1.2f}}
kill @s