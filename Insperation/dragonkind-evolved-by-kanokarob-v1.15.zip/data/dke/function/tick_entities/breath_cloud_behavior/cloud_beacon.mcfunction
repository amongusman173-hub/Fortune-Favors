# Generated with MC-Build

data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:instant_damage"}, {id: "minecraft:glowing", duration: 200}]}, custom_particle: {type:"minecraft:end_rod"}}
execute positioned ~-2.5 ~-0.5 ~2.5 if entity @a[dx=5,dy=1,dz=5] as @e[type=minecraft:enderman,distance=..20] run damage @s 0.0 player_attack by @a[dx=5,dy=1,dz=5,limit=1,sort=random]