# Generated with MC-Build

# Change properties
execute if score $$dke.global dke.type matches 1 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:hunger", duration: 100}, {id: "minecraft:nausea", duration: 200}]}, RadiusPerTick: 0.015f, custom_particle: {type:"minecraft:sneeze"}}
execute if score $$dke.global dke.type matches 2 run data merge entity @s {potion_contents:{custom_effects: [{id:"minecraft:poison",duration: 200},{id:"minecraft:weakness",duration:100},{id:"minecraft:oozing",duration:600}]},RadiusPerTick: 0.015f,custom_particle:{type:"minecraft:falling_spore_blossom"}}
execute if score $$dke.global dke.type matches 3 run function dke:tick_entities/breath_cloud_behavior/cloud_warped
execute if score $$dke.global dke.type matches 4 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:instant_damage"}, {id: "minecraft:darkness", duration: 200}]}, custom_particle: {type:"minecraft:squid_ink"}}
execute if score $$dke.global dke.type matches 5 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:slowness", duration: 100, amplifier: 4b}, {id: "minecraft:slow_falling", duration: 200}]}, custom_particle: {type:"minecraft:snowflake"}}
execute if score $$dke.global dke.type matches 6 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:wither", duration: 100}, {id: "minecraft:weakness", duration: 200}]}, custom_particle: {type:"minecraft:smoke"}}
execute if score $$dke.global dke.type matches 7 run data merge entity @s {custom_particle: {type:"minecraft:soul_fire_flame"}}
execute if score $$dke.global dke.type matches 8 run data merge entity @s {custom_particle: {type:"minecraft:flame"}}
execute if score $$dke.global dke.type matches 9 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:instant_damage"}, {id: "minecraft:blindness", duration: 200}]}, custom_particle: {type:"minecraft:witch"}}
execute if score $$dke.global dke.type matches 11 run function dke:tick_entities/breath_cloud_behavior/cloud_beacon
execute if score $$dke.global dke.type matches 12 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:mining_fatigue", duration: 600}, {id: "minecraft:slowness", amplifier: 2b, duration: 300}, {id: "minecraft:hunger", duration: 200}]}, custom_particle:{type:"minecraft:dust_plume"}}
execute if score $$dke.global dke.type matches 13 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:instant_damage", amplifier: 1b}, {id: "minecraft:speed", amplifier: 2b, duration: 100}]},custom_particle: {type:"minecraft:wax_off"}}
execute if score $$dke.global dke.type matches 14 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:instant_damage", amplifier: 1b}, {id: "minecraft:wither", amplifier: 1b, duration: 300},{id: "minecraft:darkness", amplifier: 1b, duration: 300}]},custom_particle: {type:"minecraft:campfire_cosy_smoke"}}
execute if score $$dke.global dke.type matches 100 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:levitation", duration: 100}, {id: "minecraft:weakness", duration: 200, amplifier: 4b}]}, RadiusPerTick: 0.015f, custom_particle: {type:"minecraft:dust",color:[0.808f,0.506f,0.949f],scale:2.0f}}
execute if score $$dke.global dke.type matches 101 run data merge entity @s {potion_contents:{custom_effects: [{id: "minecraft:poison", duration: 300}, {id: "minecraft:instant_damage", duration: 100, amplifier: 2b}]}, RadiusPerTick: 0.015f, custom_particle: {type:"minecraft:dust",color:[1.0f,0.878f,0.0f],scale:2.0f}}
# Move to ground if in midair
execute in the_end if blocks ~-1 ~-1 ~-1 ~1 ~-1 ~1 -1 3 -1 all run tp @s ~ ~-1 ~