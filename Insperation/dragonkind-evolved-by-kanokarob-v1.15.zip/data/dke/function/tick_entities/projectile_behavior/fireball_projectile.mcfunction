# Generated with MC-Build

particle flame ~ ~ ~ 0.2 0.2 0.2 0 2 force
particle lava ~ ~ ~ 0.1 0.1 0.1 0.01 1 force
tp ^ ^ ^1.5
execute if entity @a[distance=..3] run function dke:tick_entities/projectile_behavior/fireball_projectile/fireball_projectile_hit
execute if block ~ ~ ~ #dke:end_ground run function dke:tick_entities/projectile_behavior/fireball_projectile/fireball_projectile_hit
execute unless predicate dke:dragon_lair run function dke:tick_entities/projectile_behavior/fireball_projectile/fireball_projectile_hit