# Generated with MC-Build

playsound block.amethyst_cluster.break block @a[predicate=dke:dragon_lair] ~ ~ ~ 3 1
playsound entity.dragon_fireball.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle minecraft:dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~ ~ 0.5 0.5 0.5 0 30 force
particle minecraft:totem_of_undying ~ ~ ~ 0.5 0.5 0.5 0.05 10 force
tag @n[type=minecraft:marker,tag=dke.shockwave.center,distance=..1] add dke.shockwave.active
scoreboard players set @n[type=minecraft:marker,tag=dke.shockwave.center,distance=..1] dke.cooldown 49
kill @s