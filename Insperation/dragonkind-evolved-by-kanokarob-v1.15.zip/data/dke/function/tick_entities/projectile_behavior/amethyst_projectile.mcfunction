# Generated with MC-Build

particle dust{color:[0.824,0.576,0.965],scale:1.0} ~ ~ ~ 0.2 0.2 0.2 0 2 force
particle item{item:"amethyst_shard"} ~ ~ ~ 0.1 0.1 0.1 0.01 1 force
tp ^ ^ ^1.5
execute if entity @a[distance=..3] run function dke:tick_entities/projectile_behavior/amethyst_projectile/amethyst_projectile_hit
execute if block ~ ~ ~ #dke:end_ground run function dke:tick_entities/projectile_behavior/amethyst_projectile/amethyst_projectile_hit
execute unless predicate dke:dragon_lair run function dke:tick_entities/projectile_behavior/amethyst_projectile/amethyst_projectile_hit