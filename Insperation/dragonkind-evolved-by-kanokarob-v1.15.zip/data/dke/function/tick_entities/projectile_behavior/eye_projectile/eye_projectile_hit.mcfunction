# Generated with MC-Build

playsound entity.ender_eye.death block @a[predicate=dke:dragon_lair] ~ ~ ~ 3 1
playsound entity.dragon_fireball.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle portal ~ ~ ~ 2 2 2 0.1 30 normal
particle explosion ~ ~ ~ 2 2 2 0 10 force
execute as @a[distance=..5] run damage @s 10.0 magic by @n[type=minecraft:end_crystal,predicate=dke:end_crystal/launcher]
kill @s