# Generated with MC-Build

scoreboard players reset @s dke.cooldown
tp @s ~ ~ ~ facing entity @p[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator]