# Generated with MC-Build

playsound block.amethyst_cluster.break block @a[predicate=dke:dragon_lair] ~ ~ ~ 3 1
playsound entity.dragon_fireball.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle block{block_state: "minecraft:amethyst_block"} ~ ~ ~ 2 2 2 0.1 30 normal
particle explosion ~ ~ ~ 2 2 2 0 10 force
execute as @a[distance=..5] run damage @s 8.0 mob_projectile by @n[type=minecraft:ender_dragon,tag=dke.started]
kill @s