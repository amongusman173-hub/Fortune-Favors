# Generated with MC-Build

playsound entity.dragon_fireball.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle flame ~ ~ ~ 2 2 2 0.1 30 normal
particle lava ~ ~ ~ 2 2 2 0.05 10 normal
particle explosion ~ ~ ~ 2 2 2 0 10 force
execute as @a[distance=..5] run damage @s 5.0 minecraft:in_fire by @n[type=minecraft:ender_dragon,tag=dke.started]
place feature dke:fire_patch
kill @s