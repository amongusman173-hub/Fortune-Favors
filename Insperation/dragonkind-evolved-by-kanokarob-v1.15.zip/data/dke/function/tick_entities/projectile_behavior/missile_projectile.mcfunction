# Generated with MC-Build

particle minecraft:firework ~ ~ ~ 0.1 0.1 0.1 0.01 2 force
particle minecraft:smoke ~ ~ ~ 0.1 0.1 0.1 0.01 1 force
execute unless entity @s[tag=dke.missile.homing] run function dke:tick_entities/projectile_behavior/missile_projectile/motion
execute if entity @s[tag=dke.missile.homing] run function dke:tick_entities/projectile_behavior/missile_projectile/motion_homing
execute if entity @e[type=!#dke:arrow_ignore,distance=..3] run function dke:tick_entities/projectile_behavior/missile_projectile/impact
execute if block ^ ^ ^0 #dke:end_ground run function dke:tick_entities/projectile_behavior/missile_projectile/impact