# Generated with MC-Build

scoreboard players add @s dke.cooldown 0
scoreboard players add @s dke.cooldown 1
particle glow ~ ~ ~ 0.2 0.2 0.2 0 1 force
particle portal ~ ~ ~ 0.1 0.1 0.1 0.01 2 force
tp ^ ^ ^2
execute if score @s dke.cooldown matches 5.. run function dke:tick_entities/projectile_behavior/eye_projectile/eye_projectile_realign
execute if entity @a[distance=..3,nbt={FallFlying:0b}] run function dke:tick_entities/projectile_behavior/eye_projectile/eye_projectile_hit
execute if entity @a[distance=..5,predicate=dke:flying] run function dke:tick_entities/projectile_behavior/eye_projectile/eye_projectile_hit
execute if block ~ ~ ~ #dke:end_ground run function dke:tick_entities/projectile_behavior/eye_projectile/eye_projectile_hit
execute unless predicate dke:dragon_lair run function dke:tick_entities/projectile_behavior/eye_projectile/eye_projectile_hit