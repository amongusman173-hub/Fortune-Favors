# Generated with MC-Build

execute facing entity @a[predicate=dke:flying,predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] feet run tp @s ^ ^ ^0.8 ~ ~
execute unless entity @a[predicate=dke:flying,predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] facing entity @p[predicate=dke:dragon_lair,gamemode=!creative,gamemode=!spectator] feet run tp @s ^ ^ ^0.8 ~ ~