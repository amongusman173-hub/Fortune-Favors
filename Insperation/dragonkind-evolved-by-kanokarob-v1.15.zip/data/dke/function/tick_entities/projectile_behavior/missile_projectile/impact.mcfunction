# Generated with MC-Build

playsound minecraft:entity.firework_rocket.large_blast block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
playsound entity.dragon_fireball.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle minecraft:firework ~ ~1.5 ~ 0.5 0.5 0.5 0.05 30 force
particle minecraft:lava ~ ~1.5 ~ 0.5 0.5 0.5 0.05 10 force
particle minecraft:explosion ~ ~1.5 ~ 2 2 2 0 5 force
execute as @e[type=!#dke:end_mobs,distance=..5] run damage @s 10.0 minecraft:explosion by @n[type=minecraft:item_display,tag=dke.projectile.missile,distance=..6] from @n[type=minecraft:ender_dragon,predicate=dke:dragon_lair,tag=dke.started]
kill @s