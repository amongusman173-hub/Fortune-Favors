# Generated with MC-Build

execute if predicate dke:chance/20 run rotate @s ~ ~2
execute if predicate dke:chance/50 run rotate @s ~ ~1
execute rotated as @s run tp @s ^ ^ ^0.6 ~ ~2