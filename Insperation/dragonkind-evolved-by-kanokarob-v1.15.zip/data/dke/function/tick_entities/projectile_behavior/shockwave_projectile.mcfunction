# Generated with MC-Build

particle minecraft:dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~ ~ 0.5 0.5 0.5 0 10 force
particle minecraft:totem_of_undying ~ ~ ~ 0.3 0.3 0.3 0 3 force
tp ^ ^ ^1.5
execute if entity @n[type=minecraft:marker,tag=dke.shockwave.center,distance=..1] run function dke:tick_entities/projectile_behavior/shockwave_projectile/shockwave_projectile_hit