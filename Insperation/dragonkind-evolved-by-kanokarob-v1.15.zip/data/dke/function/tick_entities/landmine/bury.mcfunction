# Generated with MC-Build

tp @s ~ ~-0.0065 ~ ~2 0
execute if predicate dke:periodic_5t run playsound minecraft:item.brush.brushing.generic block @a[predicate=dke:dragon_lair,distance=..16] ~ ~ ~ 1 1
particle minecraft:block{block_state:"minecraft:end_stone"} ~ ~0.2 ~ 0.3 0.1 0.3 0.01 2 normal
execute if score @s dke.time matches 30 run playsound minecraft:block.note_block.bit block @a[predicate=dke:dragon_lair,distance=..16] ~ ~ ~ 0.5 2
execute if score @s dke.time matches 50 run data modify entity @s Glowing set value 0b
execute if score @s dke.time matches 100 run playsound minecraft:block.note_block.bit block @a[predicate=dke:dragon_lair,distance=..16] ~ ~ ~ 0.5 2