# Generated with MC-Build

playsound minecraft:entity.generic.explode block @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1
particle minecraft:firework ~ ~2.5 ~ 1 1 1 0.2 30 force
particle minecraft:lava ~ ~2.5 ~ 1 1 1 0.1 10 force
particle minecraft:explosion ~ ~2.5 ~ 1.5 1.5 1.5 0 5 force
execute as @e[type=!#dke:end_mobs,distance=..7] run damage @s 10.0 minecraft:explosion by @n[type=minecraft:item_display,tag=dke.landmine,distance=..8] from @n[type=minecraft:ender_dragon,predicate=dke:dragon_lair,tag=dke.started]
kill @s