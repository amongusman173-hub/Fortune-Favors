# Generated with MC-Build

particle poof ~ ~0.2 ~ 0.2 0.2 0.2 0.01 2 normal
kill @s