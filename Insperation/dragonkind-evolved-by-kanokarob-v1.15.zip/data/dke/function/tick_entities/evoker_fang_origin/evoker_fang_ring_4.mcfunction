# Generated with MC-Build

execute positioned ^ ^ ^4 run function dke:spawns/elder_fang
execute positioned ^ ^ ^-4 run function dke:spawns/elder_fang
execute positioned ^4 ^ ^ run function dke:spawns/elder_fang
execute positioned ^-4 ^ ^ run function dke:spawns/elder_fang