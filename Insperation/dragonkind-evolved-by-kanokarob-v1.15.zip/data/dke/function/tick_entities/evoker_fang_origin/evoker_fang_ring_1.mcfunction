# Generated with MC-Build

execute positioned ^ ^ ^1 run function dke:spawns/elder_fang
execute positioned ^ ^ ^-1 run function dke:spawns/elder_fang
execute positioned ^1 ^ ^ run function dke:spawns/elder_fang
execute positioned ^-1 ^ ^ run function dke:spawns/elder_fang