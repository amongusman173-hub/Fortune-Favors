# Generated with MC-Build

execute positioned ^ ^ ^2 run function dke:spawns/elder_fang
execute positioned ^ ^ ^-2 run function dke:spawns/elder_fang
execute positioned ^2 ^ ^ run function dke:spawns/elder_fang
execute positioned ^-2 ^ ^ run function dke:spawns/elder_fang