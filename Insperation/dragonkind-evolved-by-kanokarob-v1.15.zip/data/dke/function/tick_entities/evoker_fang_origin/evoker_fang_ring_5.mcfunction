# Generated with MC-Build

execute positioned ^ ^ ^5 run function dke:spawns/elder_fang
execute positioned ^ ^ ^-5 run function dke:spawns/elder_fang
execute positioned ^5 ^ ^ run function dke:spawns/elder_fang
execute positioned ^-5 ^ ^ run function dke:spawns/elder_fang