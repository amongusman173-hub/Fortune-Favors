# Generated with MC-Build

execute positioned ^ ^ ^3 run function dke:spawns/elder_fang
execute positioned ^ ^ ^-3 run function dke:spawns/elder_fang
execute positioned ^3 ^ ^ run function dke:spawns/elder_fang
execute positioned ^-3 ^ ^ run function dke:spawns/elder_fang