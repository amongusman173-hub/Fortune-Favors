# Generated with MC-Build

particle minecraft:dust{color:[1.0,0.878,0.0],scale:2.0} ~ ~1.75 ~ 2 0.75 2 0.05 30 force
particle minecraft:explosion ~ ~0.5 ~ 1 0.5 1 0 5 force
playsound minecraft:entity.generic.explode block @a[distance=..16] ~ ~ ~ 0.2 1.2
playsound minecraft:item.totem.use block @a[distance=..16] ~ ~ ~ 0.2 2
execute as @a[distance=..4,predicate=!dke:on_ground] run damage @s 5.0 minecraft:magic by @n[type=minecraft:ender_dragon,tag=dke.started,predicate=dke:dragon_lair]