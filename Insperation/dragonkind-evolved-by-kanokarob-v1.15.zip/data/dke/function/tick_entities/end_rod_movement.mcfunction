# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
execute if score @s dke.time matches ..7 run tp @s ~ ~0.15 ~
execute if score @s dke.time matches 5..7 as @a[predicate=dke:on_ground,distance=..1.5] run damage @s 3.0 minecraft:mob_attack
execute if score @s dke.time matches 10 run function dke:tick_entities/end_rod_movement/end_rod_kill