# Generated with MC-Build

# Movement
execute facing entity @e[tag=dke.hazard.center,distance=..11] feet run tp @s ^0.4 ^ ^0.007
execute facing entity @e[tag=dke.hazard.center,distance=11..] feet run tp @s ^-0.4 ^ ^0.007
# Aesthetics
execute positioned ~-4 ~-4 ~-4 run playsound minecraft:entity.lightning_bolt.impact hostile @a[dx=9,dz=9] ~ ~ ~ 0.5 1
execute positioned over motion_blocking run particle electric_spark ~ ~ ~ 1 1 1 0 10 force
execute positioned over motion_blocking run particle explosion ~ ~2 ~ 1 1 1 0 1 normal
# Damage
execute positioned ~-1 0 ~-1 as @e[type=!#dke:no_knockback,type=!#dke:end_mobs,dx=3,dy=128,dz=3] at @s run function dke:tick_entities/hazards/thunder/lightning_damage