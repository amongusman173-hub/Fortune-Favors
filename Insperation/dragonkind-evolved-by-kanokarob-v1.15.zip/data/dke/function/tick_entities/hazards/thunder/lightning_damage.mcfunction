# Generated with MC-Build

damage @s 6.0 minecraft:lightning_bolt by @e[type=minecraft:ender_dragon,tag=dke.started,predicate=dke:dragon_lair,limit=1]
particle wax_off ~ ~1 ~ 0.3 0.5 0.3 0.05 10 force
playsound minecraft:entity.lightning_bolt.impact hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 1 1