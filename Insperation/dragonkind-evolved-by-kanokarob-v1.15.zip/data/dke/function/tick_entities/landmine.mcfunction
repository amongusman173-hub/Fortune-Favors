# Generated with MC-Build

scoreboard players add @s dke.time 0
# Bury
execute if score @s dke.time matches 30..100 run function dke:tick_entities/landmine/bury
# Explode
execute if score @s dke.time matches 100.. if entity @e[type=#dke:landmine_detect,distance=..5] run function dke:tick_entities/landmine/explode
execute unless score @s dke.time matches 101.. run scoreboard players add @s dke.time 1