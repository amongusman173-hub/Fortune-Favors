# Generated with MC-Build

scoreboard players add @s dke.time 0
scoreboard players add @s dke.time 1
#Amethyst Projectiles
execute if entity @s[tag=dke.projectile.amethyst] run function dke:tick_entities/projectile_behavior/amethyst_projectile
#Fireball Projectiles
execute if entity @s[tag=dke.projectile.fireball] run function dke:tick_entities/projectile_behavior/fireball_projectile
#Eye Projectiles
execute if entity @s[tag=dke.projectile.eye] run function dke:tick_entities/projectile_behavior/eye_projectile
# Missiles
execute if entity @s[tag=dke.projectile.missile] run function dke:tick_entities/projectile_behavior/missile_projectile
# Shockwave Projectiles
execute if entity @s[tag=dke.projectile.shockwave] run function dke:tick_entities/projectile_behavior/shockwave_projectile
#Remove projectile
execute if score @s dke.time matches 300.. run kill @s