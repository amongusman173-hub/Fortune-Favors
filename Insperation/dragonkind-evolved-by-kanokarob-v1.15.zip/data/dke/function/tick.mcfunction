# Generated with MC-Build

# Tag necessary entities
execute as @e[type=#dke:untagged_entities,predicate=dke:dragon_lair,tag=!dke.entity,tag=!smithed.entity,tag=!smithed.strict] at @s run function dke:tag_entities
#████████ ██  ██████ ██   ██     ██████  ██       █████  ██    ██ ███████ ██████  
#   ██    ██ ██      ██  ██      ██   ██ ██      ██   ██  ██  ██  ██      ██   ██ 
#   ██    ██ ██      █████       ██████  ██      ███████   ████   █████   ██████  
#   ██    ██ ██      ██  ██      ██      ██      ██   ██    ██    ██      ██   ██ 
#   ██    ██  ██████ ██   ██     ██      ███████ ██   ██    ██    ███████ ██   ██ 
#Runs player tick functions
execute as @a at @s run function dke:tick_player
#████████ ██  ██████ ██   ██     ███████ ███    ██ ████████ ██ ████████ ██ ███████ ███████ 
#   ██    ██ ██      ██  ██      ██      ████   ██    ██    ██    ██    ██ ██      ██      
#   ██    ██ ██      █████       █████   ██ ██  ██    ██    ██    ██    ██ █████   ███████ 
#   ██    ██ ██      ██  ██      ██      ██  ██ ██    ██    ██    ██    ██ ██           ██ 
#   ██    ██  ██████ ██   ██     ███████ ██   ████    ██    ██    ██    ██ ███████ ███████ 
#Runs entity-specific functions
execute as @e[type=#dke:entities,tag=dke.ticking] at @s run function dke:tick_entities