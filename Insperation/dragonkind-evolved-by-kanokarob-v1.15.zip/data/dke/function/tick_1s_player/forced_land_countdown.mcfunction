# Generated with MC-Build

scoreboard players remove @s dke.time.forced_land 1
execute if score @s dke.time.forced_land matches ..0 run function dke:tick_1s_player/forced_land_countdown/forced_land_expire