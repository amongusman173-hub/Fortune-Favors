# Generated with MC-Build

scoreboard players reset @s dke.time.forced_land
tag @s remove dke.grounded
attribute @s minecraft:gravity modifier remove dke:forced_land
attribute @s minecraft:fall_damage_multiplier base set 1.0