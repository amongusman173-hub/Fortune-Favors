# Generated with MC-Build

scoreboard players set $$dke.global dke.alive 0
kill @e[tag=dke.requires_dragon]
execute as @e[tag=dke.igloo] at @s run function dke:tick_1s_entities/igloo_behavior/igloo_removal
execute as @e[type=minecraft:end_crystal,predicate=dke:dragon_lair,nbt={ShowBottom:1b},tag=!smithed.entity,tag=!smithed.strict] at @s run function dke:ender_dragon_death/kill_crystal
execute as @e[tag=dke.end_crystal,predicate=dke:dragon_lair,nbt={ShowBottom:1b}] at @s run function dke:ender_dragon_death/kill_crystal
kill @e[type=minecraft:marker,tag=dke.crystal,predicate=dke:dragon_lair]
fill ~-4 ~-2 ~-4 ~4 ~2 ~4 air replace fire
execute positioned 0 0 0 positioned over motion_blocking run summon marker ~ ~ ~ {Tags: [dke.entity,dke.cleanup_crew,dke.ticking,dke.entity.technical]}
scoreboard players set @n[tag=dke.cleanup_crew] dke.cooldown 60
execute as @p run function dke:ender_dragon_death/ender_dragon_loot
tag @e[type=minecraft:enderman,predicate=dke:dragon_lair,tag=dke.entity] remove dke.entity