# Generated with MC-Build

# Scheduled functions
schedule function dke:tick_1s 1s replace
# Dummy scores
scoreboard objectives add dke.time dummy
scoreboard objectives add dke.time.sound dummy
scoreboard objectives add dke.time.forced_land dummy
scoreboard objectives add dke.time.generic dummy
scoreboard objectives add dke.time.meteors dummy
scoreboard objectives add dke.cooldown dummy
scoreboard objectives add dke.state dummy
scoreboard objectives add dke.alive dummy
scoreboard objectives add dke.success dummy
scoreboard objectives add dke.random dummy
scoreboard objectives add dke.temp dummy
scoreboard objectives add dke.edk dummy
scoreboard objectives add dke.difficulty dummy
scoreboard objectives add dke.ominous dummy
scoreboard objectives add dke.type dummy
scoreboard objectives add dke.next_type dummy
scoreboard objectives add dke.count dummy
scoreboard objectives add dke.health dummy
scoreboard objectives add dke.max_health dummy
scoreboard objectives add dke.has_end_crystals dummy
scoreboard objectives add dke.player_health health
scoreboard objectives add dke.ability_1 dummy
scoreboard objectives add dke.ability_2 dummy
scoreboard objectives add dke.ability_3 dummy
scoreboard objectives add dke.pickaxe_count dummy
scoreboard objectives add dke.anchor_id dummy
scoreboard objectives add dke.x dummy
scoreboard objectives add dke.y dummy
scoreboard objectives add dke.z dummy
# Tracking scores
scoreboard objectives add dke.w_stick used:warped_fungus_on_a_stick
scoreboard objectives add dke.pickaxe minecraft.used:minecraft.diamond_pickaxe