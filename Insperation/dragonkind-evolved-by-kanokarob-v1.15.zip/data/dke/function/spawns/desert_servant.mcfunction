# Generated with MC-Build

summon hoglin ~ ~ ~ {Tags: [dke.mob, dke.mob.desert_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.hoglin_servant"}, attributes: [{id: "minecraft:max_health", base: 18.0d}, {id: "minecraft:attack_damage", base: 7.0d}, {id: "minecraft:follow_range", base: 150.0d}], Health: 18.0f, DeathLootTable: "dke:empty", IsImmuneToZombification: 1b}
particle lava ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle falling_dust{block_state:"minecraft:sand"} ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound entity.blaze.ambient hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.35