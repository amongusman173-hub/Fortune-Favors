# Generated with MC-Build

summon husk ~ ~ ~ {Tags: [dke.mob, dke.mob.zombie_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.zombie_servant"}, attributes: [{id: "minecraft:max_health", base: 18.0d}, {id: "minecraft:knockback_resistance", base: 0.8d}, {id: "minecraft:attack_damage", base: 5.0d}, {id: "minecraft:follow_range", base: 150.0d}, {id: "minecraft:movement_speed", base: 0.3d}], Health: 18.0f, DeathLootTable: "dke:empty"}
particle minecraft:entity_effect{color:-15882932} ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle spore_blossom_air ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound block.respawn_anchor.set_spawn hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1