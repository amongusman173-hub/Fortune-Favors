# Generated with MC-Build

kill @e[tag=dke.mob.zombie_servant,predicate=dke:dragon_lair]
execute positioned ^5 ^ ^ positioned over motion_blocking run function dke:spawns/zombie_servant
execute positioned ^-3 ^ ^2.5 positioned over motion_blocking run function dke:spawns/zombie_servant
execute positioned ^-3 ^ ^-2.5 positioned over motion_blocking run function dke:spawns/zombie_servant