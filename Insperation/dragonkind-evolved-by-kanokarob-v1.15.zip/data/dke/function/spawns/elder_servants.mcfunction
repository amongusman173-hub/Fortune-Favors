# Generated with MC-Build

summon vex ~3 ~2 ~ {Tags: [dke.mob, dke.mob.elder_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.vex_servant"}, attributes: [{id: "minecraft:max_health", base: 5.0d}, {id: "minecraft:attack_damage", base: 6.0d}, {id: "minecraft:follow_range", base: 150.0d}], Health: 5.0f, DeathLootTable: "dke:empty"}
summon vex ~-2 ~2 ~1 {Tags: [dke.mob, dke.mob.elder_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.vex_servant"}, attributes: [{id: "minecraft:max_health", base: 5.0d}, {id: "minecraft:attack_damage", base: 6.0d}, {id: "minecraft:follow_range", base: 150.0d}], Health: 5.0f, DeathLootTable: "dke:empty"}
summon vex ~-2 ~2 ~-1 {Tags: [dke.mob, dke.mob.elder_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.vex_servant"}, attributes: [{id: "minecraft:max_health", base: 5.0d}, {id: "minecraft:attack_damage", base: 6.0d}, {id: "minecraft:follow_range", base: 150.0d}], Health: 5.0f, DeathLootTable: "dke:empty"}
particle totem_of_undying ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle enchant ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound entity.evoker.prepare_summon hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 0.85