# Generated with MC-Build

kill @e[tag=dke.mob.moss_servant,predicate=dke:dragon_lair]
execute positioned ^9 ^ ^ positioned over motion_blocking run function dke:spawns/moss_servant
execute positioned ^-6 ^ ^5.5 positioned over motion_blocking run function dke:spawns/moss_servant
execute positioned ^-6 ^ ^-5.5 positioned over motion_blocking run function dke:spawns/moss_servant