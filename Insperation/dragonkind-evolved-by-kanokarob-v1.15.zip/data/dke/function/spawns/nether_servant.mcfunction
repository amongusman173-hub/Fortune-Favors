# Generated with MC-Build

summon blaze ~ ~1 ~ {Tags: [dke.mob, dke.mob.nether_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.blaze_servant"}, attributes: [{id: "minecraft:max_health", base: 18.0d}, {id: "minecraft:knockback_resistance", base: 0.8d}, {id: "minecraft:attack_damage", base: 4.0d}, {id: "minecraft:follow_range", base: 150.0d}, {id: "minecraft:movement_speed", base: 0.3d}], Health: 35.0f, DeathLootTable: "dke:empty"}
particle lava ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle flame ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound entity.blaze.hurt hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 0.85