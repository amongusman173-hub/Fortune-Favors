# Generated with MC-Build

execute positioned ^5 ^ ^ positioned over motion_blocking run function dke:spawns/nether_servant
execute positioned ^-3 ^ ^2.5 positioned over motion_blocking run function dke:spawns/nether_servant
execute positioned ^-3 ^ ^-2.5 positioned over motion_blocking run function dke:spawns/nether_servant