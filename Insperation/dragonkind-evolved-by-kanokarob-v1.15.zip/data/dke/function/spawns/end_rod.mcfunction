# Generated with MC-Build

playsound entity.evoker_fangs.attack hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 0.7 1.35
execute positioned over motion_blocking run summon block_display ~ ~-1 ~ {Tags:[dke.end_rod,dke.ticking,dke.entity,dke.requires_dragon],block_state:{Name:"minecraft:end_rod",Properties:{facing:"up"}},brightness:{block:15,sky:15},transformation:{translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],scale:[1f,1f,1f],right_rotation:[0f,0f,0f,1f]},teleport_duration:1}