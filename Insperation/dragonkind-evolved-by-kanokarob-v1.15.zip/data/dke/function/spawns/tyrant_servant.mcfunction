# Generated with MC-Build

summon wither_skeleton ~ ~ ~ {Tags: [dke.mob, dke.mob.tyrant_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.wither_skeleton_servant"}, attributes: [{id: "minecraft:max_health", base: 18.0d}, {id: "minecraft:knockback_resistance", base: 0.8d}, {id: "minecraft:attack_damage", base: 7.0d}, {id: "minecraft:follow_range", base: 150.0d}, {id: "minecraft:movement_speed", base: 0.2d}], Health: 35.0f, DeathLootTable: "dke:empty"}
particle large_smoke ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle soul ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound entity.wither.spawn hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.35