# Generated with MC-Build

execute positioned over motion_blocking run summon evoker_fangs ~ ~ ~