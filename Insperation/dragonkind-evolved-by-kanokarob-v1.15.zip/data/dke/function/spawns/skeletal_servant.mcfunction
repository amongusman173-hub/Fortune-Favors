# Generated with MC-Build

summon skeleton ~ ~ ~ {Tags: [dke.mob, dke.mob.skeletal_servant, dke.entity, dke.requires_dragon], CustomName: {"translate":"entity.dke.skeleton_servant"}, attributes: [{id: "minecraft:max_health", base: 20.0d}, {id: "minecraft:knockback_resistance", base: 0.8d}, {id: "minecraft:attack_damage", base: 6.0d}, {id: "minecraft:follow_range", base: 150.0d}, {id: "minecraft:movement_speed", base: 0.2d}], Health: 20.0f, DeathLootTable: "dke:empty",Glowing:1b}
particle soul_fire_flame ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle block{block_state: "minecraft:bone_block"} ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound entity.skeleton.death hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1.35