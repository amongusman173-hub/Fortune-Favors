# Generated with MC-Build

summon slime ~ ~ ~ {Tags:[dke.mob,dke.mob.moss_servant,dke.entity,dke.requires_dragon],CustomName:{"translate":"entity.dke.slime_servant"},attributes:[{id:"minecraft:max_health",base: 18.0d},{id: "minecraft:knockback_resistance",base: 0.8d},{id:"minecraft:attack_damage",base:5.0d},{id:"minecraft:scale",base:6.0},{id:"minecraft:follow_range",base:150.0d}],Health:18.0f,DeathLootTable:"dke:empty",Size:1}
particle minecraft:item_slime ~ ~0.2 ~ 0.3 0.1 0.3 0.05 5 normal
particle spore_blossom_air ~ ~0.2 ~ 0.1 0.3 0.1 0.01 10 normal
playsound block.respawn_anchor.set_spawn hostile @a[predicate=dke:dragon_lair] ~ ~ ~ 2 1