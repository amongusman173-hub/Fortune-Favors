# Generated with MC-Build

execute if entity @s[x_rotation=-90..-30] run function dke:enchantments/propel