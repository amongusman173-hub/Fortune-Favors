# Generated with MC-Build

advancement revoke @s only dke:clear_skies_blocking
execute positioned ~-1 ~-0.5 ~-1 run kill @e[tag=dke.cloud,dx=3,dy=2,dz=3]