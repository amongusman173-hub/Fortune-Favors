# Generated with MC-Build

particle dragon_breath ~ ~1 ~ 0.3 0.3 0.3 0.05 20 normal
playsound entity.ender_dragon.hurt player @a ~ ~ ~ 0.7 0.85
tp @s ^ ^ ^-2.5
execute at @s run damage @s[type=!ender_dragon] 4.0 magic by @p[advancements={dke:kickback_block=true}]