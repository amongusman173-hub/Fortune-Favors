# Generated with MC-Build

execute anchored eyes positioned ^ ^ ^14 align xyz positioned ~-16 ~-16 ~-16 run function dke:enchantments/scan_large
item modify entity @s armor.head dke:dragonsight_damage
execute if predicate dke:items/head_broken run function dke:enchantments/break_head