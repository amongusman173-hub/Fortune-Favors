setblock ~ ~ ~ air destroy
kill @n[type=item,tag=!smithed.entity,tag=!smithed.strict]
item modify entity @s weapon.mainhand dke:damage_pickaxe