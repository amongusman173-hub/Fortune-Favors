# Generated with MC-Build

execute if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.5] run function dke:enchantments/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~ ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~ ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~ ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~ ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~ ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~ ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~ ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~ ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~-1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~-1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~-1 ~ if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~-1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~ ~-1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~-1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~1 ~-1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~-1 ~1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity
execute positioned ~-1 ~-1 ~-1 if block ~ ~ ~ #dke:ores unless entity @e[tag=dke.scan,distance=..0.25] run function dke:items/scan_large/scan_small/summon_scan_entity