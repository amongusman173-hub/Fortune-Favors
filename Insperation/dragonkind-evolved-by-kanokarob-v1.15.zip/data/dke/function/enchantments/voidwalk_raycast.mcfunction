# Generated with MC-Build

execute store success score @s dke.success unless block ~ ~-0.4 ~ #dke:nonsolid
execute unless block ~ ~-0.4 ~ #dke:nonsolid run return 1
execute if score @s dke.success matches 0 unless block ~ ~-1 ~ barrier positioned ~ ~-1 ~ run function dke:enchantments/voidwalk_raycast