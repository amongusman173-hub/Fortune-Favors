# Generated with MC-Build

tag @s add dke.entity
tag @s add dke.ticking
tag @s add dke.exhalation_arrow