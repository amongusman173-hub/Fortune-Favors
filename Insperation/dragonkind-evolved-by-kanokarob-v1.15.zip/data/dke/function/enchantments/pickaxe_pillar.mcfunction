# Generated with MC-Build

execute if score @s dke.pickaxe_count matches 10 positioned ^ ^ ^2 store success score @s dke.success unless block ~ ~ ~ #dke:unbreakable run setblock ~ ~ ~ air destroy
execute if score @s dke.success matches 1.. run item modify entity @s weapon.mainhand dke:damage_pickaxe
execute if score @s dke.pickaxe_count matches 5 positioned ^ ^ ^3 store success score @s dke.success unless block ~ ~ ~ #dke:unbreakable run setblock ~ ~ ~ air destroy
execute if score @s dke.success matches 1.. run item modify entity @s weapon.mainhand dke:damage_pickaxe
execute if score @s dke.pickaxe_count matches 0 positioned ^ ^ ^4 store success score @s dke.success unless block ~ ~ ~ #dke:unbreakable run setblock ~ ~ ~ air destroy
execute if score @s dke.success matches 1.. run item modify entity @s weapon.mainhand dke:damage_pickaxe
scoreboard players reset @s dke.success
scoreboard players remove @s dke.pickaxe_count 1