# Generated with MC-Build

#Mined something
execute if score @s dke.pickaxe matches 1.. run scoreboard players set @s dke.pickaxe_count 15
execute if score @s dke.pickaxe_count matches 0.. run function dke:enchantments/pickaxe_pillar