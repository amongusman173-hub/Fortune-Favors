# Generated with MC-Build

particle smoke ~ ~ ~ 0.5 0.1 0.5 0.01 2 normal
particle dragon_breath ~ ~ ~ 0.5 0.1 0.5 0.01 1 normal
execute unless predicate dke:slow_falling unless predicate dke:levitating run effect give @s levitation 1 3 true
execute unless predicate dke:slow_falling run effect give @s slow_falling 2 0 true