# Generated with MC-Build

execute on attacker at @s facing entity @p[advancements={dke:kickback_block=true}] feet run function dke:enchantments/knockback
advancement revoke @s only dke:kickback_block