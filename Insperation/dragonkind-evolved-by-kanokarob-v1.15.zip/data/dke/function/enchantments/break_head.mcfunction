# Generated with MC-Build

item replace entity @s armor.head with air 1
playsound entity.item.break player @s ~ ~ ~ 1 1
execute anchored eyes run particle item{item:{id:"warped_fungus_on_a_stick",components:{"minecraft:item_model":"dke:dragon_eyes"}}} ^ ^0.5 ^ 0.2 0.2 0.2 0.01 5 normal