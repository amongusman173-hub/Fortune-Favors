# Generated with MC-Build

execute anchored eyes run particle poof ^ ^-0.5 ^-1 0.5 0.5 0.5 0.05 10 normal
playsound item.elytra.flying player @a ~ ~ ~ 1 1.3
effect give @s levitation 2 20 true