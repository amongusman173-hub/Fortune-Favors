# Generated with MC-Build

execute unless predicate dke:slow_falling run function dke:enchantments/voidwalk_raycast
execute if score @s dke.success matches 0 run function dke:enchantments/voidwalk_gravity_enable
scoreboard players reset @s dke.success