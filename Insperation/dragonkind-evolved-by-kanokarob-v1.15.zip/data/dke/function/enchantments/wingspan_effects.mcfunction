# Generated with MC-Build

playsound entity.ender_dragon.flap player @a ~ ~ ~ 1.5 1.35
playsound entity.player.attack.sweep player @a ~ ~ ~ 1.5 0.85
execute rotated ~ 0 run particle sweep_attack ~ ~ ~ 0 0 0 0 1 normal