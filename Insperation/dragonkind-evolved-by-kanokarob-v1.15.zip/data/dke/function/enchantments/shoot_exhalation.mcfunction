# Generated with MC-Build

advancement revoke @s only dke:shoot_exhalation
execute as @n[type=#dke:arrows] run function dke:enchantments/tag_arrows