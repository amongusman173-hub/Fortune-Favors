# Wrong Yellow v1.0.0-rc3 Candidate

Wrong Yellow is a pure vanilla Minecraft Java datapack about places the game was never supposed to generate.

- Minecraft Java / Paper 1.21.11
- no mod and no resource pack required
- normal labyrinth layers active at Y16, Y64, Y112 and Y160
- roof active at Y208+
- bounded Giga runtime with mandatory sliced prefill for Wells, Splits and Monorooms
- composite Monoroom 48b equiprobable with the other five variants at every monoroom slot
- Director, Event Lock, Entity, C-wall, Blink Lite, Spawn Blink and Dead Screen Guard active
- Roof Escape uses Levitation-only stabilization

Install the zip directly in `<world>/datapacks/`, remove older Wrong Yellow builds, and restart the server completely. Do not use `/reload` as the primary release test.

Current documentation is in `docs/`. The full experimental history remains available under `docs/history/`.

## Candidate validation focus

- exact-footprint strict sandstone prefill before every Giga template, temporized across builder pulses;
- true four-arm Split intersections, now fully silent;
- hidden Entity profile warmup with no Alex/Steve flash or visible relocation;
- quieter portal-wall flanger.

See `docs/RC3_CANDIDATE_AUDIT.md`, `docs/RC3_CANDIDATE_SMOKE_TEST.md` and the normative `docs/GIGA_PREFILL_POLICY.md`.

Final release gate: `docs/FINAL_RC3_CHECKLIST.md`.
