# v1.0.0-rc3 Candidate — final static audit

- Added a physical air probe before a sparse Well cap can complete; command success alone is no longer accepted.
- Corrected all 105 vertical Split segment/cross/terminal-cap prefills from single 24/48-block fills to three or six 8-block slices, one per builder pulse; the sparse roof cross remains an exact 48-block plus-shaped prefill.
- Added an authoritative physical air probe after each of the 106 Split template pieces; a failed probe leaves the builder on the same piece for retry instead of advancing.
- Applied explicit `none none 1 0 strict` placement and strict sandstone cleanup to the 16 active matrix-source cache scans; no Giga `place template` command remains without `strict`.
- Prevented Hostile hitbox recovery unless a revealed, non-pending mannequin visual is present.
- Removed the orphan `backrooms:place_all_layers` manual function, which referenced four deleted worldgen structures.
- Synchronized current timer, exact-footprint prefill and build nomenclature documentation; runtime guard is now 51.
- No timer, probability, NBT, worldgen, Spectator, C-wall, portal, Blink, Roof Escape, loot or audio behavior was changed.
- Static candidate only: Paper startup and smoke tests remain required before public release.

# RC3.68.48 — Exact-footprint Giga Prefill Hotfix

- Well cap prefill reduced from the nominal 48x1x48 NBT box to the actual 16x1x16 central aperture.
- Temporary Split frontier-cap prefills now match their NBTs exactly: 1xHx4 east/west, 4xHx1 north/south.
- Sparse Split roof-cross prefill now matches its plus-shaped 48-block aperture instead of filling the full 8x8 box.
- Prevents permanent smooth-sandstone strips/walls in structure-void or omitted template space.
- Uniform Giga prefill remains mandatory; only its footprint was corrected.
- Runtime guard 50.

# RC3.68.48 — Giga Prefill Syntax / Split State Hotfix

- Fixes the invalid `fill ... smooth_sandstone replace strict` syntax introduced in RC3.68.45. `replace` expects a block filter, so Paper parsed `strict` as the nonexistent block `minecraft:strict` and refused to load 148 commands across 116 functions.
- Uses the valid no-filter syntax `fill ... smooth_sandstone strict` for every Giga prefill operation.
- Retains RC3.68.46's dedicated `br_giga_prefill` state, preventing generic prefill from overwriting Split-cross body state in `br_giga_comp` and quarantining jobs at step 40.
- Bumps runtime guard to 49 and corrects the pack metadata/version labels.
- No gameplay, Spectator, audio, probability, NBT, Well geometry or macrocell allocation changes.

# RC3.68.46 — Split Prefill State Hotfix

- Fixes Split/cross jobs quarantining at step 40 after uniform prefill was introduced.
- Adds dedicated `br_giga_prefill` state. `br_giga_comp` is reserved for cross-body/composite progress and must never be reused for generic prefill.
- The stall watchdog now treats prefill phase changes as real progress.
- No gameplay, Spectator, Well, monoroom, audio or pacing changes.

# Changelog

## RC3.68.46 — Uniform Giga Prefill / Strict Placement Safety

- Restored the complete smooth-sandstone prefill before every runtime Giga template: monorooms, composite 48b, bounded Wells, Split segments, crosses and caps.
- Made the policy explicit and normative: prefill removes the previous labyrinth before dependent blocks are replaced; it is not an optional rendering workaround.
- Added `strict` to Giga sandstone fills and template placements so the temporary replacement and final NBT do not trigger neighbour/shape updates that can drop carpets or churn block states.
- Intended temporized large construction: one <=8-block-high fill slice per builder pulse, with the final template placed later. The supplied RC3.68.48 still had single 24/48-block Split fills; the candidate section above records their final correction.
- Restored the complete Well base/stage/cap prefill pipeline; 24-high stages use three 8-high slices before placement.
- Expanded 48x48 Well and monoroom readiness checks to all 3x3 touched chunks rather than corners only.
- Kept Spectator-driven Giga generation unchanged by explicit request.
- Added `docs/GIGA_PREFILL_POLICY.md` and runtime counters for monoroom/Well/Split/frontier-cap prefill operations.
- Advanced content layout to v7 and runtime guard to v47.

## RC3.68.44 — Direct Giga Placement / Dynamic C-wall Retarget / Presence Boost

- Portal-wall trigger/flanger is now private to the player beginning their own Backrooms transfer.
- C-wall tracking re-evaluates the nearest eligible player every 20 ticks; it changes target only when another player is closer and replays the existing chase-start sound sequence on transfer.
- Entity and One-shot pacing increased by at least one third on Y65 and Y113 bands, with Y161 adjusted where needed to preserve the rising danger gradient.
- Removed composite 48b height restrictions: all six monoroom variants now have equal pool weight in every monoroom slot; existing two-room placement logic for small rooms is unchanged.
- Replaced Well temporary prefill with direct base/stage/cap template placement, one module per pulse, matching the stable composite-48b method.
- Removed all 100 temporary smooth-sandstone prefill writes from Split segment/cap construction; air-clears, chunk checks, probes and frontier logic remain intact.
- Advanced monoroom pool to v7, content layout to v6 and runtime guard to v46.

## RC3.68.43 — Well Support Prefill / True Split Cross / Entity Cloak Rebuild

- Fixed transient Well rendering/occlusion corruption: each 48×24×48 stage now prefills only the three smooth-sandstone support rings directly below its carpets, while the 16×16 central shaft remains air from the start. This preserves carpet stability with about 89% fewer temporary stage block writes.
- Split cells with both axes now materialize the complete EW and NS bodies before the cross core; retries rebuild the complete intersection, including the north/south-entry path whose canonical EW second body previously fell through into another NS pass.
- Removed the Split construction sound feature, its runtime tags/functions, debug command, counters and active documentation.
- Portal-wall entry flanger lowered by 4 dB: both layers are now -10 dB.
- Entity mannequins are created/reprofiled invisible, warmed for 20 ticks, revealed atomically with their hitbox and spawn cue, and pooled only after a two-tick hidden delay. Default Steve/Alex fallback is no longer used.
- Entity spawn audio is now owned by the reveal step rather than firing before the prepared visual is visible.


## RC3.68.41 — Split Cross Fix / Audio Pass 4

- Fixed Split-cross cells looping between straight segment and cross: cross NBT intentionally has no brown carpet, so the old physical probe could never validate it.
- Added a cross-specific two-point polished-tuff-wall probe and direct cross retry routing; completed crosses now clear their temporary caps normally.
- Restored `block.respawn_anchor.charge` at C-wall chase start, exactly volume 0.35 / pitch 0.5, alongside the existing layers.
- Raised all C-wall Bone Block cues by another 2 dB to volume 0.440663.
- Reworked the Elytra movement layer into alternating 25-tick plays refreshed every 20 ticks, with a 5-tick overlap and explicit stop tags.
- Increased one-shot frequency again at Y65–160: f2 150..300 s, f3 90..240 s, short retries 15..45 s; f1 and f4 remain unchanged.
- Advanced runtime guard to v43.

## RC3.68.40 — Safe Entry / Audio Pass 3

- Added a nearest-valid-carpet entry scan around the canonical Backrooms spawn; players land directly on brown carpet with two clear blocks instead of falling through a staircase void.
- C-wall Elytra layer lowered by 3 dB to -23 dB and replayed from the moving controller every 20 ticks.
- C-wall rotation Bone Block cue raised by 5 dB to match the chase-start level.
- Entity / one-shot / warning Soul Speed cue raised another 3 dB, from -5 dB to -2 dB.
- Kept bounded direct Wells, equal eligible monoroom weights and all RC3.68.39 gameplay rules unchanged.
- Advanced runtime guard to v42.
- Hostile relocation visual leakage remains the principal open gameplay defect.

## RC3.68.39 — Bounded Wells / Audio Pass 2

- Replaced runtime Well `/place jigsaw` generation with deterministic direct placement: one 48×8×48 base, zero to six 48×24×48 stages, and one cap, all with rotation `none`.
- Added a hard 128×128 macrocell boundary guard; a 48×48 Well may end on the cell edge but can never cross it.
- Removed obsolete matrix Well jigsaw functions, NBT starts and template pools from the active pack.
- Added `/function backrooms:giga/matrix/debug/force_well_next` plus direct-Well module/retry/bounds diagnostics.
- Equalized monoroom weights: all six are equal at eligible Y112; at Y64/Y160, 48b is remapped uniformly across all five eligible rooms.
- Raised Entity/one-shot Soul Speed spawn cue from -10 dB to -5 dB.
- Portal relocation now plays its sand cue at both the old and new portal positions.
- Replaced C-wall chase-start and turn cues with `block.bone_block.break` at -12 semitones; turns remain 5 dB below chase start.
- Kept the -20 dB, +12-semitone Elytra movement layer spatial at the C-wall controller so volume follows proximity.
- Advanced monoroom pool to v6, content layout to v5 and runtime guard to v41.
- Hostile TP visibility and Spawn Blink entry remain open focused defects.

## RC3.68.38 — Audio Pass 1b Test

- Removed the untested `ambient.cave` fallback from C-wall movement start.
- Removed the untested `ambient.warped_forest.mood` fallback from complete entomb.
- Complete entomb now layers `block.chest.close` at -12 semitones with `block.netherrack.step` at -6 semitones and -6 dB.
- Updated the C-wall audition commands and current sound-design documentation.
- No gameplay, worldgen, Director, Entity, Blink, Roof Escape or pacing changes.

## RC3.68.37 — Audio Pass 1 Test

- Replaced Entity and one-shot spawn cues with the 13-sample Soul Speed family at -12 semitones and -10 dB; removed disappearance and chase heartbeat cues.
- Added carpet footsteps while the scripted Entity actually moves.
- Cleaned 125 repeated portal-scan clicks; portal appearance now uses the Entity rupture sand cue.
- Added edge-triggered portal entry flanger from two `block.portal.trigger` layers at +6 semitones / -6 dB.
- Added C-wall movement layers, turn cues and complete-entomb closure layers.
- Added one-tick, -30 dB, +12-semitone anvil cues only on bone-block to ochre-froglight Blink transitions.
- Kept Roof Escape silent.
- Exact `cave18` and `warped_forest/creak4` files cannot be addressed from a pure datapack; this test uses their vanilla event-family fallbacks.
- C-wall hit sound is deferred because the current C-wall has no attackable interaction hitbox.
- Hostile relocation visibility and failed Spawn Blink entry remain open non-audio issues.

## RC3.68.36 — Release Candidate

- Restored normal labyrinth structure generation at Y16, Y64, Y112 and Y160 while preserving the roof override.
- Disabled automatic composite 48b success/failure trace messages by default; manual trace and direct-lab commands remain available.
- Restricted composite 48b to structure origin Y112 only, corresponding to playable space beginning at Y113.
- Y64 and Y160 slots now deterministically remap any 48b ticket to an eligible 24/32 variant.
- Force-next-48b now survives Wells and all two-room layouts until a Y112 single-room plan is written.
- Kept four center variants with fixed orientation; all center rotation logic remains removed.
- Advanced content layout to v4 and runtime guard to v39.
- No Director, Entity, C-wall, Blink, Roof Escape, sound or pacing changes.

## RC3.68.35 — 48b Fixed-Center Diagnostic Hotfix

- Removed all center-module rotations from composite 48b generation.
- The center still selects one of four authored NBT variants, always with `rotation none`.
- Updated the direct 48b lab to test center variant c2 without rotation.
- Kept the diagnostic worldgen isolation and composite-progress watchdog from RC3.68.34.
- No gameplay pacing, Director, Entity, C-wall, Roof Escape, Spawn Blink, or sound changes.


## RC3.68.34 — 48b Diagnostic Isolation
- Disabled normal labyrinth structure overrides for a clear spectator inspection world.
- Fixed composite progress being misclassified as a stalled builder step.
- Added per-module variant/rotation/place/probe tracing.
- Added a direct nine-module 48b laboratory independent from the planner and Wells.
- Kept the upper-floor Y112/Y160 eligibility rule for natural 48b generation.

## RC3.68.33 — Upper-Only Composite 48b / Reliable Force Debug

- Fixed `force_48b_next`: in two-room mode it previously forced the primary room at origin Y64, often invisible from the Y113 test floor, while the other horizontal candidate could independently be a visible well.
- Composite 48b is now eligible only at origins Y112 and Y160, corresponding to playable interiors Y113 and Y161.
- Lower Y64 monoroom slots can no longer select 48b naturally. A forbidden 48b ticket is deterministically redistributed among the four 24/32 entries, preserving 48a at 10%.
- The force flag now survives wells and lower rooms, and is consumed only when an eligible upper 48b plan is actually written.
- Added exact last-forced origin coordinates plus planned/forced/completed/module diagnostics to the monoroom pool status.
- Monoroom pool schema advanced to v5, content layout to v3, runtime guard to 36.

## RC3.68.32 — Composite 48b / Roof Advancement Margin

- Roof Escape Overworld arrival lowered from Y265 to Y264: vanilla advancement threshold is 50 vertical blocks under Levitation; Y264 is three blocks below the highest safe integer target from the minimum Y218 trigger.
- Added monoroom pool v4 with 24a/24b/32a/32b at 20% each and 48a/48b at 10% each.
- Added composite monoroom 48b: nine independently selected 16×48×16 modules, placed progressively one module per builder pulse.
- Added independent deterministic center rotation.
- Added the four requested duplicated modules: 3e/4e from 2e and 3w/4w from 2w.
- Runtime guard advanced to 35 and now expects monoroom pool version 4.
- Death-screen Spawn Blink now takes one final position sample on the death edge so a solo player sees the blink near the fixed kill-screen camera.


## RC3.68.31 — Spawn Blink Recovery / Roof Y265 / NBT Refresh

- Fixed Spawn Blink retries that rescanned the same 7×7 patch twelve times; appearance events now search thirteen progressive nearby patches.
- Restored online disappearance blinks using scoreboard-sampled last Backrooms coordinates, without per-player tracker markers.
- Death disappearance uses the same bounded last-position route; roof Y208+ remains excluded.
- Lowered Roof Escape Overworld arrival from Y301 to Y265 while retaining Levitation-only stabilization for 120 ticks.
- Refreshed level_16b/16c/16d and monoroom_24a/24b NBT assets.
- Audited the composite 48b delivery: 32/36 modules received; runtime integration remains disabled until four east/west variants are supplied.
- Runtime guard bumped to 34 and primary status labels synchronized to the current candidate.

## RC3.68.30 — Runtime Guard Emergency Hotfix

- Fixed a critical runtime guard mismatch: the monoroom pool schema is version 3, but `runtime/ensure_ready` incorrectly expected version 1.
- The mismatch caused `runtime/bootstrap_core` and `init` to execute every tick while Giga runtime was enabled, repeatedly attempting to create scoreboard objectives and eventually stalling Paper.
- Pool recovery now reloads only the monoroom pool instead of rerunning the full bootstrap.
- Runtime storage guard bumped to 33.
- Removed a redundant second static matrix source-cache load during `/reload`.
- No gameplay, pacing, NBT, sound, Director, Entity, C-wall, Blink, or Roof Escape behavior changed.

## RC3.68.29 — Clean Foundation

- Renamed the active `simple_director` namespace to `director`.
- Roof jump now applies Levitation only; post-teleport hold increased from 80 to 120 ticks.
- Full vanilla-yellow leather suit now suppresses C-wall Slowness and Darkness. Pursuit, entombing and configured damage remain active.
- Added `/function backrooms:director/admin/force_oneshot_here`.
- Removed the disconnected pre-Blink-Lite implementation and the disabled hub/safe-room no-op functions.
- Rebuilt the public documentation while preserving all historical notes in an indexed archive.
- Kept the one-shot timers unchanged pending controlled QA.

## RC3.68.28 — General Audit Candidate

- Fixed multiplayer-safe death-screen handling.
- Added independent Roof Escape origin cleanup and deterministic marker matching.
- Excluded roof players from Director drivers.
- Replaced global Hostile reveal scheduling with per-visual cloak timers.

## RC3.68.27

- Cloaked Hostile relocation before teleport.
- Increased one-shot frequency on floors Y65–160.

## RC3.68.25–26

- Introduced the Levitation-hold Roof Escape route.
- Added Spawn Blink lifecycle handling and Dead Screen Guard.

A complete experimental history is preserved in `docs/history/`.
