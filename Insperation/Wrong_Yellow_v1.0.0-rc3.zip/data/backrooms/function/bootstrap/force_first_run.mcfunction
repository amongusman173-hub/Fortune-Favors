# Forces prewarm now, without waiting for /reload.
function backrooms:bootstrap/first_run
