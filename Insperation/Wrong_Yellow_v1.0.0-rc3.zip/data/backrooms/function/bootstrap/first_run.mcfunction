# first-run hub placement disabled. Keep only the bootstrap flag.
data modify storage backrooms:state bootstrap_done set value 1b
