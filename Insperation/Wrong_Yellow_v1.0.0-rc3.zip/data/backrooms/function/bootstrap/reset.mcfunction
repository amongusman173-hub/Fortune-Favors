# Remove the flag to retest first-launch behavior on the next /reload.
data remove storage backrooms:state bootstrap_done
