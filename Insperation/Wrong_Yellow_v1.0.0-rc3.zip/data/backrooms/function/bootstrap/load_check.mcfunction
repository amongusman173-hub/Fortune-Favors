# no hub/safe-room bootstrap placement.
execute unless data storage backrooms:state {bootstrap_done:1b} run function backrooms:bootstrap/first_run
