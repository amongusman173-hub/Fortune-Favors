# Mark the bootstrap as done. Useful when Backrooms region files already exist.
data modify storage backrooms:state bootstrap_done set value 1b
