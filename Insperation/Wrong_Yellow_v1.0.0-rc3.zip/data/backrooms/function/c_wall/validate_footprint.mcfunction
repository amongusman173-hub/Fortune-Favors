# C-wall narrow-spawn rule.
# A C-wall can manifest in cramped spaces: only the manifestation centre must be brown_carpet.
# The 5x5 display body is visual-only and may overlap narrow geometry; LOS decides whether it may lock the player.
scoreboard players set #cw_valid br_cw_tmp 1
execute unless block ~ ~ ~ minecraft:brown_carpet run scoreboard players set #cw_valid br_cw_tmp 0
