# Restore smooth display movement one tick after an instant snap-repose.
execute as @e[type=minecraft:marker,tag=br_cw_controller,scores={br_cw_snap_restore=1..}] at @s run function backrooms:c_wall/render/set_visual_teleport_smooth
scoreboard players set @e[type=minecraft:marker,tag=br_cw_controller,scores={br_cw_snap_restore=1..}] br_cw_snap_restore 0

# Natural instances keep their sampled brightness. Do not cancel because the local light changed.
execute as @e[type=minecraft:marker,tag=br_cw_controller,scores={br_cw_state=0}] at @s run function backrooms:c_wall/state_idle
execute as @e[type=minecraft:marker,tag=br_cw_controller,scores={br_cw_state=1}] at @s run function backrooms:c_wall/state_tracking
execute as @e[type=minecraft:marker,tag=br_cw_controller,scores={br_cw_state=2}] at @s run function backrooms:c_wall/state_closing

# Contamination must remain per-tick while an actual C-wall is present, but it now uses 3 AABB bars instead of 65 display probes.
function backrooms:c_wall/contact_tick

# Safety: orphan visuals cannot survive without a nearby controller, but this does not need to run every tick.
scoreboard players add #cw_orphan_tick br_cw_tmp 1
execute if score #cw_orphan_tick br_cw_tmp matches 20.. run scoreboard players set #cw_orphan_tick br_cw_tmp 0
execute if score #cw_orphan_tick br_cw_tmp matches 0 as @e[tag=br_cw_visual] at @s unless entity @e[type=minecraft:marker,tag=br_cw_controller,distance=..80,limit=1] run kill @s

# Additional orphan safety: if a controller survives without visuals, remove it on the same 1s orphan cadence.
execute if score #cw_orphan_tick br_cw_tmp matches 0 as @e[type=minecraft:marker,tag=br_cw_controller] at @s unless entity @e[tag=br_cw_visual,distance=..80,limit=1] run kill @s
