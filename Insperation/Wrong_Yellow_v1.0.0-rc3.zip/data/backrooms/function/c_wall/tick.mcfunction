# C-wall runtime. Natural spawn timing is owned by Director.
scoreboard players set #cw_lock_delay br_cw_cfg 0
execute unless score #cw_controller_present br_cw_tmp matches -2147483648..2147483647 run function backrooms:c_wall/reconcile_active
scoreboard players add #cw_reconcile_tick br_cw_tmp 1
execute if score #cw_reconcile_tick br_cw_tmp matches 20.. run scoreboard players set #cw_reconcile_tick br_cw_tmp 0
execute if score #cw_reconcile_tick br_cw_tmp matches 0 run function backrooms:c_wall/reconcile_active
scoreboard players add #cw_init_tick br_cw_tmp 1
execute if score #cw_init_tick br_cw_tmp matches 20.. run scoreboard players set #cw_init_tick br_cw_tmp 0
execute if score #cw_init_tick br_cw_tmp matches 0 as @a[tag=!br_cw_cd_ready] run function backrooms:c_wall/init_player
# If pressure is alive but no controller is currently placed, keep the 5-minute window ticking and retry once/sec.
execute if score #cw_pressure_timer br_cw_tmp matches 1.. unless score #cw_controller_present br_cw_tmp matches 1.. run scoreboard players remove #cw_pressure_timer br_cw_tmp 1
execute if score #cw_pressure_timer br_cw_tmp matches ..0 unless score #cw_controller_present br_cw_tmp matches 1.. run function backrooms:c_wall/pressure/expire
execute if score #cw_init_tick br_cw_tmp matches 0 if score #cw_pressure_timer br_cw_tmp matches 1.. unless score #cw_controller_present br_cw_tmp matches 1.. run function backrooms:c_wall/pressure/retry
execute as @a[tag=br_cw_entombed] at @s run function backrooms:c_wall/tomb_tick
execute if score #cw_controller_present br_cw_tmp matches 1.. in backrooms:backrooms run function backrooms:c_wall/active_tick
