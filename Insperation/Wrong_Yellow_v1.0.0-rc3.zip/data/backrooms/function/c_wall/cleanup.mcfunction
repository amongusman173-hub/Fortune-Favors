# Debug/manual cleanup for the current C-wall manifestation. Does not remove final smooth_sandstone tomb blocks.
function backrooms:c_wall/cleanup_silent
scoreboard players add #cw_cleanup_runs br_cw_diag 1
tellraw @a {"text":"[WY C-wall] cleaned loaded C-wall controllers/displays.","color":"yellow"}
