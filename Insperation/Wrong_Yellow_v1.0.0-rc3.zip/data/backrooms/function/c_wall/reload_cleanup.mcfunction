scoreboard players set #cw_pressure_timer br_cw_tmp 0
scoreboard players set #cw_relocate_timer br_cw_tmp 0
scoreboard players set #cw_pressure_floor br_cw_tmp 0
# Remove technical C-wall entities on reload to avoid duplicate displays/controllers.
function backrooms:c_wall/cleanup_silent
