# Dispatch pose_close_16 according to br_cw_facing. 0=east, 1=west, 2=south, 3=north.
execute if score @s br_cw_facing matches 1 run function backrooms:c_wall/render/pose_close_16_west
execute if score @s br_cw_facing matches 2 run function backrooms:c_wall/render/pose_close_16_south
execute if score @s br_cw_facing matches 3 run function backrooms:c_wall/render/pose_close_16_north
execute unless score @s br_cw_facing matches 1..3 run function backrooms:c_wall/render/pose_close_16_east
