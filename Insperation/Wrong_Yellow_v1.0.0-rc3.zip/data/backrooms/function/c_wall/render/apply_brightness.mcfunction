# Apply uniform brightness captured at spawn. No dynamic resampling while the C-wall moves.
scoreboard players operation #cw_light br_cw_tmp = @s br_cw_light
execute if score @s br_cw_light matches 0 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:0,sky:0}}
execute if score @s br_cw_light matches 1 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:1,sky:1}}
execute if score @s br_cw_light matches 2 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:2,sky:2}}
execute if score @s br_cw_light matches 3 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:3,sky:3}}
execute if score @s br_cw_light matches 4 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:4,sky:4}}
execute if score @s br_cw_light matches 5 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:5,sky:5}}
execute if score @s br_cw_light matches 6 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:6,sky:6}}
execute if score @s br_cw_light matches 7 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:7,sky:7}}
execute if score @s br_cw_light matches 8 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:8,sky:8}}
execute if score @s br_cw_light matches 9 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:9,sky:9}}
execute if score @s br_cw_light matches 10 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:10,sky:10}}
execute if score @s br_cw_light matches 11 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:11,sky:11}}
execute if score @s br_cw_light matches 12 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:12,sky:12}}
execute if score @s br_cw_light matches 13 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:13,sky:13}}
execute if score @s br_cw_light matches 14 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:14,sky:14}}
execute if score @s br_cw_light matches 15 as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {brightness:{block:15,sky:15}}
