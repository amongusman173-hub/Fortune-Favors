# Capture the C-wall fixed brightness once at spawn. Executed as/at the controller.
# Sample point: formation centre at Y+1, i.e. just above the carpet/floor layer.
# The resulting score is stored on the controller and never recalculated during movement.
scoreboard players set @s br_cw_light 5
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_0 run scoreboard players set @s br_cw_light 0
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_1 run scoreboard players set @s br_cw_light 1
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_2 run scoreboard players set @s br_cw_light 2
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_3 run scoreboard players set @s br_cw_light 3
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_4 run scoreboard players set @s br_cw_light 4
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_5 run scoreboard players set @s br_cw_light 5
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_6 run scoreboard players set @s br_cw_light 6
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_7 run scoreboard players set @s br_cw_light 7
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_8 run scoreboard players set @s br_cw_light 8
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_9 run scoreboard players set @s br_cw_light 9
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_10 run scoreboard players set @s br_cw_light 10
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_11 run scoreboard players set @s br_cw_light 11
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_12 run scoreboard players set @s br_cw_light 12
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_13 run scoreboard players set @s br_cw_light 13
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_14 run scoreboard players set @s br_cw_light 14
execute positioned ~ ~1 ~ if predicate backrooms:c_wall/light_15 run scoreboard players set @s br_cw_light 15
scoreboard players operation #cw_light br_cw_tmp = @s br_cw_light
