# once chase starts, all hidden-inside displays become real C-wall again.
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=br_cw_hidden_inside,tag=br_cw_layer_base] run data merge entity @s {block_state:{Name:"minecraft:cut_sandstone"}}
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=br_cw_hidden_inside,tag=br_cw_layer_wood] run data merge entity @s {block_state:{Name:"minecraft:stripped_birch_wood",Properties:{axis:"y"}}}
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=br_cw_hidden_inside] run tag @s remove br_cw_hidden_inside
execute if score #cw_overlay br_cw_cfg matches 1.. run function backrooms:c_wall/overlay/apply
