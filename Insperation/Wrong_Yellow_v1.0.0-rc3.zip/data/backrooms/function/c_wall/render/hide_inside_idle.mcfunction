# hide C-wall block_displays that spawned inside real blocks while idle.
# This prevents z-fighting/texture overlays in narrow corridors. They are restored on chase lock.
# Clear blocks intentionally include air/light/brown carpet via #backrooms:c_wall_los_clear.
scoreboard players set #cw_hidden_inside_now br_cw_tmp 0
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=!br_cw_hidden_inside] at @s unless block ~ ~ ~ #backrooms:c_wall_los_clear run tag @s add br_cw_hidden_inside
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=br_cw_hidden_inside] at @s unless block ~ ~ ~ #backrooms:c_wall_los_clear run scoreboard players add #cw_hidden_inside_now br_cw_tmp 1
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=br_cw_hidden_inside] run data merge entity @s {block_state:{Name:"minecraft:air"},Glowing:0b}
scoreboard players operation #cw_hidden_inside br_cw_diag += #cw_hidden_inside_now br_cw_tmp
