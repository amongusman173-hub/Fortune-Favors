# Restore smooth linear glide after one tick of instant snap-rotation.
execute as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {teleport_duration:2}
