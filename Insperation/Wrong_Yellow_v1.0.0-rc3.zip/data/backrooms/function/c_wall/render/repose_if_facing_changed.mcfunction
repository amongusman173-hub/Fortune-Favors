# Snap-rotate/switch the 65 displays only when facing changed.
# force teleport_duration=0 for the pose tick so orientation cannot visually ease.
execute unless score @s br_cw_prev_facing = @s br_cw_facing unless entity @s[tag=br_cw_no_turn_sound] run function backrooms:c_wall/sound/turn
execute unless score @s br_cw_prev_facing = @s br_cw_facing run function backrooms:c_wall/render/set_visual_teleport_instant
execute unless score @s br_cw_prev_facing = @s br_cw_facing run function backrooms:c_wall/render/pose_initial
execute unless score @s br_cw_prev_facing = @s br_cw_facing run scoreboard players set @s br_cw_snap_restore 1
execute unless score @s br_cw_prev_facing = @s br_cw_facing run scoreboard players operation @s br_cw_prev_facing = @s br_cw_facing
