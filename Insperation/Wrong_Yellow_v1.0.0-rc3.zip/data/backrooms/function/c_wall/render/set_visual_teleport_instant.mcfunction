# Rare snap-rotation helper. Data merge is allowed here because it only runs when facing changes, not every tick.
execute as @e[type=minecraft:block_display,tag=br_cw_visual,distance=..80] run data merge entity @s {teleport_duration:0}
