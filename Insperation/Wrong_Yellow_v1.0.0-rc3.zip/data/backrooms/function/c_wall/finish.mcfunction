function backrooms:c_wall/sound/stop_move
scoreboard players set #cw_pressure_timer br_cw_tmp 0
scoreboard players set #cw_relocate_timer br_cw_tmp 0
scoreboard players set #cw_pressure_floor br_cw_tmp 0
# if this C-wall actually entered event movement, complete Event Lock.
execute if entity @s[tag=br_cw_chase] run function backrooms:event_lock/complete_cwall
function backrooms:c_wall/end_cycle_cooldown
scoreboard players add #cw_finished br_cw_diag 1
tag @a remove br_cw_los_visible
tag @a remove br_cw_target
scoreboard players set #cw_controller_present br_cw_tmp 0
kill @e[tag=br_cw]

tag @a remove br_cw_retarget_candidate
