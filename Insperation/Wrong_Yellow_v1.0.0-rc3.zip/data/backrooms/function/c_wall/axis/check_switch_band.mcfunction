# dynamic axis handoff during chase.
# @s = C-wall controller. The wall keeps its locked axis, but if it reaches/crosses
# the player's current coordinate on that axis, it immediately releases the segment
# so the next tick can choose the other axis. This makes the chase feel like:
# slide on one axis -> corridor-align with player -> take next axis.
execute unless entity @a[tag=br_cw_target,limit=1] run return 0
execute store result score @s br_cw_x run data get entity @s Pos[0] 100
execute store result score @s br_cw_z run data get entity @s Pos[2] 100
execute as @a[tag=br_cw_target,limit=1,sort=nearest] store result score #cw_tx br_cw_tmp run data get entity @s Pos[0] 100
execute as @a[tag=br_cw_target,limit=1,sort=nearest] store result score #cw_tz br_cw_tmp run data get entity @s Pos[2] 100
scoreboard players operation #cw_dx br_cw_tmp = #cw_tx br_cw_tmp
scoreboard players operation #cw_dx br_cw_tmp -= @s br_cw_x
scoreboard players operation #cw_dz br_cw_tmp = #cw_tz br_cw_tmp
scoreboard players operation #cw_dz br_cw_tmp -= @s br_cw_z
scoreboard players set #cw_neg br_cw_tmp -1
scoreboard players operation #cw_abs_dx br_cw_tmp = #cw_dx br_cw_tmp
scoreboard players operation #cw_abs_dz br_cw_tmp = #cw_dz br_cw_tmp
execute if score #cw_abs_dx br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dx br_cw_tmp *= #cw_neg br_cw_tmp
execute if score #cw_abs_dz br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dz br_cw_tmp *= #cw_neg br_cw_tmp

# Moving on X: switch once the wall is in the player's X corridor and the next axis still matters, or once it has crossed the player.
execute if score @s br_cw_axis matches 1 if score #cw_abs_dx br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dz br_cw_tmp > #cw_axis_switch_band_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 1 if score #cw_abs_dx br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dz br_cw_tmp > #cw_axis_switch_band_x100 br_cw_cfg run scoreboard players set @s br_cw_axis_remaining 0
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 0 if score #cw_dx br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 0 if score #cw_dx br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_axis_remaining 0
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 1 if score #cw_dx br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 1 if score #cw_dx br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis_remaining 0

# Moving on Z: switch once the wall is in the player's Z corridor and the next axis still matters, or once it has crossed the player.
execute if score @s br_cw_axis matches 2 if score #cw_abs_dz br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dx br_cw_tmp > #cw_axis_switch_band_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 2 if score #cw_abs_dz br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dx br_cw_tmp > #cw_axis_switch_band_x100 br_cw_cfg run scoreboard players set @s br_cw_axis_remaining 0
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 2 if score #cw_dz br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 2 if score #cw_dz br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_axis_remaining 0
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 3 if score #cw_dz br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis 0
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 3 if score #cw_dz br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis_remaining 0
