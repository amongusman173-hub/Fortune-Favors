# Target left the C-wall vertical band (C-wall Y-1 .. Y+4). Y-2 and Y+5 immediately stop the event.
# stop the event immediately; the wall returns to inert idle for 10s, can be reacquired normally, then ruptures with FX; display visibility is preserved after a visible event.
function backrooms:c_wall/sound/stop_move
execute if entity @s[tag=br_cw_chase] run function backrooms:event_lock/complete_cwall
tag @a remove br_cw_target
tag @a remove br_cw_los_visible
tag @a remove br_cw_chase
tag @s remove br_cw_chase
tag @s add br_cw_vertical_lost
tag @s remove br_cw_pressure
scoreboard players set @s br_cw_state 0
scoreboard players set @s br_cw_timer 0
scoreboard players set @s br_cw_nav_timer 0
scoreboard players set @s br_cw_ybad 200
scoreboard players set @s br_cw_axis 0
scoreboard players set @s br_cw_axis_remaining 0
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @a[distance=..48] {"text":"[WY C-wall] vertical floor loss: event stopped; wall will rupture if not reacquired in 10s.","color":"dark_gray"}
