# Debug overlay for visible C-wall block_displays.
# hidden-inside idle displays stay non-glowing until chase reveal.
execute as @e[tag=br_cw_visual,tag=!br_cw_hidden_inside] run data merge entity @s {Glowing:1b}
execute as @e[tag=br_cw_visual,tag=br_cw_hidden_inside] run data merge entity @s {Glowing:0b}
