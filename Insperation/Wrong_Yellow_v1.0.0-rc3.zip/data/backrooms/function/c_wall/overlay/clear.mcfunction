# Remove debug overlay from C-wall block_displays.
execute as @e[tag=br_cw_visual] run data merge entity @s {Glowing:0b}
