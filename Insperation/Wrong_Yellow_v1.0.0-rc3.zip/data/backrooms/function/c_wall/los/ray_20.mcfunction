# C-wall heart LOS ray step 20. @s = candidate player.
# block obstruction is checked before short-range hit acceptance.
execute unless block ~ ~ ~ #backrooms:c_wall_los_clear run return 0
execute if entity @s[distance=..1.8] run scoreboard players set #cw_los br_cw_tmp 1
execute if score #cw_los br_cw_tmp matches 1 run return 1
execute if block ~ ~ ~ #backrooms:c_wall_los_clear positioned ^ ^ ^0.5 run function backrooms:c_wall/los/ray_21
