# @s = candidate player. Execution position remains the C-wall controller centre.
# Conservative heart LOS: start near the C-wall core, raycast toward the player's eyes.
# This prevents outer C-wall protrusions from detecting a player through/around walls.
scoreboard players set #cw_los br_cw_tmp 0
execute positioned ~ ~1.20 ~ facing entity @s eyes positioned ^ ^ ^0.5 run function backrooms:c_wall/los/ray_00
execute if score #cw_los br_cw_tmp matches 1 run tag @s add br_cw_los_visible
execute if score #cw_los br_cw_tmp matches 1 run scoreboard players add #cw_los_seen br_cw_diag 1
execute unless score #cw_los br_cw_tmp matches 1 run scoreboard players add #cw_los_blocked br_cw_diag 1
