# C-wall configurable constants; lock delay forced instant for server-scoreboard safety.
# Server cycle: a C-wall pressure cycle wakes every 15..40 minutes, then keeps reseeding until a player actually locks it.
scoreboard players set #cw_cd_min br_cw_cfg 18000
scoreboard players set #cw_cd_max br_cw_cfg 48000
scoreboard players set #cw_retry_cd br_cw_cfg 1200
scoreboard players set #cw_lock_delay br_cw_cfg 0
scoreboard players set #cw_close_ticks br_cw_cfg 20
scoreboard players set #cw_y_mismatch_cancel br_cw_cfg 200
scoreboard players set #cw_abandon_range br_cw_cfg 64
scoreboard players set #cw_move_step_x100 br_cw_cfg 18
scoreboard players set #cw_move_diag_step_x100 br_cw_cfg 0
scoreboard players set #cw_lock_radius_x10 br_cw_cfg 100
scoreboard players set #cw_display_brightness br_cw_cfg 5
scoreboard players set #cw_tomb_damage_ticks br_cw_cfg 10
scoreboard players set #cw_debug_forced br_cw_cfg 1
scoreboard players set #cw_tomb_damage_enabled br_cw_cfg 0
scoreboard players set #cw_nav_recalc_ticks br_cw_cfg 20
scoreboard players set #cw_axis_min_x100 br_cw_cfg 19

# debug/spawn-distance policy: spawn 32, reseed only beyond 40.
scoreboard players set #cw_spawn_distance br_cw_cfg 32
scoreboard players set #cw_reseed_extra br_cw_cfg 8
scoreboard players set #cw_reseed_distance br_cw_cfg 40
scoreboard players add #cw_overlay br_cw_cfg 0

# switch movement axis when aligned/crossed within a 1.8-block corridor band.
scoreboard players set #cw_axis_switch_band_x100 br_cw_cfg 180
