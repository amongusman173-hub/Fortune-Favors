# idempotent final capture centre pull.
# Run AS the locked target AT the locked target, only during C-wall closing.
# Important: do NOT use "positioned ~0.5 ... align ... positioned ~0.5" here.
# That expression is not idempotent: once the player is exactly at .5, the next tick can advance them by one block again.
# Correct rule: snap X/Z to the centre of the block currently occupied by the player's feet.
# Example: X=1.1 Z=-14.8 -> X=1.5 Z=-14.5. Repeating the command from X=1.5 Z=-14.5 stays there.
execute align xz positioned ~0.5 ~ ~0.5 run tp @s ~ ~ ~
scoreboard players add #cw_center_pulls br_cw_diag 1
