# CLOSING: brutal snap close, short final centre pull, then entomb.
# vertical loss still wins during closing; stairs/floor changes return to idle, no climax.
execute unless entity @a[tag=br_cw_target,tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,distance=..48,limit=1] run function backrooms:c_wall/cancel
execute unless entity @a[tag=br_cw_target,tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,distance=..48,limit=1] run return 0
scoreboard players set #cw_ycheck br_cw_tmp 0
execute positioned ~-512 ~-1 ~-512 if entity @a[tag=br_cw_target,tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,dx=1024,dy=5,dz=1024,limit=1] run scoreboard players set #cw_ycheck br_cw_tmp 1
execute unless score #cw_ycheck br_cw_tmp matches 1 run function backrooms:c_wall/state_vertical_lost
execute unless score #cw_ycheck br_cw_tmp matches 1 run return 0
# During the last 4 ticks before real-block entombing, snap the locked target to the same nearest block centre used by entomb_at_player.
# This is intentionally short-range: it fixes edge-of-block escapes without pulling a player back from far away.
execute as @a[tag=br_cw_target,tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,distance=..2.25,limit=1,sort=nearest] at @s run function backrooms:c_wall/center_target_for_entomb
# If the target genuinely slips out before entombing, reopen instantly and keep hunting.
execute unless entity @a[tag=br_cw_target,distance=..2.25,limit=1] run function backrooms:c_wall/reset_to_tracking
execute if score @s br_cw_state matches 2 run scoreboard players remove @s br_cw_timer 1
execute if score @s br_cw_state matches 2 if score @s br_cw_timer matches ..0 run function backrooms:c_wall/entomb
