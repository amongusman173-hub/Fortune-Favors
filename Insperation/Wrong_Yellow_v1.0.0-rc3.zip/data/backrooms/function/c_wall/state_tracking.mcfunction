# TRACKING: fixed on the first approaching player.
# if target leaves vertical band, C-wall stops and returns to idle. No climax.
# Activation/chase band is C-wall Y-1 .. Y+4.
scoreboard players set #cw_target_invalid br_cw_tmp 0
execute unless entity @a[tag=br_cw_target,limit=1] run scoreboard players set #cw_target_invalid br_cw_tmp 1
execute unless entity @a[tag=br_cw_target,gamemode=survival,limit=1] unless entity @a[tag=br_cw_target,gamemode=adventure,limit=1] run scoreboard players set #cw_target_invalid br_cw_tmp 1
execute as @a[tag=br_cw_target,limit=1] at @s unless predicate backrooms:in_backrooms run scoreboard players set #cw_target_invalid br_cw_tmp 1
execute if entity @a[tag=br_cw_target,tag=br_dead_screen,limit=1] run scoreboard players set #cw_target_invalid br_cw_tmp 1
execute if score #cw_target_invalid br_cw_tmp matches 1.. run function backrooms:c_wall/cancel
execute if score #cw_target_invalid br_cw_tmp matches 1.. run return 0

# Vertical loss: target is not inside C-wall Y-1..Y+4. Return to idle, do not kill/reseed.
scoreboard players set #cw_ycheck br_cw_tmp 0
execute positioned ~-512 ~-1 ~-512 if entity @a[tag=br_cw_target,tag=!backrooms_leaving,gamemode=!creative,gamemode=!spectator,dx=1024,dy=5,dz=1024,limit=1] run scoreboard players set #cw_ycheck br_cw_tmp 1
execute unless score #cw_ycheck br_cw_tmp matches 1 run function backrooms:c_wall/state_vertical_lost
execute unless score #cw_ycheck br_cw_tmp matches 1 run return 0
scoreboard players set @s br_cw_ybad 0

# Sustained chase does not complete a climax by itself; completion happens when the chase ends.
execute if score @s br_cw_nav_timer matches 0..1200 run scoreboard players add @s br_cw_nav_timer 1

# Re-evaluate the nearest eligible player once per second. The current target participates
# in the same nearest-player selection, so the lock changes only when another player is closer.
scoreboard players add @s br_cw_timer 1
execute if score @s br_cw_timer matches 20.. run function backrooms:c_wall/retarget_nearest
execute if score @s br_cw_timer matches 20.. run scoreboard players set @s br_cw_timer 0

scoreboard players set #cw_lock_delay br_cw_cfg 0
function backrooms:c_wall/move_toward_target
execute if entity @a[tag=br_cw_target,distance=..1.25,limit=1] run function backrooms:c_wall/start_closing
