# Linear group movement along a locked axis segment.
# axis-lock remains, but alignment/crossing is checked every tick.
# The C-wall slides along one axis until it enters the player's corridor band on that axis,
# then the next tick chooses the other/current needed axis.
execute if score @s br_cw_axis matches 0 run function backrooms:c_wall/choose_trajectory
execute if score @s br_cw_axis matches 1.. run function backrooms:c_wall/render/repose_if_facing_changed
# Move controller and all displays together. This preserves the current pose and avoids re-rendering 65 cells every tick.
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 0 as @e[tag=br_cw,distance=..80] at @s run tp @s ~0.18 ~ ~
execute if score @s br_cw_axis matches 1 if score @s br_cw_facing matches 1 as @e[tag=br_cw,distance=..80] at @s run tp @s ~-0.18 ~ ~
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 2 as @e[tag=br_cw,distance=..80] at @s run tp @s ~ ~ ~0.18
execute if score @s br_cw_axis matches 2 if score @s br_cw_facing matches 3 as @e[tag=br_cw,distance=..80] at @s run tp @s ~ ~ ~-0.18
# Dynamic axis handoff: no waiting for an obsolete full-distance segment if the target moved.
execute if score @s br_cw_axis matches 1.. run function backrooms:c_wall/axis/check_switch_band
# Fallback segment consumption remains as a safety guard.
execute if score @s br_cw_axis matches 1.. run scoreboard players operation @s br_cw_axis_remaining -= #cw_move_step_x100 br_cw_cfg
execute if score @s br_cw_axis_remaining matches ..0 run scoreboard players set @s br_cw_axis 0
function backrooms:c_wall/sound/move_loop_tick
