# Set br_cw_facing from controller to the selected player.
# facing: 0=east, 1=west, 2=south, 3=north.
scoreboard players set @s br_cw_facing 0
execute store result score @s br_cw_x run data get entity @s Pos[0] 100
execute store result score @s br_cw_z run data get entity @s Pos[2] 100
execute as @a[tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,distance=..64,limit=1,sort=nearest] store result score #cw_tx br_cw_tmp run data get entity @s Pos[0] 100
execute as @a[tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,distance=..64,limit=1,sort=nearest] store result score #cw_tz br_cw_tmp run data get entity @s Pos[2] 100
scoreboard players operation #cw_dx br_cw_tmp = #cw_tx br_cw_tmp
scoreboard players operation #cw_dx br_cw_tmp -= @s br_cw_x
scoreboard players operation #cw_dz br_cw_tmp = #cw_tz br_cw_tmp
scoreboard players operation #cw_dz br_cw_tmp -= @s br_cw_z
scoreboard players set #cw_neg br_cw_tmp -1
scoreboard players operation #cw_abs_dx br_cw_tmp = #cw_dx br_cw_tmp
scoreboard players operation #cw_abs_dz br_cw_tmp = #cw_dz br_cw_tmp
execute if score #cw_abs_dx br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dx br_cw_tmp *= #cw_neg br_cw_tmp
execute if score #cw_abs_dz br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dz br_cw_tmp *= #cw_neg br_cw_tmp
# Dominant axis chooses the mouth direction.
execute if score #cw_abs_dx br_cw_tmp >= #cw_abs_dz br_cw_tmp if score #cw_dx br_cw_tmp matches 0.. run scoreboard players set @s br_cw_facing 0
execute if score #cw_abs_dx br_cw_tmp >= #cw_abs_dz br_cw_tmp if score #cw_dx br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_facing 1
execute if score #cw_abs_dz br_cw_tmp > #cw_abs_dx br_cw_tmp if score #cw_dz br_cw_tmp matches 0.. run scoreboard players set @s br_cw_facing 2
execute if score #cw_abs_dz br_cw_tmp > #cw_abs_dx br_cw_tmp if score #cw_dz br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_facing 3
