# @s = newly selected player. One global C-wall exists, so transfer the target tag atomically.
tag @a[tag=br_cw_target] remove br_cw_target
tag @s add br_cw_target
scoreboard players add #cw_retargets br_cw_diag 1
execute as @e[type=minecraft:marker,tag=br_cw_controller,limit=1] at @s run function backrooms:c_wall/on_retarget
