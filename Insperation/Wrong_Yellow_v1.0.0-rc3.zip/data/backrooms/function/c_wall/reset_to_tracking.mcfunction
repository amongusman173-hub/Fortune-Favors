scoreboard players add #cw_resets br_cw_diag 1
scoreboard players set @s br_cw_state 1
scoreboard players set @s br_cw_timer 0
scoreboard players set @s br_cw_nav_timer 0
scoreboard players set @s br_cw_axis 0
scoreboard players set @s br_cw_axis_remaining 0
function backrooms:c_wall/render/reveal_hidden_inside
function backrooms:c_wall/choose_trajectory
function backrooms:c_wall/render/repose_if_facing_changed
