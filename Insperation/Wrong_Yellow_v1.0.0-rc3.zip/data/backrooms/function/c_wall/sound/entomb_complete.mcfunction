# Complete closure: chest close plus down-pitched Netherrack footstep texture.
playsound minecraft:block.chest.close master @a[distance=..32] ~ ~ ~ 1.0 0.5
playsound minecraft:block.netherrack.step master @a[distance=..32] ~ ~ ~ 0.501187 0.707107
