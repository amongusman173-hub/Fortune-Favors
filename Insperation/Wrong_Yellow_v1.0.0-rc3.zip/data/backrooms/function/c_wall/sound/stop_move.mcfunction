stopsound @a[tag=br_cw_elytra_a] master minecraft:item.elytra.flying
stopsound @a[tag=br_cw_elytra_b] hostile minecraft:item.elytra.flying
# Safety for listeners from older builds or interrupted chase cycles.
stopsound @a[distance=..48] master minecraft:item.elytra.flying
stopsound @a[distance=..48] hostile minecraft:item.elytra.flying
tag @a remove br_cw_elytra_a
tag @a remove br_cw_elytra_b
scoreboard players set @s br_cw_sound 0
