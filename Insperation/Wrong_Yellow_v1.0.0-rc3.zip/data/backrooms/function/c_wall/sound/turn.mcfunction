# Rotation cue: bone block one octave down, raised another 2 dB from 0.35 to 0.440663.
playsound minecraft:block.bone_block.break master @a[distance=..32] ~ ~ ~ 0.440663 0.5
