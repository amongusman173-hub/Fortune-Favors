# Elytra loop envelope in pure datapack:
# A(master) starts at tick 0, B(hostile) at tick 20, A stops at 25;
# A restarts at 40, B stops five ticks later. Each play lasts 25 ticks with a 5-tick overlap.
# Alternating categories are required because /stopsound cannot address individual sound instances.
scoreboard players add @s br_cw_sound 1
execute if score @s br_cw_sound matches 5 run stopsound @a[tag=br_cw_elytra_b] hostile minecraft:item.elytra.flying
execute if score @s br_cw_sound matches 5 run tag @a remove br_cw_elytra_b
execute if score @s br_cw_sound matches 20 run playsound minecraft:item.elytra.flying hostile @a[distance=..32] ~ ~ ~ 0.070795 2.0
execute if score @s br_cw_sound matches 20 run tag @a[distance=..32] add br_cw_elytra_b
execute if score @s br_cw_sound matches 25 run stopsound @a[tag=br_cw_elytra_a] master minecraft:item.elytra.flying
execute if score @s br_cw_sound matches 25 run tag @a remove br_cw_elytra_a
execute if score @s br_cw_sound matches 40.. run playsound minecraft:item.elytra.flying master @a[distance=..32] ~ ~ ~ 0.070795 2.0
execute if score @s br_cw_sound matches 40.. run tag @a[distance=..32] add br_cw_elytra_a
execute if score @s br_cw_sound matches 40.. run scoreboard players set @s br_cw_sound 0
