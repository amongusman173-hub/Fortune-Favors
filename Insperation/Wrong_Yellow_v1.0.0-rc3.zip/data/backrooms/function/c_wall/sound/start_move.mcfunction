# Chase start: restore the original respawn-anchor charge, add the reinforced bone-block impact,
# then start Elytra channel A. Two audio categories are alternated later so each loop can be cut
# after 25 ticks while preserving a 5-tick overlap with the next 20-tick refresh.
playsound minecraft:block.respawn_anchor.charge master @a[distance=..32] ~ ~ ~ 0.35 0.5
playsound minecraft:block.bone_block.break master @a[distance=..32] ~ ~ ~ 0.440663 0.5
stopsound @a[tag=br_cw_elytra_a] master minecraft:item.elytra.flying
stopsound @a[tag=br_cw_elytra_b] hostile minecraft:item.elytra.flying
tag @a remove br_cw_elytra_a
tag @a remove br_cw_elytra_b
playsound minecraft:item.elytra.flying master @a[distance=..32] ~ ~ ~ 0.070795 2.0
tag @a[distance=..32] add br_cw_elytra_a
scoreboard players set @s br_cw_sound 0
