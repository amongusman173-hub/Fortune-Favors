scoreboard players set #cw_pressure_timer br_cw_tmp 0
scoreboard players set #cw_relocate_timer br_cw_tmp 0
scoreboard players set #cw_pressure_floor br_cw_tmp 0
# Silent cleanup for reload/debug internals. Does not remove final smooth_sandstone tomb blocks.
execute in backrooms:backrooms if entity @e[tag=br_cw,limit=1] run kill @e[tag=br_cw]
execute as @a[tag=br_cw_target] run tag @s remove br_cw_target
execute as @a[tag=br_cw_chase] run tag @s remove br_cw_chase
execute as @a[tag=br_cw_entombed] run tag @s remove br_cw_entombed
scoreboard players set #cw_controller_present br_cw_tmp 0
scoreboard players set #cw_controllers br_cw_tmp 0

tag @a remove br_cw_los_visible
stopsound @a[tag=br_cw_elytra_a] master minecraft:item.elytra.flying
stopsound @a[tag=br_cw_elytra_b] hostile minecraft:item.elytra.flying
tag @a remove br_cw_elytra_a
tag @a remove br_cw_elytra_b

# prevent stale tomb_timer debug values after cleanup/tag removal.
scoreboard players set @a br_cw_tomb_timer 0
scoreboard players set @a br_cw_tomb_hit 0

tag @a remove br_cw_retarget_candidate
