# Beige Backrooms dust/sand rupture on currently visible C-wall displays.
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=!br_cw_hidden_inside,distance=..80] at @s run particle minecraft:dust{color:[0.77,0.68,0.48],scale:0.75} ~ ~0.45 ~ 0.10 0.08 0.10 0.01 3 force @a[distance=..32]
execute as @e[type=minecraft:block_display,tag=br_cw_visual,tag=!br_cw_hidden_inside,distance=..80] at @s run particle minecraft:dust{color:[0.88,0.80,0.60],scale:0.50} ~ ~0.85 ~ 0.06 0.12 0.06 0.005 2 force @a[distance=..32]
playsound minecraft:block.sand.break master @a[distance=..32] ~ ~ ~ 0.42 0.72
