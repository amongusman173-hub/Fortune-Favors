# Place a real 3x3 cross of smooth_sandstone, five blocks high, centred on the block occupied by the target.
# use the same idempotent X/Z block-centre rule as center_target_for_entomb.
# - Player TP centre point: align xz -> block origin, then +0.5/+0.5.
# - Physical tomb centre block: positioned ~ ~-0.01 ~ align xyz -> same occupied block on X/Z and floor/carpet block on Y.
# Example: player X=1.1 Y=210 Z=-14.8 is pulled to X=1.5 Y=210 Z=-14.5, then the cross centre block is X=1 Z=-15.
execute positioned ~ ~-0.01 ~ align xyz run fill ~-1 ~ ~ ~1 ~4 ~ minecraft:smooth_sandstone replace
execute positioned ~ ~-0.01 ~ align xyz run fill ~ ~ ~-1 ~ ~4 ~1 minecraft:smooth_sandstone replace
scoreboard players add #cw_entombs br_cw_diag 1
tag @s add br_cw_entombed
scoreboard players set @s br_cw_tomb_timer 160
scoreboard players set @s br_cw_tomb_hit 0
function backrooms:c_wall/sound/entomb_complete
