# Initialise a player for C-wall runtime. Natural frequency is server-wide.
scoreboard players set @s br_cw_cd 0
tag @s add br_cw_cd_ready
