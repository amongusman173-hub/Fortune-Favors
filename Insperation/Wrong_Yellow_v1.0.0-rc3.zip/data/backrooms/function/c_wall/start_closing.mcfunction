# Snap close: no ease, no long pose cascade.
function backrooms:c_wall/sound/stop_move
scoreboard players set @s br_cw_state 2
scoreboard players set @s br_cw_timer 4
scoreboard players set @s br_cw_ybad 0
playsound minecraft:block.piston.contract master @a[distance=..32] ~ ~ ~ 0.45 0.55
function backrooms:c_wall/render/set_visual_teleport_instant
function backrooms:c_wall/render/pose_close_30
scoreboard players set @s br_cw_snap_restore 1
