# Full vanilla-yellow leather suit blocks only C-wall slowness and darkness.
# It does not stop pursuit, collision, entombing or optional in-wall damage.
execute if items entity @s armor.head minecraft:leather_helmet[minecraft:dyed_color=16701501] if items entity @s armor.chest minecraft:leather_chestplate[minecraft:dyed_color=16701501] if items entity @s armor.legs minecraft:leather_leggings[minecraft:dyed_color=16701501] if items entity @s armor.feet minecraft:leather_boots[minecraft:dyed_color=16701501] run return 0
effect give @s minecraft:slowness 2 2 true
effect give @s minecraft:darkness 2 0 true
