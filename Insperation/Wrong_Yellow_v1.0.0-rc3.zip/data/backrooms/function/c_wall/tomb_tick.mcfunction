# Post-entomb pressure while the player is physically inside the tomb.
# A full yellow suit suppresses slowness/darkness but not entombing or configured damage.
execute if entity @s[gamemode=creative] run tag @s remove br_cw_entombed
execute if entity @s[gamemode=spectator] run tag @s remove br_cw_entombed
execute unless entity @s[tag=br_cw_entombed] run return 0
scoreboard players remove @s br_cw_tomb_timer 1
execute if score @s br_cw_tomb_timer matches ..0 run tag @s remove br_cw_entombed
execute unless entity @s[tag=br_cw_entombed] run return 0
# If neither feet nor head are still inside smooth sandstone, the player has escaped. Effects then expire naturally after about 2s.
execute unless block ~ ~ ~ minecraft:smooth_sandstone unless block ~ ~1 ~ minecraft:smooth_sandstone run tag @s remove br_cw_entombed
execute unless entity @s[tag=br_cw_entombed] run return 0
function backrooms:c_wall/apply_pressure_effects
scoreboard players add @s br_cw_tomb_hit 1
execute if score #cw_tomb_damage_enabled br_cw_cfg matches 1 if score @s br_cw_tomb_hit matches 10.. run damage @s 2 minecraft:in_wall
execute if score #cw_tomb_damage_enabled br_cw_cfg matches 1 if score @s br_cw_tomb_hit matches 10.. run scoreboard players add #cw_tomb_damage br_cw_diag 1
execute if score @s br_cw_tomb_hit matches 10.. run scoreboard players set @s br_cw_tomb_hit 0
