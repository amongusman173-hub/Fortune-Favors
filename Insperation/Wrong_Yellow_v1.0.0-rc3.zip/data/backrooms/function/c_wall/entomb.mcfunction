# ENTOMBING: real smooth_sandstone cross; no /kill.
execute as @a[tag=br_cw_target,limit=1,sort=nearest] at @s run function backrooms:c_wall/entomb_at_player
function backrooms:c_wall/finish
