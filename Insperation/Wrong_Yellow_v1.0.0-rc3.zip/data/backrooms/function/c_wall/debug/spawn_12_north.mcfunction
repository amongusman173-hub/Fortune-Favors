# Spawn a debug C-wall 12 blocks north of the executing player.
execute unless entity @s run tellraw @a {"text":"[WY C-wall] Run this function as a player.","color":"red"}
execute unless entity @s run return 0
execute unless predicate backrooms:in_backrooms run tellraw @s {"text":"[WY C-wall] This debug spawn is Backrooms-only.","color":"red"}
execute unless predicate backrooms:in_backrooms run return 0
execute if entity @s[gamemode=creative] run tellraw @s {"text":"[WY C-wall] Switch out of Creative/Spectator to be targetable.","color":"yellow"}
execute if entity @s[gamemode=creative] run return 0
execute if entity @s[gamemode=spectator] run tellraw @s {"text":"[WY C-wall] Switch out of Creative/Spectator to be targetable.","color":"yellow"}
execute if entity @s[gamemode=spectator] run return 0
function backrooms:c_wall/cleanup_silent
scoreboard players set #cw_spawned br_cw_tmp 0
execute positioned ~ ~-0.01 ~-12 if block ~ ~ ~ minecraft:brown_carpet positioned ~ ~ ~ align xyz run function backrooms:c_wall/spawn_debug_here
execute unless score #cw_spawned br_cw_tmp matches 1 positioned ~ ~-1.01 ~-12 if block ~ ~ ~ minecraft:brown_carpet positioned ~ ~ ~ align xyz run function backrooms:c_wall/spawn_debug_here
execute if score #cw_spawned br_cw_tmp matches 1 run tellraw @s {"text":"[WY C-wall] debug C-wall spawned 12 blocks north.","color":"green"}
execute unless score #cw_spawned br_cw_tmp matches 1 run tellraw @s {"text":"[WY C-wall] no valid 5x5 carpet footprint 12 blocks north.","color":"red"}
