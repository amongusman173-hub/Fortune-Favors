function backrooms:c_wall/cleanup
