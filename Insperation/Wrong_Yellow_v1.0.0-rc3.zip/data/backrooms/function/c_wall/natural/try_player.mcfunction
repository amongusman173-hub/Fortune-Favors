scoreboard players add #cw_attempts br_cw_diag 1
tag @s add br_cw_spawn_origin
scoreboard players set #cw_spawned br_cw_tmp 0
execute store result score @s br_cw_rand run random value 0..7
execute if score @s br_cw_rand matches 0 run function backrooms:c_wall/natural/try_order00
execute if score @s br_cw_rand matches 1 run function backrooms:c_wall/natural/try_order01
execute if score @s br_cw_rand matches 2 run function backrooms:c_wall/natural/try_order02
execute if score @s br_cw_rand matches 3 run function backrooms:c_wall/natural/try_order03
execute if score @s br_cw_rand matches 4 run function backrooms:c_wall/natural/try_order04
execute if score @s br_cw_rand matches 5 run function backrooms:c_wall/natural/try_order05
execute if score @s br_cw_rand matches 6 run function backrooms:c_wall/natural/try_order06
execute if score @s br_cw_rand matches 7 run function backrooms:c_wall/natural/try_order07
execute if score #cw_spawned br_cw_tmp matches 1 run scoreboard players add #cw_spawns br_cw_diag 1
# If no valid footprint was found, retry on the next natural tick. Do not spend the 15..40 min cycle yet.
tag @s remove br_cw_spawn_origin
