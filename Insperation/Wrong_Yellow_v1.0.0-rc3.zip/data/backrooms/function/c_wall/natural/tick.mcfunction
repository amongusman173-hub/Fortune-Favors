# one server-wide C-wall pressure cycle.
# When the server clock reaches 0, keep reseeding near eligible Backrooms players until someone actually approaches/locks it.
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_cw_controller,limit=1] run return 0
execute unless score #cw_cycle_cd br_cw_cd matches ..0 run return 0
tag @a remove br_cw_candidate
execute as @a[tag=br_cw_cd_ready,tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator] at @s if predicate backrooms:in_backrooms run tag @s add br_cw_candidate
execute unless entity @a[tag=br_cw_candidate,limit=1] run return 0
execute as @a[tag=br_cw_candidate,limit=1,sort=random] at @s run function backrooms:c_wall/natural/try_player
tag @a remove br_cw_candidate
