# @s = C-wall controller. Mark players in the valid Y-1..Y+4 chase band, then
# select the nearest from the controller position. The current target is included.
tag @a remove br_cw_retarget_candidate
execute positioned ~-64 ~-1 ~-64 run tag @a[tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,dx=128,dy=5,dz=128] add br_cw_retarget_candidate
execute as @a[tag=br_cw_retarget_candidate,limit=1,sort=nearest] unless entity @s[tag=br_cw_target] run function backrooms:c_wall/retarget_to_self
tag @a remove br_cw_retarget_candidate
