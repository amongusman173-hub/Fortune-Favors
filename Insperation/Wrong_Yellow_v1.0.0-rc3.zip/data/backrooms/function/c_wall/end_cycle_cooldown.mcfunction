# End a natural C-wall pressure cycle after a real chase/entomb/floor escape.
execute store result score #cw_cycle_cd br_cw_cd run random value 18000..48000
scoreboard players add #cw_cycle_ends br_cw_diag 1
