# IDLE/PRESSURE: visible idle C-wall, no target yet.
# Pressure window is a C-wall behavior. Director only starts it; Event Lock is requested only when LOS turns into a real event.
execute if score #cw_pressure_timer br_cw_tmp matches 1.. run scoreboard players remove #cw_pressure_timer br_cw_tmp 1
execute if score #cw_pressure_timer br_cw_tmp matches 1.. run scoreboard players remove #cw_relocate_timer br_cw_tmp 1
execute if score #cw_pressure_timer br_cw_tmp matches ..0 if entity @s[tag=br_cw_pressure] run function backrooms:c_wall/pressure/expire
execute unless entity @s[type=minecraft:marker,tag=br_cw_controller] run return 0

# If a real event lost the player vertically, the inert wall lingers briefly, then ruptures instead of idling forever.
# Valid C-wall event band is now controller Y-1 .. Y+4. Y-2 and Y+5 are outside.
execute if entity @s[tag=br_cw_vertical_lost] run scoreboard players remove @s br_cw_ybad 1
execute if entity @s[tag=br_cw_vertical_lost] if score @s br_cw_ybad matches ..0 run function backrooms:c_wall/vanish_with_fx
execute unless entity @s[type=minecraft:marker,tag=br_cw_controller] run return 0

tag @a remove br_cw_floor_candidate
execute positioned ~-10 ~-1 ~-10 run tag @a[tag=!backrooms_leaving,tag=!br_dead_screen,gamemode=!creative,gamemode=!spectator,dx=20,dy=5,dz=20] add br_cw_floor_candidate
# Relocate only when the player has really moved farther than 40 blocks from the idle wall.
# No more reseeding merely because the player is outside the old +10 wake-up box.
execute unless entity @a[tag=br_cw_floor_candidate,limit=1] run function backrooms:c_wall/pressure/relocate_if_due
execute unless entity @a[tag=br_cw_floor_candidate,limit=1] run return 0
execute if entity @a[tag=br_cw_target,limit=1] run return 0

# LOS is deliberately cadenced: one C-wall max, 5-tick wake-up granularity, no per-tick ray spam.
scoreboard players add @s br_cw_nav_timer 1
execute unless score @s br_cw_nav_timer matches 5.. run return 0
scoreboard players set @s br_cw_nav_timer 0
tag @a remove br_cw_los_visible
scoreboard players set #cw_los br_cw_tmp 0
execute as @a[tag=br_cw_floor_candidate,limit=1,sort=nearest] run function backrooms:c_wall/los/test_candidate
# If a close player has no LOS yet, keep the idle wall where it is; pressure relocation is distance-based only.
execute unless entity @a[tag=br_cw_los_visible,tag=br_cw_floor_candidate,limit=1] run return 0

function backrooms:event_lock/acquire_cwall
execute unless score #event_acquired br_event_lock matches 1 if score #sd_debug br_sd_tmp matches 1.. run tellraw @a[distance=..48] {"text":"[WY C-wall] LOS reached, but Event Lock is occupied; pressure stays idle.","color":"dark_gray"}
execute unless score #event_acquired br_event_lock matches 1 run return 0
execute as @a[tag=br_cw_los_visible,tag=br_cw_floor_candidate,limit=1,sort=nearest] run tag @s add br_cw_target
execute if entity @a[tag=br_cw_target,limit=1] run tag @s add br_cw_chase
execute if entity @a[tag=br_cw_target,limit=1] run tag @s remove br_cw_vertical_lost
execute if entity @a[tag=br_cw_target,limit=1] run tag @s remove br_cw_pressure
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players add #cw_locks br_cw_diag 1
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_state 1
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_timer 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_nav_timer 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_ybad 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_axis 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set @s br_cw_axis_remaining 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set #cw_pressure_timer br_cw_tmp 0
execute if entity @a[tag=br_cw_target,limit=1] run scoreboard players set #cw_relocate_timer br_cw_tmp 0
execute if entity @a[tag=br_cw_target,limit=1] run function backrooms:c_wall/render/reveal_hidden_inside
execute if entity @a[tag=br_cw_target,limit=1] run function backrooms:c_wall/choose_trajectory
execute if entity @a[tag=br_cw_target,limit=1] run tag @s add br_cw_no_turn_sound
execute if entity @a[tag=br_cw_target,limit=1] run function backrooms:c_wall/render/repose_if_facing_changed
execute if entity @a[tag=br_cw_target,limit=1] run tag @s remove br_cw_no_turn_sound
execute if entity @a[tag=br_cw_target,limit=1] run function backrooms:c_wall/sound/start_move
tag @a remove br_cw_los_visible
