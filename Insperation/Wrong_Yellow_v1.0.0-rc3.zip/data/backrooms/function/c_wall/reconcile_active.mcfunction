# Rebuild the cheap C-wall controller-present flag.
# One controller is expected, but the count stays useful for debug sanity.
scoreboard players set #cw_controllers br_cw_tmp 0
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_cw_controller] run scoreboard players add #cw_controllers br_cw_tmp 1
scoreboard players set #cw_controller_present br_cw_tmp 0
execute if score #cw_controllers br_cw_tmp matches 1.. run scoreboard players set #cw_controller_present br_cw_tmp 1
