# Spawn C-wall controller and visuals at aligned centre.
function backrooms:c_wall/validate_footprint
execute unless score #cw_valid br_cw_tmp matches 1 run scoreboard players add #cw_failed br_cw_diag 1
execute unless score #cw_valid br_cw_tmp matches 1 run return 0
execute if entity @e[tag=br_cw_controller,limit=1] run return 0
summon minecraft:marker ~ ~ ~ {Tags:["br_cw","br_cw_controller","br_cw_new"],PersistenceRequired:1b}
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_state 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_timer 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_ybad 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_tmp 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_light 5
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_axis 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_facing 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_prev_facing -1
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_nav_timer 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_axis_remaining 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_snap_restore 0
scoreboard players set @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] br_cw_sound 0
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/sample_light
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/face_nearest_player
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/spawn_initial
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/set_visual_teleport_instant
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/pose_initial
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] run scoreboard players operation @s br_cw_prev_facing = @s br_cw_facing
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] run scoreboard players set @s br_cw_snap_restore 1
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/apply_brightness
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] at @s run function backrooms:c_wall/render/hide_inside_idle
execute as @e[type=minecraft:marker,tag=br_cw_new,distance=..1,limit=1,sort=nearest] run tag @s remove br_cw_new
scoreboard players set #cw_spawned br_cw_tmp 1
scoreboard players set #cw_controller_present br_cw_tmp 1
scoreboard players add #cw_debug_spawns br_cw_diag 1
