# Called while a survival/adventure player intersects the C-wall display volume.
# Effects refresh only while contact continues; the full yellow suit is immune to these effects.
function backrooms:c_wall/apply_pressure_effects
