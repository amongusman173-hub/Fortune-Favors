# Choose a straight movement segment toward the locked player.
# if one axis is already aligned within the corridor band, choose the other axis.
# Otherwise choose the dominant axis. Axis handoff during movement is dynamic via axis/check_switch_band.
# facing: 0=east, 1=west, 2=south, 3=north.
execute store result score @s br_cw_x run data get entity @s Pos[0] 100
execute store result score @s br_cw_z run data get entity @s Pos[2] 100
execute as @a[tag=br_cw_target,limit=1,sort=nearest] store result score #cw_tx br_cw_tmp run data get entity @s Pos[0] 100
execute as @a[tag=br_cw_target,limit=1,sort=nearest] store result score #cw_tz br_cw_tmp run data get entity @s Pos[2] 100
scoreboard players operation #cw_dx br_cw_tmp = #cw_tx br_cw_tmp
scoreboard players operation #cw_dx br_cw_tmp -= @s br_cw_x
scoreboard players operation #cw_dz br_cw_tmp = #cw_tz br_cw_tmp
scoreboard players operation #cw_dz br_cw_tmp -= @s br_cw_z
scoreboard players set #cw_neg br_cw_tmp -1
scoreboard players operation #cw_abs_dx br_cw_tmp = #cw_dx br_cw_tmp
scoreboard players operation #cw_abs_dz br_cw_tmp = #cw_dz br_cw_tmp
execute if score #cw_abs_dx br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dx br_cw_tmp *= #cw_neg br_cw_tmp
execute if score #cw_abs_dz br_cw_tmp matches ..-1 run scoreboard players operation #cw_abs_dz br_cw_tmp *= #cw_neg br_cw_tmp
scoreboard players set @s br_cw_axis 0
scoreboard players set @s br_cw_axis_remaining 0

# Corridor-priority: if already aligned on X, take Z; if aligned on Z, take X.
execute if score @s br_cw_axis matches 0 if score #cw_abs_dx br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dz br_cw_tmp >= #cw_axis_min_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 2
execute if score @s br_cw_axis matches 0 if score #cw_abs_dz br_cw_tmp <= #cw_axis_switch_band_x100 br_cw_cfg if score #cw_abs_dx br_cw_tmp >= #cw_axis_min_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 1

# Otherwise choose dominant axis.
execute if score @s br_cw_axis matches 0 if score #cw_abs_dx br_cw_tmp >= #cw_abs_dz br_cw_tmp if score #cw_abs_dx br_cw_tmp >= #cw_axis_min_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 1
execute if score @s br_cw_axis matches 0 if score #cw_abs_dz br_cw_tmp > #cw_abs_dx br_cw_tmp if score #cw_abs_dz br_cw_tmp >= #cw_axis_min_x100 br_cw_cfg run scoreboard players set @s br_cw_axis 2

# If both axes are tiny but capture did not trigger yet, nudge along the largest residual axis.
execute if score @s br_cw_axis matches 0 if score #cw_abs_dx br_cw_tmp >= #cw_abs_dz br_cw_tmp if score #cw_abs_dx br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis 1
execute if score @s br_cw_axis matches 0 if score #cw_abs_dz br_cw_tmp > #cw_abs_dx br_cw_tmp if score #cw_abs_dz br_cw_tmp matches 1.. run scoreboard players set @s br_cw_axis 2

execute if score @s br_cw_axis matches 1 run scoreboard players operation @s br_cw_axis_remaining = #cw_abs_dx br_cw_tmp
execute if score @s br_cw_axis matches 2 run scoreboard players operation @s br_cw_axis_remaining = #cw_abs_dz br_cw_tmp
execute if score @s br_cw_axis matches 1 if score #cw_dx br_cw_tmp matches 0.. run scoreboard players set @s br_cw_facing 0
execute if score @s br_cw_axis matches 1 if score #cw_dx br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_facing 1
execute if score @s br_cw_axis matches 2 if score #cw_dz br_cw_tmp matches 0.. run scoreboard players set @s br_cw_facing 2
execute if score @s br_cw_axis matches 2 if score #cw_dz br_cw_tmp matches ..-1 run scoreboard players set @s br_cw_facing 3
