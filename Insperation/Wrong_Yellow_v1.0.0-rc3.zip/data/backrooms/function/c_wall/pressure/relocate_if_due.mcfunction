# Relocate pressure only when the tracked player has really left the idle C-wall area.
# no more disappearing/reseeding merely because the player is not within the old +10 LOS wake-up box.
# Executed at the current C-wall controller.
execute if score #cw_pressure_timer br_cw_tmp matches 1.. if score #cw_relocate_timer br_cw_tmp matches ..0 unless entity @a[gamemode=survival,distance=..40,limit=1] unless entity @a[gamemode=adventure,distance=..40,limit=1] run function backrooms:c_wall/pressure/relocate
