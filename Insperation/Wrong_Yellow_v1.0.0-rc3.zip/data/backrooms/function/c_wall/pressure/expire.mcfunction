# Pressure expired without becoming a real event.
scoreboard players set #cw_pressure_timer br_cw_tmp 0
scoreboard players set #cw_relocate_timer br_cw_tmp 0
scoreboard players set #cw_pressure_floor br_cw_tmp 0
scoreboard players add #cw_pressure_expired br_cw_diag 1
kill @e[tag=br_cw]
scoreboard players set #cw_controller_present br_cw_tmp 0
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @a[tag=br_sd_driver] {"text":"[WY C-wall] pressure expired without event.","color":"gold"}
