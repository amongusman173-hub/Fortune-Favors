# Called while pressure is alive but no controller currently exists.
scoreboard players set #cw_spawned br_cw_tmp 0
execute if score #cw_pressure_timer br_cw_tmp matches ..0 run return 0
execute if entity @e[type=minecraft:marker,tag=br_cw_controller,limit=1] run return 0
execute if score #cw_pressure_floor br_cw_tmp matches 1 as @a[tag=br_sd_floor1,limit=1,sort=random] at @s run function backrooms:c_wall/natural/try_player
execute if score #cw_pressure_floor br_cw_tmp matches 2 as @a[tag=br_sd_floor2,limit=1,sort=random] at @s run function backrooms:c_wall/natural/try_player
execute if score #cw_pressure_floor br_cw_tmp matches 3 as @a[tag=br_sd_floor3,limit=1,sort=random] at @s run function backrooms:c_wall/natural/try_player
execute if score #cw_pressure_floor br_cw_tmp matches 4 as @a[tag=br_sd_floor4,limit=1,sort=random] at @s run function backrooms:c_wall/natural/try_player
execute if score #cw_spawned br_cw_tmp matches 1 as @e[type=minecraft:marker,tag=br_cw_controller,limit=1,sort=nearest] run tag @s add br_cw_pressure
execute if score #cw_spawned br_cw_tmp matches 1 store result score #cw_relocate_timer br_cw_tmp run random value 500..900
