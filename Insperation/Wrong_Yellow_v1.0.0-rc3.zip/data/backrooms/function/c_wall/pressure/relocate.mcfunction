# Pressure relocation: if the player never crosses the idle C-wall, move the idle manifestation and keep the same 5 min pressure window.
execute if score #cw_pressure_timer br_cw_tmp matches ..0 run return 0
scoreboard players add #cw_pressure_relocated br_cw_diag 1
kill @e[tag=br_cw]
scoreboard players set #cw_controller_present br_cw_tmp 0
execute store result score #cw_relocate_timer br_cw_tmp run random value 500..900
function backrooms:c_wall/pressure/retry
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @a[tag=br_sd_driver] {"text":"[WY C-wall] pressure relocated.","color":"gold"}
