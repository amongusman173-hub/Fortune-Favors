# @s = chosen player. C-wall owns the pressure window; Director only calls this.
scoreboard players set #cw_spawned br_cw_tmp 0
execute if score #cw_pressure_timer br_cw_tmp matches 1.. run return 0
execute if entity @e[type=minecraft:marker,tag=br_cw_controller,limit=1] run return 0
scoreboard players set #cw_pressure_timer br_cw_tmp 6000
execute store result score #cw_relocate_timer br_cw_tmp run random value 500..900
scoreboard players add #cw_pressure_started br_cw_diag 1
function backrooms:c_wall/natural/try_player
execute if score #cw_spawned br_cw_tmp matches 1 as @e[type=minecraft:marker,tag=br_cw_controller,limit=1,sort=nearest] run tag @s add br_cw_pressure
execute unless score #cw_spawned br_cw_tmp matches 1 run scoreboard players set #cw_controller_present br_cw_tmp 0
