# Kill a visible C-wall manifestation with a beige dust/sand rupture.
# Used for sustained vertical-floor loss, not for ordinary pressure relocation.
function backrooms:c_wall/sound/stop_move
function backrooms:c_wall/fx/rupture_visible_displays
execute if entity @s[tag=br_cw_chase] run function backrooms:event_lock/complete_cwall
scoreboard players set #cw_pressure_timer br_cw_tmp 0
scoreboard players set #cw_relocate_timer br_cw_tmp 0
scoreboard players set #cw_pressure_floor br_cw_tmp 0
tag @a remove br_cw_target
tag @a remove br_cw_los_visible
tag @a remove br_cw_entombed
tag @s remove br_cw_pressure
tag @s remove br_cw_vertical_lost
scoreboard players set #cw_controller_present br_cw_tmp 0
kill @e[tag=br_cw]

tag @a remove br_cw_retarget_candidate
