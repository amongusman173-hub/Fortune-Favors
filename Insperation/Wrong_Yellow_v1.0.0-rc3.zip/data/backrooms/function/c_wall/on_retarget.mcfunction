# @s = C-wall controller. Keep the event and pressure state; only refresh navigation and audio.
scoreboard players set @s br_cw_axis 0
scoreboard players set @s br_cw_axis_remaining 0
scoreboard players set @s br_cw_timer 0
function backrooms:c_wall/choose_trajectory
tag @s add br_cw_no_turn_sound
function backrooms:c_wall/render/repose_if_facing_changed
tag @s remove br_cw_no_turn_sound
function backrooms:c_wall/sound/start_move
