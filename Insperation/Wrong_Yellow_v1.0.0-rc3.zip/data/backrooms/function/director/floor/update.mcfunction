execute store result score @s br_sd_y run data get entity @s Pos[1] 1
scoreboard players set @s br_sd_floor -1
execute if score @s br_sd_y matches 0..16 run scoreboard players set @s br_sd_floor 0
execute if score @s br_sd_y matches 17..64 run scoreboard players set @s br_sd_floor 1
execute if score @s br_sd_y matches 65..112 run scoreboard players set @s br_sd_floor 2
execute if score @s br_sd_y matches 113..160 run scoreboard players set @s br_sd_floor 3
execute if score @s br_sd_y matches 161..207 run scoreboard players set @s br_sd_floor 4
execute if score @s br_sd_y matches 208.. run scoreboard players set @s br_sd_floor 5
