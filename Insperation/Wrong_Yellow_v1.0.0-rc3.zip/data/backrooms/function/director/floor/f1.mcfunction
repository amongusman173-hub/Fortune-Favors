# Floor 1: shared density. Blink pauses unless at least one player on this floor moved during this 1s pass.
execute unless score #sd_blink_f1 br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_blink
execute if score #sd_floor1_moved br_sd_tmp matches 1.. run scoreboard players remove #sd_blink_f1 br_sd_tmp 1
execute if score #sd_floor1_moved br_sd_tmp matches 1.. if score #sd_blink_f1 br_sd_tmp matches ..0 run scoreboard players set #sd_roll_success br_sd_tmp 0
execute if score #sd_floor1_moved br_sd_tmp matches 1.. if score #sd_blink_f1 br_sd_tmp matches ..0 as @a[tag=br_sd_floor1,tag=br_sd_moving,limit=1,sort=random] at @s run function backrooms:director/blink/try
execute if score #sd_floor1_moved br_sd_tmp matches 1.. if score #sd_blink_f1 br_sd_tmp matches ..0 if score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_blink
execute if score #sd_floor1_moved br_sd_tmp matches 1.. if score #sd_blink_f1 br_sd_tmp matches ..0 unless score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_blink_short
execute unless score #sd_oneshot_f1 br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_oneshot
scoreboard players remove #sd_oneshot_f1 br_sd_tmp 1
execute if score #sd_oneshot_f1 br_sd_tmp matches ..0 run scoreboard players set #sd_roll_success br_sd_tmp 0
execute if score #sd_oneshot_f1 br_sd_tmp matches ..0 as @a[tag=br_sd_floor1,limit=1,sort=random] at @s run function backrooms:director/roll/oneshot
execute if score #sd_oneshot_f1 br_sd_tmp matches ..0 if score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_oneshot
execute if score #sd_oneshot_f1 br_sd_tmp matches ..0 unless score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_oneshot_short
execute unless score #sd_entity_f1 br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_entity
scoreboard players remove #sd_entity_f1 br_sd_tmp 1
execute if score #sd_entity_f1 br_sd_tmp matches ..0 run scoreboard players set #sd_roll_success br_sd_tmp 0
execute if score #sd_entity_f1 br_sd_tmp matches ..0 as @a[tag=br_sd_floor1,limit=1,sort=random] at @s run function backrooms:director/roll/entity
execute if score #sd_entity_f1 br_sd_tmp matches ..0 if score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_entity
execute if score #sd_entity_f1 br_sd_tmp matches ..0 unless score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_entity_short
execute unless score #sd_cwall_f1 br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_cwall
scoreboard players remove #sd_cwall_f1 br_sd_tmp 1
execute if score #sd_cwall_f1 br_sd_tmp matches ..0 run scoreboard players set #sd_roll_success br_sd_tmp 0
execute if score #sd_cwall_f1 br_sd_tmp matches ..0 as @a[tag=br_sd_floor1,limit=1,sort=random] at @s run function backrooms:director/roll/cwall
execute if score #sd_cwall_f1 br_sd_tmp matches ..0 if score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_cwall
execute if score #sd_cwall_f1 br_sd_tmp matches ..0 unless score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f1_cwall_short
