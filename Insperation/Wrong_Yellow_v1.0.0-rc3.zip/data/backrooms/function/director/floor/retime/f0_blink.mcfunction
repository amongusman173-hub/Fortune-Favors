execute store result score #sd_blink_f0 br_sd_tmp run random value 15..160
