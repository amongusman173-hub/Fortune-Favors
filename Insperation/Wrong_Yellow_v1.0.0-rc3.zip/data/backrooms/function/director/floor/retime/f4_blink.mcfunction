execute store result score #sd_blink_f4 br_sd_tmp run random value 8..38
