execute store result score #sd_blink_f1 br_sd_tmp run random value 5..15
