execute store result score #sd_entity_f3 br_sd_tmp run random value 225..585
