execute store result score #sd_entity_f2 br_sd_tmp run random value 360..765
