execute store result score #sd_cwall_f1 br_sd_tmp run random value 60..150
