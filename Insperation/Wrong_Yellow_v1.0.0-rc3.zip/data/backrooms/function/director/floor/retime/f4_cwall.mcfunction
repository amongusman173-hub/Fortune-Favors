execute store result score #sd_cwall_f4 br_sd_tmp run random value 60..360
