execute store result score #sd_oneshot_f3 br_sd_tmp run random value 10..30
