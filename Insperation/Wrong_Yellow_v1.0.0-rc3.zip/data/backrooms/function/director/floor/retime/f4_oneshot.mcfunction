execute store result score #sd_oneshot_f4 br_sd_tmp run random value 60..150
