execute store result score #sd_oneshot_f1 br_sd_tmp run random value 30..90
