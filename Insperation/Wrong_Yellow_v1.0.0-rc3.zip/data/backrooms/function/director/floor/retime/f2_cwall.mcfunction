execute store result score #sd_cwall_f2 br_sd_tmp run random value 360..900
