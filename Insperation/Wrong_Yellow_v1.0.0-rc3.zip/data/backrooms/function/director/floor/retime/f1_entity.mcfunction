execute store result score #sd_entity_f1 br_sd_tmp run random value 480..1200
