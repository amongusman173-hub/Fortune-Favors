execute store result score #sd_oneshot_f2 br_sd_tmp run random value 110..225
