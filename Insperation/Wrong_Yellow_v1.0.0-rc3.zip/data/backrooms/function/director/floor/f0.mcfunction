# Floor 0: shared density. Blink pauses unless at least one player on this floor moved during this 1s pass.
execute unless score #sd_blink_f0 br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f0_blink
execute if score #sd_floor0_moved br_sd_tmp matches 1.. run scoreboard players remove #sd_blink_f0 br_sd_tmp 1
execute if score #sd_floor0_moved br_sd_tmp matches 1.. if score #sd_blink_f0 br_sd_tmp matches ..0 run scoreboard players set #sd_roll_success br_sd_tmp 0
execute if score #sd_floor0_moved br_sd_tmp matches 1.. if score #sd_blink_f0 br_sd_tmp matches ..0 as @a[tag=br_sd_floor0,tag=br_sd_moving,limit=1,sort=random] at @s run function backrooms:director/blink/try
execute if score #sd_floor0_moved br_sd_tmp matches 1.. if score #sd_blink_f0 br_sd_tmp matches ..0 if score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f0_blink
execute if score #sd_floor0_moved br_sd_tmp matches 1.. if score #sd_blink_f0 br_sd_tmp matches ..0 unless score #sd_roll_success br_sd_tmp matches 1.. run function backrooms:director/floor/retime/f0_blink_short
