# Shared Floor Director. One pass per second; timers are global per floor, not per player.
scoreboard players add #sd_clock br_sd_tmp 1
execute if score #sd_clock br_sd_tmp matches ..19 run return 0
scoreboard players set #sd_clock br_sd_tmp 0
function backrooms:event_lock/tick

scoreboard players set #sd_drivers br_sd_tmp 0
scoreboard players set #sd_any_moved br_sd_tmp 0
scoreboard players set #sd_floor0_count br_sd_tmp 0
scoreboard players set #sd_floor1_count br_sd_tmp 0
scoreboard players set #sd_floor2_count br_sd_tmp 0
scoreboard players set #sd_floor3_count br_sd_tmp 0
scoreboard players set #sd_floor4_count br_sd_tmp 0
scoreboard players set #sd_floor5_count br_sd_tmp 0
scoreboard players set #sd_floor0_moved br_sd_tmp 0
scoreboard players set #sd_floor1_moved br_sd_tmp 0
scoreboard players set #sd_floor2_moved br_sd_tmp 0
scoreboard players set #sd_floor3_moved br_sd_tmp 0
scoreboard players set #sd_floor4_moved br_sd_tmp 0

tag @a remove br_sd_driver
tag @a remove br_sd_floor0
tag @a remove br_sd_floor1
tag @a remove br_sd_floor2
tag @a remove br_sd_floor3
tag @a remove br_sd_floor4
tag @a remove br_sd_floor5
tag @a remove br_sd_moving

execute as @a[gamemode=survival,tag=!backrooms_leaving,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run function backrooms:director/player_tick
execute as @a[gamemode=adventure,tag=!backrooms_leaving,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run function backrooms:director/player_tick

# One shared timer set per floor: density is floor-based, not multiplied by player count or distance.
execute if entity @a[tag=br_sd_floor0,limit=1] run function backrooms:director/floor/f0
execute if entity @a[tag=br_sd_floor1,limit=1] run function backrooms:director/floor/f1
execute if entity @a[tag=br_sd_floor2,limit=1] run function backrooms:director/floor/f2
execute if entity @a[tag=br_sd_floor3,limit=1] run function backrooms:director/floor/f3
execute if entity @a[tag=br_sd_floor4,limit=1] run function backrooms:director/floor/f4
