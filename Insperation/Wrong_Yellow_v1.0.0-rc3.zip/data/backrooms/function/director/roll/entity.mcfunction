scoreboard players add #sd_entity_attempt br_sd_tmp 1
scoreboard players set #sd_roll_success br_sd_tmp 0
# Warning/subliminal can exist near C-wall idle, but do not stack Entity manifestations.
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_entity,limit=1] run return 0
execute if entity @a[tag=br_hunted,limit=1] run return 0
function backrooms:entity/natural_start
scoreboard players set #sd_roll_success br_sd_tmp 1
scoreboard players add #sd_entity_started br_sd_tmp 1
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @s {"text":"[WY Director] natural Entity sequence started.","color":"dark_purple"}
