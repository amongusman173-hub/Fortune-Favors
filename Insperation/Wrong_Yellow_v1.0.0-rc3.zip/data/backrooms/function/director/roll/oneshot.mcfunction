scoreboard players add #sd_oneshot_attempt br_sd_tmp 1
scoreboard players set #sd_roll_success br_sd_tmp 0
# Never overlap with another Entity manifestation.
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_entity_attack,limit=1] run return 0
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_entity_oneshot,limit=1] run return 0
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_entity_subliminal,limit=1] run return 0
scoreboard players set @s br_tmp 0
function backrooms:entity/oneshot/appear_4_6
execute if score @s br_tmp matches 1 run scoreboard players set #sd_roll_success br_sd_tmp 1
execute if score @s br_tmp matches 1 run scoreboard players add #sd_oneshot_success br_sd_tmp 1
execute unless score @s br_tmp matches 1 run scoreboard players add #sd_oneshot_fail br_sd_tmp 1
execute if score #sd_debug br_sd_tmp matches 1.. if score @s br_tmp matches 1 run tellraw @s {"text":"[WY Director] one-shot placed.","color":"dark_purple"}
execute if score #sd_debug br_sd_tmp matches 1.. unless score @s br_tmp matches 1 run tellraw @s {"text":"[WY Director] one-shot found no valid carpet; short retry.","color":"dark_gray"}
