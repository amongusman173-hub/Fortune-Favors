scoreboard players add #sd_cwall_attempt br_sd_tmp 1
scoreboard players set #sd_roll_success br_sd_tmp 0
# C-wall pressure is owned by the C-wall module. Director only asks it to start.
execute if score #cw_pressure_timer br_cw_tmp matches 1.. run return 0
execute in backrooms:backrooms if entity @e[type=minecraft:marker,tag=br_cw_controller,limit=1] run return 0
scoreboard players operation #cw_pressure_floor br_cw_tmp = @s br_sd_floor
scoreboard players set #cw_spawned br_cw_tmp 0
function backrooms:c_wall/pressure/start
execute if score #cw_spawned br_cw_tmp matches 1 run scoreboard players set #sd_roll_success br_sd_tmp 1
execute if score #cw_spawned br_cw_tmp matches 1 run scoreboard players add #sd_cwall_success br_sd_tmp 1
execute unless score #cw_spawned br_cw_tmp matches 1 run scoreboard players add #sd_cwall_fail br_sd_tmp 1
execute if score #sd_debug br_sd_tmp matches 1.. if score #cw_spawned br_cw_tmp matches 1 run tellraw @s {"text":"[WY Director] C-wall pressure requested.","color":"gold"}
execute if score #sd_debug br_sd_tmp matches 1.. unless score #cw_spawned br_cw_tmp matches 1 run tellraw @s {"text":"[WY Director] C-wall pressure failed to place; short retry.","color":"dark_gray"}
