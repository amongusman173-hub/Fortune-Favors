# @s = eligible Backrooms player. One-second movement gate for Director blinks.
# Blinks pause while the player is physically idle; other Director timers keep running.
execute store result score @s br_sd_x run data get entity @s Pos[0] 100
execute store result score @s br_sd_z run data get entity @s Pos[2] 100
scoreboard players set @s br_sd_moved 0
# First sample initialises without counting as movement.
execute unless score @s br_sd_last_x matches -2147483648..2147483647 run scoreboard players operation @s br_sd_last_x = @s br_sd_x
execute unless score @s br_sd_last_z matches -2147483648..2147483647 run scoreboard players operation @s br_sd_last_z = @s br_sd_z
scoreboard players operation #sd_move_delta br_sd_tmp = @s br_sd_x
scoreboard players operation #sd_move_delta br_sd_tmp -= @s br_sd_last_x
execute if score #sd_move_delta br_sd_tmp matches 5.. run scoreboard players set @s br_sd_moved 1
execute if score #sd_move_delta br_sd_tmp matches ..-5 run scoreboard players set @s br_sd_moved 1
scoreboard players operation #sd_move_delta br_sd_tmp = @s br_sd_z
scoreboard players operation #sd_move_delta br_sd_tmp -= @s br_sd_last_z
execute if score #sd_move_delta br_sd_tmp matches 5.. run scoreboard players set @s br_sd_moved 1
execute if score #sd_move_delta br_sd_tmp matches ..-5 run scoreboard players set @s br_sd_moved 1
execute if score @s br_sd_moved matches 1.. run scoreboard players operation @s br_sd_last_x = @s br_sd_x
execute if score @s br_sd_moved matches 1.. run scoreboard players operation @s br_sd_last_z = @s br_sd_z
