# Roof is intentionally quiet: reset timers so coming back into a playable floor reseeds cleanly.
scoreboard players set @s br_sd_blink 0
scoreboard players set @s br_sd_oneshot 0
scoreboard players set @s br_sd_entity 0
scoreboard players set @s br_sd_cwall 0
