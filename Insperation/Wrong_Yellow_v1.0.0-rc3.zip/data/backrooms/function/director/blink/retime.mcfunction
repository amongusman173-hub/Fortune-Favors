# Blink cadence in seconds. Director-owned shared floor timers are authoritative.
# Y0/Y17/Y65 use the slower range; Y113/Y161 retain their established faster range.
execute if score @s br_sd_floor matches 0 store result score @s br_sd_blink run random value 15..160
execute if score @s br_sd_floor matches 1 store result score @s br_sd_blink run random value 15..160
execute if score @s br_sd_floor matches 2 store result score @s br_sd_blink run random value 15..160
execute if score @s br_sd_floor matches 3 store result score @s br_sd_blink run random value 11..56
execute if score @s br_sd_floor matches 4 store result score @s br_sd_blink run random value 8..38
execute if score @s br_sd_floor matches 5.. run scoreboard players set @s br_sd_blink 999999
execute if score @s br_sd_floor matches ..-1 run scoreboard players set @s br_sd_blink 999999
