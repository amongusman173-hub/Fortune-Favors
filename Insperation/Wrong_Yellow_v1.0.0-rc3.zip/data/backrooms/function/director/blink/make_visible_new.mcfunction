# @s = Director driver. Newly placed anchors are those not tagged br_sd_blink_existing.
scoreboard players operation #sd_blink_floor br_sd_tmp = @s br_sd_floor
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=!br_sd_blink_existing] run function backrooms:director/blink/mark_new_anchor
function backrooms:blink_lite/reconcile_active
