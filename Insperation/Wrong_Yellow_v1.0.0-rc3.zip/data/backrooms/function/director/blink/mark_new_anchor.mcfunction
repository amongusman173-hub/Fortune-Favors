# @s = newly created Blink Lite marker.
tag @s add br_blink_minor_visible
tag @s remove br_blink_mode_low
tag @s remove br_blink_mode_medium
tag @s add br_blink_mode_high
scoreboard players set @s br_blink_timer 12
# TTL: classic/medium 45..90s; intense 30..75s.
execute unless score #sd_blink_floor br_sd_tmp matches 4 store result score @s br_life run random value 900..1800
execute if score #sd_blink_floor br_sd_tmp matches 4 store result score @s br_life run random value 600..1500
tag @s add br_blink_ttl_init
