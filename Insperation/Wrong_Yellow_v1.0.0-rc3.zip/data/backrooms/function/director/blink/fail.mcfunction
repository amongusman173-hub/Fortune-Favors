scoreboard players set #sd_roll_success br_sd_tmp 0
scoreboard players add #sd_blink_fail br_sd_tmp 1
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @s {"text":"[WY Director] blink found no valid nearby ceiling anchor; short retry.","color":"dark_aqua"}
