scoreboard players set #sd_roll_success br_sd_tmp 1
scoreboard players add #sd_blink_success br_sd_tmp 1
execute if score #sd_debug br_sd_tmp matches 1.. run tellraw @s [{"text":"[WY Director] blink manifested floor=","color":"aqua"},{"score":{"name":"@s","objective":"br_sd_floor"}},{"text":" group="},{"score":{"name":"#sd_blink_group","objective":"br_sd_tmp"}},{"text":" active="},{"score":{"name":"#blink_active","objective":"br_blink_lite"}}]
