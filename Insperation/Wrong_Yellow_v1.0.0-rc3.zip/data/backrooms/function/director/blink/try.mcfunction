# Director-owned Blink lane. Recreates the intended stress-blink behavior without Safe/Normal/Hard cycles.
scoreboard players add #sd_blink_attempt br_sd_tmp 1
execute if score @s br_sd_floor matches 5.. run function backrooms:director/blink/retime
execute if score @s br_sd_floor matches 5.. run return 0

# Local cap: never exceed 3 active anchors around this player.
scoreboard players set #sd_blink_near br_sd_tmp 0
execute at @s as @e[type=minecraft:marker,tag=br_blink_lite_active,distance=..72] run scoreboard players add #sd_blink_near br_sd_tmp 1
execute if score #sd_blink_near br_sd_tmp matches 3.. run return 0

scoreboard players set #blink_found br_blink_lite 0
scoreboard players set #sd_blink_group br_sd_tmp 1
scoreboard players set #blink_minor_mode br_blink_lite 1

# Classic floors: often 1, rarely 2, very rarely 3. Same proportions as old Stress Normal.
execute if score @s br_sd_floor matches 0..2 store result score #sd_blink_roll br_sd_tmp run random value 0..999
execute if score @s br_sd_floor matches 0..2 if score #sd_blink_roll br_sd_tmp matches 0..79 run scoreboard players set #sd_blink_group br_sd_tmp 2
execute if score @s br_sd_floor matches 0..2 if score #sd_blink_roll br_sd_tmp matches 80..89 run scoreboard players set #sd_blink_group br_sd_tmp 3

# Medium floor: often 1, regularly 2, rarely 3.
execute if score @s br_sd_floor matches 3 store result score #sd_blink_roll br_sd_tmp run random value 0..99
execute if score @s br_sd_floor matches 3 if score #sd_blink_roll br_sd_tmp matches 0..24 run scoreboard players set #sd_blink_group br_sd_tmp 2
execute if score @s br_sd_floor matches 3 if score #sd_blink_roll br_sd_tmp matches 25..31 run scoreboard players set #sd_blink_group br_sd_tmp 3

# Intense floor: true random between 1, 2 and 3.
execute if score @s br_sd_floor matches 4 store result score #sd_blink_group br_sd_tmp run random value 1..3

scoreboard players operation #blink_minor_mode br_blink_lite = #sd_blink_group br_sd_tmp

# Capacity clamp after group roll: active=2 -> max group 1; active=1 -> max group 2.
execute if score #sd_blink_near br_sd_tmp matches 2.. if score #sd_blink_group br_sd_tmp matches 2.. run scoreboard players set #sd_blink_group br_sd_tmp 1
execute if score #sd_blink_near br_sd_tmp matches 1 if score #sd_blink_group br_sd_tmp matches 3.. run scoreboard players set #sd_blink_group br_sd_tmp 2
scoreboard players operation #blink_minor_mode br_blink_lite = #sd_blink_group br_sd_tmp

# Mark old anchors so only newly placed anchors receive Director visibility/TTL edits.
tag @e[type=minecraft:marker,tag=br_blink_lite_active] add br_sd_blink_existing
execute at @s run function backrooms:blink_lite/try_player_minor
scoreboard players set #blink_minor_mode br_blink_lite 0
execute if score #blink_found br_blink_lite matches 1 run function backrooms:director/blink/make_visible_new
execute if score #blink_found br_blink_lite matches 1 run function backrooms:director/blink/success
execute unless score #blink_found br_blink_lite matches 1 run function backrooms:director/blink/fail
tag @e[type=minecraft:marker,tag=br_sd_blink_existing] remove br_sd_blink_existing

