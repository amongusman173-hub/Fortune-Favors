# Short retry after local cap/fail.
execute store result score @s br_sd_blink run random value 6..18
