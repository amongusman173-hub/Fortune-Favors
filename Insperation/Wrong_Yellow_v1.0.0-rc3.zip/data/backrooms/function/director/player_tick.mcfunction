# @s = eligible non-dead Backrooms player. Classify first; roof is diagnostic-only and never drives events.
function backrooms:director/floor/update
execute if score @s br_sd_floor matches 5 run scoreboard players add #sd_floor5_count br_sd_tmp 1
execute if score @s br_sd_floor matches 5 run return 0

tag @s add br_sd_driver
scoreboard players add #sd_drivers br_sd_tmp 1
function backrooms:director/movement/update

execute if score @s br_sd_floor matches 0 run tag @s add br_sd_floor0
execute if score @s br_sd_floor matches 1 run tag @s add br_sd_floor1
execute if score @s br_sd_floor matches 2 run tag @s add br_sd_floor2
execute if score @s br_sd_floor matches 3 run tag @s add br_sd_floor3
execute if score @s br_sd_floor matches 4 run tag @s add br_sd_floor4

execute if score @s br_sd_floor matches 0 run scoreboard players add #sd_floor0_count br_sd_tmp 1
execute if score @s br_sd_floor matches 1 run scoreboard players add #sd_floor1_count br_sd_tmp 1
execute if score @s br_sd_floor matches 2 run scoreboard players add #sd_floor2_count br_sd_tmp 1
execute if score @s br_sd_floor matches 3 run scoreboard players add #sd_floor3_count br_sd_tmp 1
execute if score @s br_sd_floor matches 4 run scoreboard players add #sd_floor4_count br_sd_tmp 1

execute if score @s br_sd_moved matches 1.. run tag @s add br_sd_moving
execute if score @s br_sd_moved matches 1.. run scoreboard players set #sd_any_moved br_sd_tmp 1
execute if score @s br_sd_moved matches 1.. if score @s br_sd_floor matches 0 run scoreboard players add #sd_floor0_moved br_sd_tmp 1
execute if score @s br_sd_moved matches 1.. if score @s br_sd_floor matches 1 run scoreboard players add #sd_floor1_moved br_sd_tmp 1
execute if score @s br_sd_moved matches 1.. if score @s br_sd_floor matches 2 run scoreboard players add #sd_floor2_moved br_sd_tmp 1
execute if score @s br_sd_moved matches 1.. if score @s br_sd_floor matches 3 run scoreboard players add #sd_floor3_moved br_sd_tmp 1
execute if score @s br_sd_moved matches 1.. if score @s br_sd_floor matches 4 run scoreboard players add #sd_floor4_moved br_sd_tmp 1
