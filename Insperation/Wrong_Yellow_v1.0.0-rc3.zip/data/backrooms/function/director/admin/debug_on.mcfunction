scoreboard players set #sd_debug br_sd_tmp 1
function backrooms:event_lock/debug_on
tellraw @s {"text":"[WY Director] debug ON.","color":"yellow"}
