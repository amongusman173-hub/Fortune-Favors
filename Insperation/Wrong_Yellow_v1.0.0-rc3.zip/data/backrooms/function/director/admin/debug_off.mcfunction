scoreboard players set #sd_debug br_sd_tmp 0
function backrooms:event_lock/debug_off
tellraw @s {"text":"[WY Director] debug OFF.","color":"gray"}
