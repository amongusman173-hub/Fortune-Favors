# QA helper: attempt exactly one one-shot around the executing player.
execute unless predicate backrooms:in_backrooms run tellraw @s {"text":"[WY Director] Enter the Backrooms before forcing a one-shot.","color":"red"}
execute unless predicate backrooms:in_backrooms run return 0
scoreboard players set #sd_roll_success br_sd_tmp 0
function backrooms:director/roll/oneshot
execute if score #sd_roll_success br_sd_tmp matches 1.. run tellraw @s {"text":"[WY Director] Forced one-shot placed successfully.","color":"green"}
execute unless score #sd_roll_success br_sd_tmp matches 1.. run tellraw @s {"text":"[WY Director] Forced one-shot failed: no valid carpet or another Entity manifestation is active.","color":"yellow"}
