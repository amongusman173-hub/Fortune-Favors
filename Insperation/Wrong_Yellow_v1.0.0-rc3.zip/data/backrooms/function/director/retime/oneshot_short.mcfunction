execute if score @s br_sd_floor matches 2 store result score @s br_sd_oneshot run random value 10..34
execute if score @s br_sd_floor matches 3..4 store result score @s br_sd_oneshot run random value 10..30
execute unless score @s br_sd_floor matches 2..4 store result score @s br_sd_oneshot run random value 30..90
