execute store result score @s br_sd_cwall run random value 60..150
