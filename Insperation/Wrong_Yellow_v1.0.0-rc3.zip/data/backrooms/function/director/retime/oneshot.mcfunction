# Seconds; shared floor Director calls the floor-specific wrappers with the same values.
execute if score @s br_sd_floor matches 1 store result score @s br_sd_oneshot run random value 360..720
execute if score @s br_sd_floor matches 2 store result score @s br_sd_oneshot run random value 110..225
execute if score @s br_sd_floor matches 3 store result score @s br_sd_oneshot run random value 70..180
execute if score @s br_sd_floor matches 4 store result score @s br_sd_oneshot run random value 60..150
