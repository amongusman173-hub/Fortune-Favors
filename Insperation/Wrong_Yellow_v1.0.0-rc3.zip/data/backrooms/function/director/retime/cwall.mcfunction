# Natural C-wall pressure timer, seconds.
execute if score @s br_sd_floor matches 1 store result score @s br_sd_cwall run random value 360..1080
execute if score @s br_sd_floor matches 2 store result score @s br_sd_cwall run random value 360..900
execute if score @s br_sd_floor matches 3 store result score @s br_sd_cwall run random value 180..600
execute if score @s br_sd_floor matches 4 store result score @s br_sd_cwall run random value 60..360
execute if score @s br_sd_floor matches ..0 run scoreboard players set @s br_sd_cwall 999999
execute if score @s br_sd_floor matches 5.. run scoreboard players set @s br_sd_cwall 999999
