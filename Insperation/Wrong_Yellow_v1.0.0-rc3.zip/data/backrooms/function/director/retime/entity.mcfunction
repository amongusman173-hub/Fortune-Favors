# Natural subliminal/hostile Entity timer in seconds, slightly shorter below Y161.
execute if score @s br_sd_floor matches 1 store result score @s br_sd_entity run random value 480..1200
execute if score @s br_sd_floor matches 2 store result score @s br_sd_entity run random value 360..765
execute if score @s br_sd_floor matches 3 store result score @s br_sd_entity run random value 225..585
execute if score @s br_sd_floor matches 4 store result score @s br_sd_entity run random value 60..360
execute if score @s br_sd_floor matches ..0 run scoreboard players set @s br_sd_entity 999999
execute if score @s br_sd_floor matches 5.. run scoreboard players set @s br_sd_entity 999999
