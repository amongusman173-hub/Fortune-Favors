# diagnostic: official entry route, identical to the route called by the portal.
function backrooms:enter
