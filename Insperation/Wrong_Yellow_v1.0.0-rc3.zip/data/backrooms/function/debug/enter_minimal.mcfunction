function backrooms:runtime/ensure_ready
execute in backrooms:backrooms run tp @s 8 19 8 180 0
function backrooms:clear_transition_effects
tellraw @s {"text":"[WY debug] Minimal Backrooms entry. Automatic hub/safe-room placement is disabled in RC3.3.24.","color":"yellow"}
