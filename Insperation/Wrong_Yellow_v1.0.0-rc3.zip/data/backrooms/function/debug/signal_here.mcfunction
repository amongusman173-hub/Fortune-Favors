# debug: creates only a signal marker here, to test the particle field.
summon minecraft:marker ~ ~ ~ {Tags:["br_fault_signal"]}
particle minecraft:white_ash ~ ~1.8 ~ 7 2.5 7 0.01 80 normal @s
