# debug: bypass /locate. Creates a natural cave marker exactly here and immediately runs hybrid placement.
# Use in Overworld near/inside the cave you want to test: /function backrooms:debug/spawn_fault_here
summon minecraft:marker ~ ~ ~ {Tags:["br_fault_pending"]}
execute as @e[type=minecraft:marker,tag=br_fault_pending,distance=..1,limit=1,sort=nearest] at @s run function backrooms:fault/generate_from_marker
