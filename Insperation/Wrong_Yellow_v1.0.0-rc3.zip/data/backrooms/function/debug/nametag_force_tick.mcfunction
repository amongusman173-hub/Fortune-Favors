# Force setup + one nametag logic pass, then print status for the command runner.
function backrooms:debug/nametag_setup
function backrooms:hide_nametags_tick
function backrooms:debug/nametag_status
