# Debug: force the full roof-exit request path from inside the Backrooms.
execute as @s at @s if predicate backrooms:in_backrooms run function backrooms:leave_request
