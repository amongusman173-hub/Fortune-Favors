# Manual emergency bootstrap. This is intentionally not part of the normal tick path.
function backrooms:runtime/bootstrap_core
tellraw @s {"text":"[WY debug] Runtime bootstrap executed once. Objectives and storage-backed pools refreshed; runtime_guard_version=51.","color":"green"}
