# lock: manual test for the same route used by the natural wall.
function backrooms:portal/request_advancement_enter
