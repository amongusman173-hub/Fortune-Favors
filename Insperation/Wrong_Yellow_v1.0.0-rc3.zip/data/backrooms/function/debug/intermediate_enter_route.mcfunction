# manual test for the same route used by the natural wall.
# Sets the intermediate state; teleport starts at the very beginning of the next tick.
function backrooms:portal/request_intermediate_enter
