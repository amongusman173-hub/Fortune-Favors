# diagnostic: calls the exact function used by the portal at tick 40.
function backrooms:portal/transfer
