# Ensures Backrooms nametag teams exist and have the correct vanilla options.
team add br_backrooms
team modify br_backrooms nametagVisibility never
team modify br_backrooms collisionRule never
team add br_backrooms_yellow
team modify br_backrooms_yellow nametagVisibility hideForOtherTeams
team modify br_backrooms_yellow collisionRule never
