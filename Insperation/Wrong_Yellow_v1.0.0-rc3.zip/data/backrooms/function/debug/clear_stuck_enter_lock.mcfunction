# Manual cleanup if a player gets stuck in a teleport/reposition loop.
tag @s remove br_in_bug
tag @s remove br_bug_loading
tag @s remove br_bug_tp_cd
tag @s remove br_ready_to_enter
tag @s remove br_scheduled_to_enter
tag @s remove br_adv_enter_requested
tag @s remove br_enter_lock
tag @s remove br_hub_check_pending
advancement revoke @s only backrooms:portal_enter
scoreboard players set @s br_portal 0
scoreboard players set @s br_bug_touch 0
scoreboard players set @s br_enter_source 0
scoreboard players set @s br_tp_called 0
function backrooms:clear_transition_effects
