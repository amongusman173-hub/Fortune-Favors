# Sets the tag and schedules entry like the natural wall after 40 ticks.
tag @s add br_scheduled_to_enter
schedule function backrooms:portal/portal_scheduled_enter 1t append
