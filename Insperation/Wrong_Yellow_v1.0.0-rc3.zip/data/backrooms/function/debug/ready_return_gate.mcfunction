# diagnostic: arms the same tag as the wall. The next global tick should enter through the return gate.
tag @s add br_ready_to_enter
