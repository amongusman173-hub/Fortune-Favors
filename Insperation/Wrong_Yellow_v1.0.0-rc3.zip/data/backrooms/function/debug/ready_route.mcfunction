# diagnostic: simulates the wall at 40 ticks by arming transfer for the next tick start.
tag @s add br_ready_to_enter
