# Roof escape diagnostic shortcut.
function backrooms:roof_escape/admin/status
