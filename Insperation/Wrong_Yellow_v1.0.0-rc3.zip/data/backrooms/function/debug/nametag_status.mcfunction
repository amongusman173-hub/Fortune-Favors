# Diagnose Backrooms nametag logic for the command runner.
team list br_backrooms
team list br_backrooms_yellow
