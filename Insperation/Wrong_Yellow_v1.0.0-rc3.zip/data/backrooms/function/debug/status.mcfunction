# debug: confirms the pack currently loaded and shows basic state.
execute store result score #br_pending_count br_tmp run execute if entity @e[type=minecraft:marker,tag=br_fault_pending]
execute store result score #br_signal_count br_tmp run execute if entity @e[type=minecraft:marker,tag=br_fault_signal]
