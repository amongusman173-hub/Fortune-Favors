# Diagnostic: absolute minimal Overworld return, without tags or cleanup.
# Run from inside the Backrooms. X/Z are converted by coordinate_scale.
execute in minecraft:overworld run tp @s ~ 264 ~
