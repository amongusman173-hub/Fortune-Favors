# Gives the exact yellow leather suit recognized by the Backrooms nametag system.
give @s minecraft:leather_helmet[minecraft:dyed_color=16701501] 1
give @s minecraft:leather_chestplate[minecraft:dyed_color=16701501] 1
give @s minecraft:leather_leggings[minecraft:dyed_color=16701501] 1
give @s minecraft:leather_boots[minecraft:dyed_color=16701501] 1
