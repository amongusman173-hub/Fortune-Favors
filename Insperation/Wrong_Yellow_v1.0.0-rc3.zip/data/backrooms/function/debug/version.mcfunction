tellraw @s [{"text":"Wrong Yellow v1.0.0-rc3 Candidate - final static audit","color":"yellow"},{"text":" | #cw_lock_delay should be 0; dev reset available at backrooms:admin/dev_full_reset","color":"gray"}]
scoreboard players get #cw_lock_delay br_cw_cfg
