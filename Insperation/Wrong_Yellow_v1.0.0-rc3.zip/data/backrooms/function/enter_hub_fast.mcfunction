function backrooms:runtime/ensure_ready
# no automatic hub/safe-room runtime. Enter the normal Backrooms worldgen only.
function backrooms:entry/teleport_safe
scoreboard players set @s br_portal 0
scoreboard players set @s br_bug_touch 0
function backrooms:clear_transition_effects
tag @s add br_bug_tp_cd
schedule function backrooms:portal/clear_tp_cd 40t append
