scoreboard players set #br_perf_ambient br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Ambient dust enabled.","color":"green"}
