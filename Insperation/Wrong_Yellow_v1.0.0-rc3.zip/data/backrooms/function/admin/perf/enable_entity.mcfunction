scoreboard players set #br_perf_entity br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Entity runtime enabled.","color":"green"}
