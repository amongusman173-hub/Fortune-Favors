# enable the full runtime feature set for global idle measurement. Debug overlays and spawn_mobs are not touched.
scoreboard players set #br_perf_ambient br_tmp 1
scoreboard players set #br_perf_blink br_tmp 1
scoreboard players set #br_perf_entity br_tmp 1
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 1
scoreboard players set #br_perf_director br_tmp 1
scoreboard players set #br_perf_fault br_tmp 1
scoreboard players set #br_perf_portal_scan br_tmp 1
scoreboard players set #br_perf_nametag br_tmp 1
scoreboard players set #br_perf_roof_escape br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Full runtime enabled: Ambient/Blink/Entity/C-wall/Giga/Director/Fault/Portal/Nametag/Roof.","color":"green"}
