scoreboard players set #br_perf_c_wall br_tmp 0
# Keep any final tomb blocks, but remove the disposable controller/displays safely.
function backrooms:c_wall/reload_cleanup
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] C-wall runtime disabled; active controller/display entities were cleaned up.","color":"yellow"}
