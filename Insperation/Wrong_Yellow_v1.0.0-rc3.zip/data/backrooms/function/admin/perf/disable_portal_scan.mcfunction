scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_bug_scan br_timer 0
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Portal discovery scan disabled; existing active portal transfer logic is preserved.","color":"yellow"}
