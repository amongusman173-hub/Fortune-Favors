scoreboard players set #br_perf_blink br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Blink Lite enabled.","color":"green"}
