scoreboard players set #br_perf_fault br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Overworld Fault natural runtime enabled.","color":"green"}
