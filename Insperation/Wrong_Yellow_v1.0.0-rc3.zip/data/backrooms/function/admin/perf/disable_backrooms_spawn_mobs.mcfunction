execute in backrooms:backrooms run gamerule spawn_mobs false
tellraw @s {"text":"[Wrong Yellow] Backrooms gamerule spawn_mobs=false applied. This is now accepted as a performance optimisation after RC3.66.11."}
