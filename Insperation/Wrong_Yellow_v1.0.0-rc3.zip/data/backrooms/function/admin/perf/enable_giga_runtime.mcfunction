scoreboard players set #br_perf_giga_runtime br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Giga/matrix runtime enabled.","color":"green"}
