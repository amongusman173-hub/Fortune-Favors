# Runtime-minimal mode for Spark baseline isolation.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 0
scoreboard players set #br_perf_c_wall br_tmp 0
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
scoreboard players set #br_bug_scan br_timer 0
scoreboard players set #event_lock br_event_lock 0
scoreboard players set #event_kind br_event_lock 0
scoreboard players set #event_timer br_event_lock 0
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
function backrooms:entity/reload_cleanup
function backrooms:c_wall/reload_cleanup
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Runtime minimal baseline mode enabled: all perf-controlled systems are off.","color":"yellow"}
