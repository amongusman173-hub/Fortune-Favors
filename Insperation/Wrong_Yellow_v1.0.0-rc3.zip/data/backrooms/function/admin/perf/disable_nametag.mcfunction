scoreboard players set #br_perf_nametag br_tmp 0
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Nametag reconciliation disabled for perf isolation.","color":"yellow"}
