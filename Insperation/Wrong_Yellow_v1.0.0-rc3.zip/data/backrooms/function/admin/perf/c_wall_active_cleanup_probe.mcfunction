# C-wall active fixture cleanup probe.
# Keeps the same isolated C-wall-only perf flags, but removes loaded C-wall controller/displays and player tags.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 0
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
function backrooms:c_wall/cleanup_silent
function backrooms:admin/perf/recalculate_runtime_gate
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.32 C-wall fixture cleanup probe applied; controller/displays removed, C-wall flag remains enabled.","color":"yellow"}
execute if entity @s run function backrooms:c_wall/debug/status
