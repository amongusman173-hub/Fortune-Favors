scoreboard players set #br_perf_roof_escape br_tmp 0
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Roof escape tick disabled for perf isolation. Do not use for normal gameplay tests.","color":"yellow"}
