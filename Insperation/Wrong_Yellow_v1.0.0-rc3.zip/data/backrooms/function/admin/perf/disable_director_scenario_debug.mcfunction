function backrooms:director/admin/debug_off
