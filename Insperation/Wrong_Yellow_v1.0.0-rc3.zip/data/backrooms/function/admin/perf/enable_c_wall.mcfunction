scoreboard players set #br_perf_c_wall br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] C-wall runtime enabled.","color":"green"}
