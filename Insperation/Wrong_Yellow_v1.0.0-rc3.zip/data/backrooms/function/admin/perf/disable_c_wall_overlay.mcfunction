scoreboard players set #cw_overlay br_cw_cfg 0
execute in backrooms:backrooms run function backrooms:c_wall/overlay/clear
tellraw @s {"text":"[Wrong Yellow] C-wall overlay OFF.","color":"yellow"}
function backrooms:c_wall/debug/status
