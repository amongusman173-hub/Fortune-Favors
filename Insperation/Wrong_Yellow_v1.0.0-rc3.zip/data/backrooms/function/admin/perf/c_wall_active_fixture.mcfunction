# C-wall active fixture preset.
# Run as a player in the Backrooms, preferably Survival/Adventure, standing on open brown_carpet and looking across a large carpet area.
# This is manual-only: it does not reactivate Ambient/Blink/Entity/Giga/Fault/Director.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 0
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
# Keep the natural cycle parked while the manual fixture is profiled.
scoreboard players set #cw_cycle_cd br_cw_cd 48000
scoreboard players set #cw_tick br_cw_tmp 0
function backrooms:admin/perf/recalculate_runtime_gate
# The debug spawn helper validates player source, dimension, gamemode and 5x5 brown_carpet footprint, then cleans any previous C-wall.
function backrooms:c_wall/debug/spawn_12_forward
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.32 renderer-diet fixture preset applied: C-wall=1 only; manual wall attempted 12 blocks forward.","color":"green"}
execute if entity @s run function backrooms:c_wall/debug/status
