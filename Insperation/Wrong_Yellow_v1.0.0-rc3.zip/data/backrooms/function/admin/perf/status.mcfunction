tellraw @s {"text":"[Wrong Yellow Perf] build_id=v1.0.0-rc3 Candidate","color":"aqua"}
execute unless score #br_perf_ambient br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_ambient br_tmp 1
execute unless score #br_perf_blink br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_blink br_tmp 1
execute unless score #br_perf_entity br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_entity br_tmp 1
execute unless score #br_perf_c_wall br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_c_wall br_tmp 1
execute unless score #br_perf_giga_runtime br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_giga_runtime br_tmp 1
execute unless score #br_perf_fault br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_fault br_tmp 1
execute unless score #br_perf_portal_scan br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_portal_scan br_tmp 1
execute unless score #br_perf_director br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_director br_tmp 1
execute unless score #br_perf_nametag br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_nametag br_tmp 1
execute unless score #br_perf_roof_escape br_tmp matches -2147483648..2147483647 run scoreboard players set #br_perf_roof_escape br_tmp 1
execute unless score #br_entity_hitbox_debug br_tmp matches -2147483648..2147483647 run scoreboard players set #br_entity_hitbox_debug br_tmp 0
execute unless score #br_food_brown_mushroom br_tmp matches -2147483648..2147483647 run scoreboard players set #br_food_brown_mushroom br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
scoreboard players set #br_perf_status_matrix br_tmp 0
scoreboard players set #br_perf_status_building br_tmp 0
scoreboard players set #br_perf_status_entity br_tmp 0
scoreboard players set #br_perf_status_cwall br_tmp 0
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=wy_matrix_cell,scores={br_giga_matrix_v=9}] run scoreboard players add #br_perf_status_matrix br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=wy_matrix_building,scores={br_giga_matrix_v=9}] run scoreboard players add #br_perf_status_building br_tmp 1
execute in backrooms:backrooms as @e[tag=br_entity] run scoreboard players add #br_perf_status_entity br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_cw_controller] run scoreboard players add #br_perf_status_cwall br_tmp 1
scoreboard players set #br_perf_status_markers br_tmp 0
scoreboard players set #br_perf_status_giga_markers br_tmp 0
scoreboard players set #br_perf_status_cw_visual br_tmp 0
scoreboard players set #br_perf_status_visual_pool br_tmp 0
execute in backrooms:backrooms as @e[type=minecraft:marker] run scoreboard players add #br_perf_status_markers br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=wy_matrix_cell] run scoreboard players add #br_perf_status_giga_markers br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=wy_matrix_building] run scoreboard players add #br_perf_status_giga_markers br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=wy_matrix_pending] run scoreboard players add #br_perf_status_giga_markers br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:block_display,tag=br_cw_visual] run scoreboard players add #br_perf_status_cw_visual br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pool] run scoreboard players add #br_perf_status_visual_pool br_tmp 1
tellraw @s [{"text":"[Wrong Yellow Perf] core flags  ambient="},{"score":{"name":"#br_perf_ambient","objective":"br_tmp"}},{"text":" blink="},{"score":{"name":"#br_perf_blink","objective":"br_tmp"}},{"text":" entity="},{"score":{"name":"#br_perf_entity","objective":"br_tmp"}},{"text":" c_wall="},{"score":{"name":"#br_perf_c_wall","objective":"br_tmp"}},{"text":" giga="},{"score":{"name":"#br_perf_giga_runtime","objective":"br_tmp"}},{"text":" director="},{"score":{"name":"#br_perf_director","objective":"br_tmp"}}]
tellraw @s [{"text":"[Wrong Yellow Perf] isolation flags  fault="},{"score":{"name":"#br_perf_fault","objective":"br_tmp"}},{"text":" portal_scan="},{"score":{"name":"#br_perf_portal_scan","objective":"br_tmp"}},{"text":" nametag="},{"score":{"name":"#br_perf_nametag","objective":"br_tmp"}},{"text":" roof_escape="},{"score":{"name":"#br_perf_roof_escape","objective":"br_tmp"}}]
tellraw @s [{"text":"[Wrong Yellow Perf] loaded matrix cells="},{"score":{"name":"#br_perf_status_matrix","objective":"br_tmp"}},{"text":" building="},{"score":{"name":"#br_perf_status_building","objective":"br_tmp"}},{"text":" entities="},{"score":{"name":"#br_perf_status_entity","objective":"br_tmp"}},{"text":" c-wall controllers="},{"score":{"name":"#br_perf_status_cwall","objective":"br_tmp"}}]
tellraw @s [{"text":"[Wrong Yellow Perf] marker debug total/giga/cwallDisplays/visualPool="},{"score":{"name":"#br_perf_status_markers","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_perf_status_giga_markers","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_perf_status_cw_visual","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_perf_status_visual_pool","objective":"br_tmp"}}]
tellraw @s [{"text":"[Wrong Yellow Perf] runtime_gate="},{"score":{"name":"#br_perf_any_runtime","objective":"br_tmp"}},{"text":" 0=true minimal tick, 1=full runtime path"}]
tellraw @s {"text":"[Wrong Yellow Perf] Backrooms spawn_mobs intended=false; verify with /function backrooms:admin/perf/check_backrooms_spawn_mobs"}
tellraw @s [{"text":"[Wrong Yellow Perf] entity_hitbox_debug="},{"score":{"name":"#br_entity_hitbox_debug","objective":"br_tmp"}},{"text":" debug only"}]
tellraw @s [{"text":"[Wrong Yellow Perf] c_wall_overlay="},{"score":{"name":"#cw_overlay","objective":"br_cw_cfg"}},{"text":" debug only; /function backrooms:admin/perf/enable_c_wall_overlay or disable_c_wall_overlay"}]
tellraw @s [{"text":"[Wrong Yellow Food] backroom_brown_mushroom="},{"score":{"name":"#br_food_brown_mushroom","objective":"br_tmp"}},{"text":" no-tick brown_mushroom_block loot toggle; /function backrooms:food/status_brown_mushroom"}]
function backrooms:director/admin/status
