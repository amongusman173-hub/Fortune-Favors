scoreboard players set #br_perf_roof_escape br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Roof escape tick enabled.","color":"green"}
