# Ambient + Blink + Entity + C-wall combined horror systems preset.
# Manual-only deterministic probe before Director. Keeps Giga/Fault/Portal/Director/Nametag/Roof Escape off.
# This does not spawn fixtures by itself; use the explicit debug spawn commands after applying the preset.

# Remove stale disposable actors/anchors first. blink_lite/restore_and_kill temporarily disables Blink, so flags are set after cleanup.
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
function backrooms:entity/reload_cleanup
function backrooms:c_wall/cleanup_silent

scoreboard players set #br_perf_ambient br_tmp 1
scoreboard players set #br_perf_blink br_tmp 1
scoreboard players set #br_perf_entity br_tmp 1
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
scoreboard players set #br_entity_hitbox_debug br_tmp 0

# Deterministic engineering probe: park natural C-wall pressure so manual fixtures define the test.
# Director will later own natural carousel scheduling.
scoreboard players set #cw_cycle_cd br_cw_cd 48000
scoreboard players set #cw_tick br_cw_tmp 0

function backrooms:admin/perf/recalculate_runtime_gate
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.38 combined horror preset applied: Ambient=1, Blink=1, Entity=1, C-wall=1; Giga/Fault/Portal/Director/Nametag/Roof Escape=0.","color":"green"}
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] For deterministic stress: force one Blink anchor, spawn one C-wall, then force one Entity. Director remains OFF; overlaps are engineering validation only.","color":"yellow"}
execute if entity @s run function backrooms:admin/perf/status
