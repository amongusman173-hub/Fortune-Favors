# C-wall + Entity compatibility preset.
# Manual-only: isolate the two accepted active horror systems before recombining Ambient/Blink.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 1
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
scoreboard players set #br_entity_hitbox_debug br_tmp 0
# Start from a known clean runtime state. The systems are disposable; fixtures can be respawned manually.
function backrooms:entity/reload_cleanup
function backrooms:c_wall/cleanup_silent
# Park C-wall natural cycle so the test uses only explicitly spawned walls.
scoreboard players set #cw_cycle_cd br_cw_cd 48000
scoreboard players set #cw_tick br_cw_tmp 0
function backrooms:admin/perf/recalculate_runtime_gate
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.34 compatibility preset applied: Entity=1, C-wall=1; Ambient/Blink/Giga/Fault/Portal/Director/Nametag/Roof Escape=0.","color":"green"}
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] Spawn fixtures manually: C-wall with /function backrooms:c_wall/debug/spawn_12_forward, Entity with /function backrooms:entity/debug/force_visible_chase_front.","color":"yellow"}
execute if entity @s run function backrooms:admin/perf/status
