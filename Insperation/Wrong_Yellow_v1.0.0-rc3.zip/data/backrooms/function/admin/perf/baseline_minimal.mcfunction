function backrooms:admin/perf/disable_all
