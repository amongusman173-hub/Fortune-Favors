function backrooms:director/admin/debug_on
