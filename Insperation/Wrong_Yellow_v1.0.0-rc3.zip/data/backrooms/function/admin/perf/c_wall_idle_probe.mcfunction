# C-wall idle probe preset.
# Use after /reload or on a reused world to force the same isolated state as the fresh-backup default.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 0
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
# Guarantee an idle-only 30 s profile: no natural C-wall can wake during the probe.
scoreboard players set #cw_cycle_cd br_cw_cd 48000
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
function backrooms:entity/reload_cleanup
function backrooms:c_wall/reload_cleanup
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] RC3.66.30 C-wall idle probe preset applied: C-wall=1, accepted light systems and heavy systems=0.","color":"green"}
