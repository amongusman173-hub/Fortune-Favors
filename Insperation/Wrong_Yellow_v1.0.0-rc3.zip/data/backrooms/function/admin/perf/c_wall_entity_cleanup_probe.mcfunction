# C-wall + Entity cleanup/leak probe.
# Keeps compatibility flags enabled but removes active disposable objects.
scoreboard players set #br_perf_ambient br_tmp 0
scoreboard players set #br_perf_blink br_tmp 0
scoreboard players set #br_perf_entity br_tmp 1
scoreboard players set #br_perf_c_wall br_tmp 1
scoreboard players set #br_perf_giga_runtime br_tmp 0
scoreboard players set #br_perf_fault br_tmp 0
scoreboard players set #br_perf_portal_scan br_tmp 0
scoreboard players set #br_perf_director br_tmp 0
scoreboard players set #br_perf_nametag br_tmp 0
scoreboard players set #br_perf_roof_escape br_tmp 0
scoreboard players set #br_entity_hitbox_debug br_tmp 0
function backrooms:entity/reload_cleanup
function backrooms:c_wall/cleanup_silent
function backrooms:admin/perf/recalculate_runtime_gate
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.34 compatibility cleanup applied; C-wall + Entity flags remain enabled.","color":"yellow"}
execute if entity @s run function backrooms:admin/perf/status
execute if entity @s run function backrooms:c_wall/debug/status
execute if entity @s run function backrooms:entity/debug/status
