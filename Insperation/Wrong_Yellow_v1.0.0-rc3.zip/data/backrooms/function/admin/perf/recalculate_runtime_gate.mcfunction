# rebuild the ultra-cheap tick gate from current perf flags.
# 0 = true minimal no-op tick path. 1 = run backrooms:tick_runtime each tick.
scoreboard players set #br_perf_any_runtime br_tmp 0
execute unless score #br_perf_ambient br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_blink br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_entity br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_c_wall br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_giga_runtime br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_fault br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_portal_scan br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_director br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_nametag br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
execute unless score #br_perf_roof_escape br_tmp matches 0 run scoreboard players set #br_perf_any_runtime br_tmp 1
