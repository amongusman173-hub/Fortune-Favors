scoreboard players set #br_perf_portal_scan br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Portal discovery scan enabled.","color":"green"}
