# combined horror cleanup/leak probe.
# Restores Blink anchors and removes disposable Entity/C-wall actors. Leaves final tomb blocks untouched.
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
function backrooms:entity/reload_cleanup
function backrooms:c_wall/cleanup_silent
function backrooms:blink_lite/reconcile_active
function backrooms:entity/reconcile_active
function backrooms:c_wall/reconcile_active
execute if entity @s run tellraw @s {"text":"[Wrong Yellow] RC3.66.38 combined horror cleanup done. Note: Blink flag may be 0 after anchor restore; rerun combined_horror_systems_probe to restart the full preset.","color":"yellow"}
execute if entity @s run function backrooms:admin/perf/status
