tellraw @s {"text":"[Wrong Yellow] Querying backrooms:backrooms gamerule spawn_mobs..."}
execute in backrooms:backrooms run gamerule spawn_mobs
