scoreboard players set #cw_overlay br_cw_cfg 1
execute in backrooms:backrooms run function backrooms:c_wall/overlay/apply
tellraw @s {"text":"[Wrong Yellow] C-wall overlay ON. Existing and newly spawned C-walls will glow gold for debug.","color":"gold"}
function backrooms:c_wall/debug/status
