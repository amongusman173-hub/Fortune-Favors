scoreboard players set #br_perf_entity br_tmp 0
scoreboard players set #br_entity_hitbox_debug br_tmp 0
# Manifestations are disposable. Cleanly canceling them avoids leaving a frozen hunt.
function backrooms:entity/reload_cleanup
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Entity runtime disabled; active manifestations were cleaned up.","color":"yellow"}
