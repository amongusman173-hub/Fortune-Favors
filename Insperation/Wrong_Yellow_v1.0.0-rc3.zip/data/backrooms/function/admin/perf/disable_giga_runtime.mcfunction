# Suspend the scheduler only. Existing macrocell markers, structures and queued
# state remain untouched and resume when re-enabled.
scoreboard players set #br_perf_giga_runtime br_tmp 0
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Giga/matrix runtime suspended; structures and markers were preserved.","color":"yellow"}
