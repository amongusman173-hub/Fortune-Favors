execute in backrooms:backrooms run gamerule spawn_mobs true
tellraw @s {"text":"[Wrong Yellow] Backrooms gamerule spawn_mobs=true restored. Warning: this may re-enable NaturalSpawner cost in Backrooms."}
