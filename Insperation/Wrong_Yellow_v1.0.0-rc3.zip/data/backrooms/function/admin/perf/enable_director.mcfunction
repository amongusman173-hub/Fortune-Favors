scoreboard players set #br_perf_director br_tmp 1
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Director runtime enabled.","color":"green"}
