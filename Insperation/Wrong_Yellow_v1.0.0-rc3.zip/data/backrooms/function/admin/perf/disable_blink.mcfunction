scoreboard players set #br_perf_blink br_tmp 0
# Restore any active anchors before suspending the system; no light remains stuck off.
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
function backrooms:admin/perf/recalculate_runtime_gate
tellraw @s {"text":"[Wrong Yellow] Blink Lite disabled; active anchors were restored.","color":"yellow"}
