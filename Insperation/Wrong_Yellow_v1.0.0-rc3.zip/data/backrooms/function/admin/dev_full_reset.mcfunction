# admin/dev cleanup.
# Purpose: reset volatile test/runtime state without deleting generated chunks.
# Safe scope: loaded C-wall/entity/blink/portal technical entities, player tags, volatile fake-player scores.
# It deliberately does NOT delete Backrooms dimension chunks or deterministic giga/matrix cell markers.

tellraw @a {"text":"[WY admin] dev_full_reset started. Cleaning loaded volatile runtime state...","color":"gold"}

# Ensure current objectives/config exist before resetting values.
function backrooms:runtime/bootstrap_core

# Disposable gameplay manifests and technical visuals.
execute in backrooms:backrooms if entity @e[tag=br_cw,limit=1] run kill @e[tag=br_cw]
execute in backrooms:backrooms if entity @e[tag=br_entity,limit=1] run kill @e[tag=br_entity]
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual] at @s run function backrooms:entity/vanish_visual_entity
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pool] at @s run tp @s ~ -500 ~
execute in backrooms:backrooms as @e[tag=br_blink_lite_active] at @s run function backrooms:blink_lite/restore_and_kill
execute in backrooms:backrooms as @e[tag=br_blink_lite_off] at @s run function backrooms:blink_lite/restore_and_kill
execute in backrooms:backrooms if entity @e[tag=br_blink,limit=1] run kill @e[tag=br_blink]

# Overworld bug-portal transient entities / old test visuals.
execute in minecraft:overworld if entity @e[tag=br_bug_core,limit=1] run kill @e[tag=br_bug_core]
execute in minecraft:overworld if entity @e[tag=br_bug_visual,limit=1] run kill @e[tag=br_bug_visual]
execute in minecraft:overworld if entity @e[tag=br_bug_hit,limit=1] run kill @e[tag=br_bug_hit]
execute in minecraft:overworld if entity @e[tag=br_bug_anchor,limit=1] run kill @e[tag=br_bug_anchor]
execute in minecraft:overworld if entity @e[tag=br_exit_loader,limit=1] run kill @e[tag=br_exit_loader]

# Same cleanup in Backrooms in case a debug helper or old test branch left portal entities there.
execute in backrooms:backrooms if entity @e[tag=br_bug_core,limit=1] run kill @e[tag=br_bug_core]
execute in backrooms:backrooms if entity @e[tag=br_bug_visual,limit=1] run kill @e[tag=br_bug_visual]
execute in backrooms:backrooms if entity @e[tag=br_bug_hit,limit=1] run kill @e[tag=br_bug_hit]
execute in backrooms:backrooms if entity @e[tag=br_bug_anchor,limit=1] run kill @e[tag=br_bug_anchor]

# Player tags: execute only on players that actually have the tag to avoid noisy red feedback.
execute as @a[tag=br_blink_lite_ready] run tag @s remove br_blink_lite_ready
execute as @a[tag=br_blink_lite_eligible] run tag @s remove br_blink_lite_eligible
execute as @a[tag=br_blink_lite_opportunity] run tag @s remove br_blink_lite_opportunity
execute as @a[tag=br_cw_cd_ready] run tag @s remove br_cw_cd_ready
execute as @a[tag=br_cw_candidate] run tag @s remove br_cw_candidate
execute as @a[tag=br_cw_target] run tag @s remove br_cw_target
execute as @a[tag=br_cw_chase] run tag @s remove br_cw_chase
execute as @a[tag=br_cw_entombed] run tag @s remove br_cw_entombed
execute as @a[tag=br_hunted] run tag @s remove br_hunted
execute as @a[tag=br_natural_hunt] run tag @s remove br_natural_hunt
execute as @a[tag=br_debug_fast] run tag @s remove br_debug_fast
execute as @a[tag=br_fake_dying] run tag @s remove br_fake_dying
execute as @a[tag=br_in_bug] run tag @s remove br_in_bug
execute as @a[tag=br_entity_attack] run tag @s remove br_entity_attack
execute as @a[tag=br_entity_warning] run tag @s remove br_entity_warning
execute as @a[tag=br_entity_subliminal] run tag @s remove br_entity_subliminal
execute as @a[tag=br_entity_vanish_pending] run tag @s remove br_entity_vanish_pending
execute as @a[tag=backrooms_leaving] run tag @s remove backrooms_leaving
execute as @a[tag=br_adv_enter_requested] run tag @s remove br_adv_enter_requested
execute as @a[tag=br_ready_to_enter] run tag @s remove br_ready_to_enter
execute as @a[tag=br_scheduled_to_enter] run tag @s remove br_scheduled_to_enter
execute as @a[tag=br_enter_lock] run tag @s remove br_enter_lock
execute as @a[tag=br_exit_pending] run tag @s remove br_exit_pending
execute as @a[tag=br_fault_pending] run tag @s remove br_fault_pending
execute as @a[tag=br_fault_signal] run tag @s remove br_fault_signal

# Reset volatile player scores. These are runtime state, not permanent worldgen identity.
scoreboard players reset @a br_timer
scoreboard players reset @a br_seen
scoreboard players reset @a br_sight_count
scoreboard players reset @a br_attack_after
scoreboard players reset @a br_rand
scoreboard players reset @a br_phase
scoreboard players reset @a br_bug_timer
scoreboard players reset @a br_bug_rand
scoreboard players reset @a br_portal
scoreboard players reset @a br_bug_touch
scoreboard players reset @a br_sound_cut
tag @a remove br_sound_anvil_cut
stopsound @a master minecraft:block.anvil.use
stopsound @a master minecraft:item.elytra.flying
scoreboard players reset @a br_entity_cd
scoreboard players reset @a br_life
scoreboard players reset @a br_ai_step
scoreboard players reset @a br_ai_stuck
scoreboard players reset @a br_tmp
scoreboard players reset @a br_scan_cd
scoreboard players reset @a br_bug_tp_cd
scoreboard players reset @a br_bug_blink
scoreboard players reset @a br_enter_source
scoreboard players reset @a br_tp_called
scoreboard players reset @a br_exit_timer
scoreboard players reset @a br_entity_deaths_seen
scoreboard players reset @a br_entity_hit_cd
scoreboard players reset @a br_cw_cd
scoreboard players reset @a br_cw_state
scoreboard players reset @a br_cw_timer
scoreboard players reset @a br_cw_tmp
scoreboard players reset @a br_cw_rand
scoreboard players reset @a br_cw_ybad
scoreboard players reset @a br_cw_x
scoreboard players reset @a br_cw_z
scoreboard players reset @a br_cw_tomb_timer
scoreboard players reset @a br_cw_tomb_hit
scoreboard players reset @a br_cw_light
scoreboard players reset @a br_cw_axis
scoreboard players reset @a br_cw_facing
scoreboard players reset @a br_cw_axis_remaining
scoreboard players reset @a br_cw_snap_restore
scoreboard players reset @a br_blink_timer
scoreboard players reset @a br_blink_lite
scoreboard players reset @a br_blink_x
scoreboard players reset @a br_blink_z
scoreboard players reset @a br_blink_last_x
scoreboard players reset @a br_blink_last_z

# Reset C-wall runtime/config and diagnostics. This is the fix for stale #cw_lock_delay=200 test worlds.
scoreboard players set #cw_lock_delay br_cw_cfg 0
scoreboard players set #cw_tick br_cw_tmp 0
scoreboard players set #cw_controller_present br_cw_tmp 0
scoreboard players set #cw_reconcile_tick br_cw_tmp 0
scoreboard players set #cw_controllers br_cw_tmp 0
scoreboard players set #cw_attempts br_cw_diag 0
scoreboard players set #cw_spawns br_cw_diag 0
scoreboard players set #cw_debug_spawns br_cw_diag 0
scoreboard players set #cw_failed br_cw_diag 0
scoreboard players set #cw_finished br_cw_diag 0
scoreboard players set #cw_cancelled br_cw_diag 0
scoreboard players set #cw_entombs br_cw_diag 0
scoreboard players set #cw_cleanup_runs br_cw_diag 0
scoreboard players set #cw_tomb_damage br_cw_diag 0
scoreboard players set #cw_resets br_cw_diag 0
scoreboard players set #cw_locks br_cw_diag 0
scoreboard players set #cw_cycle_ends br_cw_diag 0
scoreboard players set #cw_idle_reseeds br_cw_diag 0
execute store result score #cw_cycle_cd br_cw_cd run random value 18000..48000

# Reset Blink Lite global counters/cooldown without deleting player-built lights.
scoreboard players set #blink_cd br_blink_lite 0
scoreboard players set #blink_active br_blink_lite 0
scoreboard players set #blink_eligible br_blink_lite 0
scoreboard players set #blink_ready br_blink_lite 0
scoreboard players set #blink_opportunities br_blink_lite 0
scoreboard players set #blink_found br_blink_lite 0
scoreboard players set #blink_roll br_blink_lite 0
scoreboard players set #blink_offset br_blink_lite 0
scoreboard players set #blink_mode br_blink_lite 0
scoreboard players set #blink_low br_blink_lite 0
scoreboard players set #blink_medium br_blink_lite 0
scoreboard players set #blink_high br_blink_lite 0
scoreboard players set #blink_anchor_present br_blink_lite 0
scoreboard players set #blink_reconcile_tick br_blink_lite 0

# Reset Backrooms hostile pressure. Current players resume from a fresh random delay.
execute as @a store result score @s br_entity_cd run random value 9000..24000
scoreboard players set #entity_active br_entity_cd 0
scoreboard players set #entity_warning br_entity_cd 0
scoreboard players set #br_entity_present br_tmp 0
scoreboard players set #br_attack_present br_tmp 0
scoreboard players set #br_vanish_present br_tmp 0
scoreboard players set #br_entity_count br_tmp 0
scoreboard players set #br_attack_count br_tmp 0
scoreboard players set #br_entity_idle_tick br_tmp 0
scoreboard players set #br_entity_reconcile_tick br_tmp 0

# Clear only runtime bootstrap flags that are safe to rebuild.
data remove storage backrooms:state runtime_bootstrapped
data remove storage backrooms:state runtime_guard_version

# Re-apply current branch runtime/config after cleanup.
function backrooms:runtime/bootstrap_core
function backrooms:c_wall/config_load
scoreboard players set #cw_lock_delay br_cw_cfg 0

# Final verification message.
tellraw @a [{"text":"[WY admin] dev_full_reset done. ","color":"green"},{"text":"C-wall lock delay forced to ","color":"gray"},{"score":{"name":"#cw_lock_delay","objective":"br_cw_cfg"}},{"text":" tick(s). Generated chunks were not deleted.","color":"gray"}]
