# this helper is intentionally disabled in release/test progression.
# produced a keepalive timeout when run in a narrow corridor.
# A later wide-room Spark profile (IJxXyhAXY4) showed acceptable server cost, so the helper is reclassified as geometry-sensitive, not a normal Blink Lite failure.
# Use one-anchor helper only for controlled profiling unless a future safe footprint validator is added.
tellraw @s {"text":"[Wrong Yellow] debug_force_three_anchors_here is disabled for RC3.66.x progression. Wide-room stress was acceptable, but narrow corridors caused a keepalive timeout. Use one-anchor helper only.","color":"yellow"}
