# Set the next natural Blink Lite cooldown after a successful anchor creation.
# cooldown is no longer consumed by failed distant scans.
execute store result score #blink_roll br_blink_lite run random value 0..9

# 1 eligible explorer: short bursts / normal / rare long gap.
execute if score #blink_eligible br_blink_lite matches 1 if score #blink_roll br_blink_lite matches 0..2 store result score #blink_cd br_blink_lite run random value 20..70
execute if score #blink_eligible br_blink_lite matches 1 if score #blink_roll br_blink_lite matches 3..8 store result score #blink_cd br_blink_lite run random value 60..140
execute if score #blink_eligible br_blink_lite matches 1 if score #blink_roll br_blink_lite matches 9 store result score #blink_cd br_blink_lite run random value 180..360

# 2 eligible explorers: faster average, same long-tail logic.
execute if score #blink_eligible br_blink_lite matches 2 if score #blink_roll br_blink_lite matches 0..3 store result score #blink_cd br_blink_lite run random value 15..55
execute if score #blink_eligible br_blink_lite matches 2 if score #blink_roll br_blink_lite matches 4..8 store result score #blink_cd br_blink_lite run random value 45..115
execute if score #blink_eligible br_blink_lite matches 2 if score #blink_roll br_blink_lite matches 9 store result score #blink_cd br_blink_lite run random value 130..280

# 3+ eligible explorers: frequent but still capped to 3 active anchors.
execute if score #blink_eligible br_blink_lite matches 3.. if score #blink_roll br_blink_lite matches 0..3 store result score #blink_cd br_blink_lite run random value 10..45
execute if score #blink_eligible br_blink_lite matches 3.. if score #blink_roll br_blink_lite matches 4..8 store result score #blink_cd br_blink_lite run random value 35..90
execute if score #blink_eligible br_blink_lite matches 3.. if score #blink_roll br_blink_lite matches 9 store result score #blink_cd br_blink_lite run random value 100..230
