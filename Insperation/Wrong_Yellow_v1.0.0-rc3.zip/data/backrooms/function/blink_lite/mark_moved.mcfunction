# Movement gate: standing still never creates repeated blink attempts.
tag @s add br_blink_lite_opportunity
scoreboard players operation @s br_blink_last_x = @s br_blink_x
scoreboard players operation @s br_blink_last_z = @s br_blink_z
