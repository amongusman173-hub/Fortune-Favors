# Duration of the defective-light frame.
execute if entity @s[tag=br_blink_mode_low] run scoreboard players set @s br_blink_timer 2
execute if entity @s[tag=br_blink_mode_medium] run scoreboard players set @s br_blink_timer 2
execute if entity @s[tag=br_blink_mode_high] store result score @s br_blink_timer run random value 2..10
execute unless entity @s[tag=br_blink_mode_low] unless entity @s[tag=br_blink_mode_medium] unless entity @s[tag=br_blink_mode_high] run scoreboard players set @s br_blink_timer 2
