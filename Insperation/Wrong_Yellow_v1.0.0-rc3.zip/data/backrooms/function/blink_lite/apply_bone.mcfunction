# Convert a bone_block into a persistent animated defective-light anchor.
# anchor gets a random low/medium/high animation profile.
function backrooms:sound/blink_anvil_1t
setblock ~ ~ ~ minecraft:ochre_froglight replace
summon minecraft:marker ~ ~ ~ {Tags:["br_blink_lite_active","br_blink_lite_restore_bone","br_blink_lite_off"]}
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=br_blink_lite_restore_bone,distance=..0.5,limit=1,sort=nearest] run function backrooms:blink_lite/mode_pick
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=br_blink_lite_restore_bone,distance=..0.5,limit=1,sort=nearest] run function backrooms:blink_lite/set_off_duration
scoreboard players add #blink_active br_blink_lite 1
scoreboard players set #blink_anchor_present br_blink_lite 1
