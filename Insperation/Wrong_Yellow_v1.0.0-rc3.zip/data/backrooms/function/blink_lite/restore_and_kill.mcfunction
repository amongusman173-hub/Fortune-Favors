# Restore the normal block when no player is close enough, then remove the animated anchor.
execute if entity @s[tag=br_blink_lite_restore_ochre] if block ~ ~ ~ minecraft:bone_block run setblock ~ ~ ~ minecraft:ochre_froglight replace
execute if entity @s[tag=br_blink_lite_restore_bone] if block ~ ~ ~ minecraft:ochre_froglight run setblock ~ ~ ~ minecraft:bone_block replace
tag @s remove br_blink_ttl_init
tag @s remove br_blink_lite_active
kill @s
