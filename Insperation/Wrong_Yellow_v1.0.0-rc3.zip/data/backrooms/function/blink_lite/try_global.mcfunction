# One natural blink event attempt.
# try the eligible player first. Failed distant scans keep the
# opportunity and use only a short retry delay instead of consuming a full cooldown.
scoreboard players set #blink_found br_blink_lite 0
execute as @a[tag=br_blink_lite_eligible,sort=random,limit=1] at @s run function backrooms:blink_lite/try_player
execute if score #blink_found br_blink_lite matches 1 run function backrooms:blink_lite/set_natural_cooldown
execute if score #blink_found br_blink_lite matches 0 run scoreboard players set #blink_cd br_blink_lite 20
