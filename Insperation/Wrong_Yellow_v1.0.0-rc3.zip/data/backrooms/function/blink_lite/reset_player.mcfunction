# Player left the Backrooms or became ineligible.
tag @s remove br_blink_lite_ready
tag @s remove br_blink_lite_opportunity
tag @s remove br_blink_lite_eligible
