# Defective dark frame: ochre_froglight -> bone_block.
execute if block ~ ~ ~ minecraft:ochre_froglight run setblock ~ ~ ~ minecraft:bone_block replace
tag @s add br_blink_lite_off
function backrooms:blink_lite/set_off_duration
