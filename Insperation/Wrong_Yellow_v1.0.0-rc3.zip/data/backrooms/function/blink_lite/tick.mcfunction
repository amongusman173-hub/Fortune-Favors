# Blink Lite Animated Anchor global tick.
# do not scan all markers every tick while no defective-light anchor is known.
execute unless score #blink_anchor_present br_blink_lite matches -2147483648..2147483647 run function backrooms:blink_lite/reconcile_active
scoreboard players add #blink_reconcile_tick br_blink_lite 1
execute if score #blink_reconcile_tick br_blink_lite matches 20.. run scoreboard players set #blink_reconcile_tick br_blink_lite 0
execute if score #blink_reconcile_tick br_blink_lite matches 0 run function backrooms:blink_lite/reconcile_active
execute if score #blink_anchor_present br_blink_lite matches 1.. as @e[type=minecraft:marker,tag=br_blink_lite_active] at @s run function backrooms:blink_lite/active_tick

# Active anchors keep their original per-tick animation. Player tracking and
# opportunity selection are cadence-limited in player_tick.mcfunction.
scoreboard players add #blink_runtime_tick br_blink_lite 1
execute if score #blink_runtime_tick br_blink_lite matches 10.. run scoreboard players set #blink_runtime_tick br_blink_lite 0
execute if score #blink_runtime_tick br_blink_lite matches 0 run function backrooms:blink_lite/player_tick
