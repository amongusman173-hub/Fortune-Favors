# 10-tick player-side Blink Lite cadence. Active anchors still animate every tick.
# The cooldown is decremented by ten below, preserving its existing real-time ranges.

tag @a remove br_blink_lite_eligible
scoreboard players set #blink_ready br_blink_lite 0
scoreboard players set #blink_eligible br_blink_lite 0
scoreboard players set #blink_opportunities br_blink_lite 0

execute as @a[tag=br_blink_lite_ready] at @s unless predicate backrooms:in_backrooms run function backrooms:blink_lite/reset_player

execute as @a[gamemode=survival,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms unless entity @s[tag=br_blink_lite_ready] run function backrooms:blink_lite/init_player
execute as @a[gamemode=adventure,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms unless entity @s[tag=br_blink_lite_ready] run function backrooms:blink_lite/init_player
execute as @a[gamemode=survival,tag=br_blink_lite_ready,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run function backrooms:blink_lite/update_player
execute as @a[gamemode=adventure,tag=br_blink_lite_ready,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run function backrooms:blink_lite/update_player
execute as @a[tag=br_blink_lite_ready] run scoreboard players add #blink_ready br_blink_lite 1

execute as @a[tag=br_blink_lite_opportunity] run scoreboard players add #blink_opportunities br_blink_lite 1
execute as @a[gamemode=survival,tag=br_blink_lite_opportunity,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run tag @s add br_blink_lite_eligible
execute as @a[gamemode=adventure,tag=br_blink_lite_opportunity,tag=!br_dead_screen] at @s if predicate backrooms:in_backrooms run tag @s add br_blink_lite_eligible
execute as @a[tag=br_blink_lite_eligible] run scoreboard players add #blink_eligible br_blink_lite 1

# the Director owns natural blink density.
# Blink Lite remains as the technical anchor/animation engine only; no independent global natural spawn here.
return 0
