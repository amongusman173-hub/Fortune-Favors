# Director Blink group=3: choose a coherent 3-of-4 cells 2x2 motif around the primary anchor.
# Runs at primary anchor position. Each variant attempts two additional anchors.
execute store result score #blink_pattern br_blink_lite run random value 0..7
# Missing one corner in a 2x2 square, with rotated/sign variants.
execute if score #blink_pattern br_blink_lite matches 0 positioned ~4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 0 positioned ~4 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 1 positioned ~4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 1 positioned ~0 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 2 positioned ~0 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 2 positioned ~4 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 3 positioned ~-4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 3 positioned ~-4 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 4 positioned ~-4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 4 positioned ~0 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 5 positioned ~0 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 5 positioned ~4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 6 positioned ~4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 6 positioned ~4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 7 positioned ~-4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 7 positioned ~-4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
