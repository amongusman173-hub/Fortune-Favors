# Nearby candidate offset 12, 0.
execute positioned ~12 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
