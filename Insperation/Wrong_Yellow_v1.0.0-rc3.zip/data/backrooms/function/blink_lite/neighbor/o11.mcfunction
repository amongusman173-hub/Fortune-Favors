# Nearby candidate offset 0, -12.
execute positioned ~0 ~ ~-12 run function backrooms:blink_lite/try_candidate_neighbor
