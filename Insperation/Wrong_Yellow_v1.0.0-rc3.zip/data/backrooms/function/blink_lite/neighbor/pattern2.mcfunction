# Director Blink group=2: choose one coherent 2x2 motif around the primary anchor.
# Variants include diagonals and two-lamp lines. Runs at primary anchor position.
execute store result score #blink_pattern br_blink_lite run random value 0..7
# Diagonals.
execute if score #blink_pattern br_blink_lite matches 0 positioned ~4 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 1 positioned ~4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 2 positioned ~-4 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 3 positioned ~-4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
# Lines.
execute if score #blink_pattern br_blink_lite matches 4 positioned ~4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 5 positioned ~-4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 6 positioned ~0 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
execute if score #blink_pattern br_blink_lite matches 7 positioned ~0 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
