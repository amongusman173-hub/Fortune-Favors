# Nearby candidate offset 4, -4.
execute positioned ~4 ~ ~-4 run function backrooms:blink_lite/try_candidate_neighbor
