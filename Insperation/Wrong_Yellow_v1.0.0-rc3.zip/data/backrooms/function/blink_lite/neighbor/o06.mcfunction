# Nearby candidate offset 0, 8.
execute positioned ~0 ~ ~8 run function backrooms:blink_lite/try_candidate_neighbor
