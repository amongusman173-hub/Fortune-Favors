# Nearby candidate offset 0, 4.
execute positioned ~0 ~ ~4 run function backrooms:blink_lite/try_candidate_neighbor
