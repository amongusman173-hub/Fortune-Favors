# Optional second blink near the primary anchor.
execute store result score #blink_offset br_blink_lite run random value 0..15
execute if score #blink_offset br_blink_lite matches 0 run function backrooms:blink_lite/neighbor/o00
execute if score #blink_offset br_blink_lite matches 1 run function backrooms:blink_lite/neighbor/o01
execute if score #blink_offset br_blink_lite matches 2 run function backrooms:blink_lite/neighbor/o02
execute if score #blink_offset br_blink_lite matches 3 run function backrooms:blink_lite/neighbor/o03
execute if score #blink_offset br_blink_lite matches 4 run function backrooms:blink_lite/neighbor/o04
execute if score #blink_offset br_blink_lite matches 5 run function backrooms:blink_lite/neighbor/o05
execute if score #blink_offset br_blink_lite matches 6 run function backrooms:blink_lite/neighbor/o06
execute if score #blink_offset br_blink_lite matches 7 run function backrooms:blink_lite/neighbor/o07
execute if score #blink_offset br_blink_lite matches 8 run function backrooms:blink_lite/neighbor/o08
execute if score #blink_offset br_blink_lite matches 9 run function backrooms:blink_lite/neighbor/o09
execute if score #blink_offset br_blink_lite matches 10 run function backrooms:blink_lite/neighbor/o10
execute if score #blink_offset br_blink_lite matches 11 run function backrooms:blink_lite/neighbor/o11
execute if score #blink_offset br_blink_lite matches 12 run function backrooms:blink_lite/neighbor/o12
execute if score #blink_offset br_blink_lite matches 13 run function backrooms:blink_lite/neighbor/o13
execute if score #blink_offset br_blink_lite matches 14 run function backrooms:blink_lite/neighbor/o14
execute if score #blink_offset br_blink_lite matches 15 run function backrooms:blink_lite/neighbor/o15
