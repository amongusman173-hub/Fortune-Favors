# Nearby candidate offset 4, 0.
execute positioned ~4 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
