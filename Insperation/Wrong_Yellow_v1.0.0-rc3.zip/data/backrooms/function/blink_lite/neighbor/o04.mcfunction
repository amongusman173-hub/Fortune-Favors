# Nearby candidate offset 8, 0.
execute positioned ~8 ~ ~0 run function backrooms:blink_lite/try_candidate_neighbor
