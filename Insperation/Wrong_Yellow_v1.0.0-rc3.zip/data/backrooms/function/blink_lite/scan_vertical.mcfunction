# Scan likely ceiling heights above the selected distant target.
# widened from +4..+7 to +2..+10 because generated rooms can place
# defective-light candidates lower or higher than the original smoke-test helper expected.
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~2 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~3 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~4 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~5 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~6 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~7 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~8 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~9 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
execute if score #blink_found br_blink_lite matches 0 positioned ~ ~10 ~ if loaded ~ ~ ~ run function backrooms:blink_lite/scan_patch
