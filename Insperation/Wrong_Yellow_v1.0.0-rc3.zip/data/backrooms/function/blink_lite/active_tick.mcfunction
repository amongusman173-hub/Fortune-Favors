# Tick one persistent defective-light anchor.
# Director-visible anchors must not pin the blink lane forever while players stay nearby.
execute unless entity @s[tag=br_blink_ttl_init] store result score @s br_life run random value 900..1800
execute unless entity @s[tag=br_blink_ttl_init] run tag @s add br_blink_ttl_init
execute if entity @s[tag=br_blink_lite_active] run scoreboard players remove @s br_life 1
execute if entity @s[tag=br_blink_lite_active,scores={br_life=..0}] run function backrooms:blink_lite/restore_and_kill
# The marker keeps animating while a Survival/Adventure player remains close enough in the same dimension.
execute unless entity @a[gamemode=survival,distance=..64] unless entity @a[gamemode=adventure,distance=..64] run function backrooms:blink_lite/restore_and_kill
execute if entity @s[tag=br_blink_lite_active] run scoreboard players remove @s br_blink_timer 1
execute if entity @s[tag=br_blink_lite_active,tag=br_blink_lite_restore_ochre,tag=br_blink_lite_off] if score @s br_blink_timer matches ..0 run function backrooms:blink_lite/frame_on_ochre
execute if entity @s[tag=br_blink_lite_active,tag=br_blink_lite_restore_bone,tag=br_blink_lite_off] if score @s br_blink_timer matches ..0 run function backrooms:blink_lite/frame_on_bone
execute if entity @s[tag=br_blink_lite_active,tag=br_blink_lite_restore_ochre] unless entity @s[tag=br_blink_lite_off] if score @s br_blink_timer matches ..0 run function backrooms:blink_lite/frame_off_ochre
execute if entity @s[tag=br_blink_lite_active,tag=br_blink_lite_restore_bone] unless entity @s[tag=br_blink_lite_off] if score @s br_blink_timer matches ..0 run function backrooms:blink_lite/frame_off_bone
