# Blink Lite Animated Anchor debug summary.
scoreboard players set #blink_low br_blink_lite 0
scoreboard players set #blink_medium br_blink_lite 0
scoreboard players set #blink_high br_blink_lite 0
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=br_blink_mode_low] run scoreboard players add #blink_low br_blink_lite 1
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=br_blink_mode_medium] run scoreboard players add #blink_medium br_blink_lite 1
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=br_blink_mode_high] run scoreboard players add #blink_high br_blink_lite 1
tellraw @s [{"text":"[Wrong Yellow] Blink Lite v1.0.0-rc3 Candidate","color":"yellow"},{"text":" cd=","color":"gray"},{"score":{"name":"#blink_cd","objective":"br_blink_lite"}},{"text":" anchors=","color":"gray"},{"score":{"name":"#blink_active","objective":"br_blink_lite"}},{"text":" ready=","color":"gray"},{"score":{"name":"#blink_ready","objective":"br_blink_lite"}},{"text":" opp=","color":"gray"},{"score":{"name":"#blink_opportunities","objective":"br_blink_lite"}},{"text":" eligible=","color":"gray"},{"score":{"name":"#blink_eligible","objective":"br_blink_lite"}}]
tellraw @s [{"text":"Modes active low/medium/high: ","color":"gray"},{"score":{"name":"#blink_low","objective":"br_blink_lite"}},{"text":"/"},{"score":{"name":"#blink_medium","objective":"br_blink_lite"}},{"text":"/"},{"score":{"name":"#blink_high","objective":"br_blink_lite"}}]
tellraw @s [{"text":"Self scores: x=","color":"gray"},{"score":{"name":"@s","objective":"br_blink_x"}},{"text":" z=","color":"gray"},{"score":{"name":"@s","objective":"br_blink_z"}},{"text":" lastX=","color":"gray"},{"score":{"name":"@s","objective":"br_blink_last_x"}},{"text":" lastZ=","color":"gray"},{"score":{"name":"@s","objective":"br_blink_last_z"}}]
tellraw @s [{"text":"Natural anchor search requires: Backrooms + Survival/Adventure + 16-block X/Z movement. The active runtime keeps opportunities after failed distant scans and retries shortly; successful anchors keep bursty/long-tail cooldowns. Anchors pick low 5..60, medium 10..40, or high 10..30 repeat profiles; high can hold the defective frame up to 10 ticks. No sound.","color":"dark_gray"}]

# blocker snapshot for cases where cd<=0 + opp=1 + eligible=1 but no anchor appears.
scoreboard players set #blink_block_cwall br_blink_lite 0
scoreboard players set #blink_block_entity br_blink_lite 0
scoreboard players set #blink_block_attack br_blink_lite 0
scoreboard players set #blink_block_hunted br_blink_lite 0
execute if score #cw_controller_present br_cw_tmp matches 1.. run scoreboard players set #blink_block_cwall br_blink_lite 1
execute if score #br_entity_present br_tmp matches 1.. run scoreboard players set #blink_block_entity br_blink_lite 1
execute if score #br_attack_present br_tmp matches 1.. run scoreboard players set #blink_block_attack br_blink_lite 1
execute if entity @a[tag=br_hunted,limit=1] run scoreboard players set #blink_block_hunted br_blink_lite 1
tellraw @s [{"text":"[Wrong Yellow] Blink blockers cwall/entity/attack/hunted="},{"score":{"name":"#blink_block_cwall","objective":"br_blink_lite"}},{"text":"/"},{"score":{"name":"#blink_block_entity","objective":"br_blink_lite"}},{"text":"/"},{"score":{"name":"#blink_block_attack","objective":"br_blink_lite"}},{"text":"/"},{"score":{"name":"#blink_block_hunted","objective":"br_blink_lite"}}]
