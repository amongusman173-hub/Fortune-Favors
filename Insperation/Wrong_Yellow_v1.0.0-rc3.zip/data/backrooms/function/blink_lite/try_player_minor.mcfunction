# Director minor Blink placement.
# Natural Blink uses distant 32..48 block targets; that was too easy to miss during C-wall pressure.
# Minor Blink is an ambiance cue: look near/front of the primary player first, then sides.
# This function is run at the primary player's position/rotation.
scoreboard players set #blink_found br_blink_lite 0
execute if score #blink_found br_blink_lite matches 0 positioned ^ ^ ^12 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^ ^ ^16 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^ ^ ^20 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^6 ^ ^14 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^-6 ^ ^14 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^8 ^ ^20 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^-8 ^ ^20 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^12 ^ ^8 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^-12 ^ ^8 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
# Fallbacks: close lateral/back positions, still much more visible than the old 32..48 distant offsets.
execute if score #blink_found br_blink_lite matches 0 positioned ^16 ^ ^0 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^-16 ^ ^0 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 0 positioned ^ ^ ^24 if loaded ~ ~ ~ run function backrooms:blink_lite/scan_vertical
