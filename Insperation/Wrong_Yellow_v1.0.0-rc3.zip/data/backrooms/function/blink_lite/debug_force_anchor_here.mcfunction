# perf helper: create one guaranteed Blink Lite animated anchor above the caller.
# Intended only for profiling Blink active animation cost on fresh test backups.
# Usage: stand in backrooms:backrooms, then run /function backrooms:blink_lite/debug_force_anchor_here
# Cleanup: /function backrooms:admin/perf/disable_blink restores active anchors and disables Blink Lite.
scoreboard players set #blink_found br_blink_lite 1
scoreboard players set #blink_active br_blink_lite 0
execute as @e[type=minecraft:marker,tag=br_blink_lite_active] run scoreboard players add #blink_active br_blink_lite 1
execute positioned ~ ~4 ~ run setblock ~ ~ ~ minecraft:ochre_froglight replace
execute positioned ~ ~4 ~ run function backrooms:blink_lite/apply_ochre
tellraw @s {"text":"[Wrong Yellow] Blink Lite forced active fixture created at +4Y. Run Spark now; cleanup with /function backrooms:admin/perf/disable_blink.","color":"yellow"}
