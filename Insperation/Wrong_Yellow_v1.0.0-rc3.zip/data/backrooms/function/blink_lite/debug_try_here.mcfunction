# Test helper: bypass movement/cooldown and scan ceiling heights above this exact area.
scoreboard players set #blink_found br_blink_lite 0
scoreboard players set #blink_active br_blink_lite 0
execute as @e[type=minecraft:marker,tag=br_blink_lite_active] run scoreboard players add #blink_active br_blink_lite 1
execute at @s run function backrooms:blink_lite/scan_vertical
execute if score #blink_found br_blink_lite matches 1 run tellraw @s {"text":"[Wrong Yellow] Blink Lite debug_try_here found a candidate and created an animated blink anchor.","color":"green"}
execute if score #blink_found br_blink_lite matches 0 run tellraw @s {"text":"[Wrong Yellow] Blink Lite debug_try_here found no ochre_froglight/bone_block in +2..+10 ceiling patch.","color":"red"}
