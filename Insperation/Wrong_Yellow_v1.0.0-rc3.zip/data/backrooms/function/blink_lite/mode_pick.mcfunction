# choose one defective-light animation profile for this anchor.
# low: very uneven 5..60 tick repeats, 2-tick outage.
# medium: validated rhythm, 10..40 tick repeats, 2-tick outage.
# high: tighter 10..30 tick repeats, outage can stretch up to 10 ticks.
tag @s remove br_blink_mode_low
tag @s remove br_blink_mode_medium
tag @s remove br_blink_mode_high
execute store result score #blink_mode br_blink_lite run random value 0..2
execute if score #blink_mode br_blink_lite matches 0 run tag @s add br_blink_mode_low
execute if score #blink_mode br_blink_lite matches 1 run tag @s add br_blink_mode_medium
execute if score #blink_mode br_blink_lite matches 2 run tag @s add br_blink_mode_high
