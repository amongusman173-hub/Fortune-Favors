# Rebuild the cheap Blink Lite active-anchor flag/count.
# This runs on reload/first tick and then only once per second.
scoreboard players set #blink_active br_blink_lite 0
execute as @e[type=minecraft:marker,tag=br_blink_lite_active] run scoreboard players add #blink_active br_blink_lite 1
scoreboard players set #blink_anchor_present br_blink_lite 0
execute if score #blink_active br_blink_lite matches 1.. run scoreboard players set #blink_anchor_present br_blink_lite 1
