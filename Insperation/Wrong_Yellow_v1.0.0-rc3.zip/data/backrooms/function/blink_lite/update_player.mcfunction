# Create an opportunity only after meaningful exploration movement.
execute store result score @s br_blink_x run data get entity @s Pos[0] 1
execute store result score @s br_blink_z run data get entity @s Pos[2] 1

scoreboard players operation @s br_blink_lite = @s br_blink_x
scoreboard players operation @s br_blink_lite -= @s br_blink_last_x
execute if score @s br_blink_lite matches 16.. run function backrooms:blink_lite/mark_moved
execute if score @s br_blink_lite matches ..-16 run function backrooms:blink_lite/mark_moved

scoreboard players operation @s br_blink_lite = @s br_blink_z
scoreboard players operation @s br_blink_lite -= @s br_blink_last_z
execute if score @s br_blink_lite matches 16.. run function backrooms:blink_lite/mark_moved
execute if score @s br_blink_lite matches ..-16 run function backrooms:blink_lite/mark_moved
