# Restore normal ochre lamp, then choose the next random defective blink delay.
execute if block ~ ~ ~ minecraft:bone_block run function backrooms:sound/blink_anvil_1t
execute if block ~ ~ ~ minecraft:bone_block run setblock ~ ~ ~ minecraft:ochre_froglight replace
tag @s remove br_blink_lite_off
function backrooms:blink_lite/set_on_delay
