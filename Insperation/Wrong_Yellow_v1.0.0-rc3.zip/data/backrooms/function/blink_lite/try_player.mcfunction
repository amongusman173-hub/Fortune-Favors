# Consume the exploration opportunity only when a real anchor is created.
# test up to four distant ceiling offsets before giving up.
scoreboard players set #blink_found br_blink_lite 0
# Attempt 1.
execute store result score #blink_offset br_blink_lite run random value 0..15
execute if score #blink_offset br_blink_lite matches 0 run function backrooms:blink_lite/target/o00
execute if score #blink_offset br_blink_lite matches 1 run function backrooms:blink_lite/target/o01
execute if score #blink_offset br_blink_lite matches 2 run function backrooms:blink_lite/target/o02
execute if score #blink_offset br_blink_lite matches 3 run function backrooms:blink_lite/target/o03
execute if score #blink_offset br_blink_lite matches 4 run function backrooms:blink_lite/target/o04
execute if score #blink_offset br_blink_lite matches 5 run function backrooms:blink_lite/target/o05
execute if score #blink_offset br_blink_lite matches 6 run function backrooms:blink_lite/target/o06
execute if score #blink_offset br_blink_lite matches 7 run function backrooms:blink_lite/target/o07
execute if score #blink_offset br_blink_lite matches 8 run function backrooms:blink_lite/target/o08
execute if score #blink_offset br_blink_lite matches 9 run function backrooms:blink_lite/target/o09
execute if score #blink_offset br_blink_lite matches 10 run function backrooms:blink_lite/target/o10
execute if score #blink_offset br_blink_lite matches 11 run function backrooms:blink_lite/target/o11
execute if score #blink_offset br_blink_lite matches 12 run function backrooms:blink_lite/target/o12
execute if score #blink_offset br_blink_lite matches 13 run function backrooms:blink_lite/target/o13
execute if score #blink_offset br_blink_lite matches 14 run function backrooms:blink_lite/target/o14
execute if score #blink_offset br_blink_lite matches 15 run function backrooms:blink_lite/target/o15
# Attempt 2.
execute if score #blink_found br_blink_lite matches 0 store result score #blink_offset br_blink_lite run random value 0..15
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 0 run function backrooms:blink_lite/target/o00
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 1 run function backrooms:blink_lite/target/o01
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 2 run function backrooms:blink_lite/target/o02
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 3 run function backrooms:blink_lite/target/o03
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 4 run function backrooms:blink_lite/target/o04
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 5 run function backrooms:blink_lite/target/o05
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 6 run function backrooms:blink_lite/target/o06
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 7 run function backrooms:blink_lite/target/o07
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 8 run function backrooms:blink_lite/target/o08
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 9 run function backrooms:blink_lite/target/o09
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 10 run function backrooms:blink_lite/target/o10
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 11 run function backrooms:blink_lite/target/o11
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 12 run function backrooms:blink_lite/target/o12
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 13 run function backrooms:blink_lite/target/o13
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 14 run function backrooms:blink_lite/target/o14
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 15 run function backrooms:blink_lite/target/o15
# Attempt 3.
execute if score #blink_found br_blink_lite matches 0 store result score #blink_offset br_blink_lite run random value 0..15
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 0 run function backrooms:blink_lite/target/o00
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 1 run function backrooms:blink_lite/target/o01
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 2 run function backrooms:blink_lite/target/o02
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 3 run function backrooms:blink_lite/target/o03
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 4 run function backrooms:blink_lite/target/o04
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 5 run function backrooms:blink_lite/target/o05
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 6 run function backrooms:blink_lite/target/o06
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 7 run function backrooms:blink_lite/target/o07
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 8 run function backrooms:blink_lite/target/o08
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 9 run function backrooms:blink_lite/target/o09
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 10 run function backrooms:blink_lite/target/o10
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 11 run function backrooms:blink_lite/target/o11
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 12 run function backrooms:blink_lite/target/o12
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 13 run function backrooms:blink_lite/target/o13
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 14 run function backrooms:blink_lite/target/o14
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 15 run function backrooms:blink_lite/target/o15
# Attempt 4.
execute if score #blink_found br_blink_lite matches 0 store result score #blink_offset br_blink_lite run random value 0..15
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 0 run function backrooms:blink_lite/target/o00
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 1 run function backrooms:blink_lite/target/o01
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 2 run function backrooms:blink_lite/target/o02
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 3 run function backrooms:blink_lite/target/o03
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 4 run function backrooms:blink_lite/target/o04
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 5 run function backrooms:blink_lite/target/o05
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 6 run function backrooms:blink_lite/target/o06
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 7 run function backrooms:blink_lite/target/o07
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 8 run function backrooms:blink_lite/target/o08
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 9 run function backrooms:blink_lite/target/o09
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 10 run function backrooms:blink_lite/target/o10
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 11 run function backrooms:blink_lite/target/o11
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 12 run function backrooms:blink_lite/target/o12
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 13 run function backrooms:blink_lite/target/o13
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 14 run function backrooms:blink_lite/target/o14
execute if score #blink_found br_blink_lite matches 0 if score #blink_offset br_blink_lite matches 15 run function backrooms:blink_lite/target/o15
execute if score #blink_found br_blink_lite matches 1 run tag @s remove br_blink_lite_opportunity
