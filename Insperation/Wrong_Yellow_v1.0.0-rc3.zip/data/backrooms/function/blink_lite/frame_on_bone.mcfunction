# Restore normal bone block, then choose the next random defective blink delay.
execute if block ~ ~ ~ minecraft:ochre_froglight run setblock ~ ~ ~ minecraft:bone_block replace
tag @s remove br_blink_lite_off
function backrooms:blink_lite/set_on_delay
