# Defective lit frame: bone_block -> ochre_froglight.
execute if block ~ ~ ~ minecraft:bone_block run function backrooms:sound/blink_anvil_1t
execute if block ~ ~ ~ minecraft:bone_block run setblock ~ ~ ~ minecraft:ochre_froglight replace
tag @s add br_blink_lite_off
function backrooms:blink_lite/set_off_duration
