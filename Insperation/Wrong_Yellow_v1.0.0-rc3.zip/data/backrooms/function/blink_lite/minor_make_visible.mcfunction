# make Director minor Blink readable.
# The previous version often created a valid anchor, but too far away and with a 2-tick outage.
# In minor mode, the new anchor gets the high profile and a longer first defective frame.
execute as @e[type=minecraft:marker,tag=br_blink_lite_active,tag=!br_blink_minor_visible] run tag @s add br_blink_minor_visible
execute as @e[type=minecraft:marker,tag=br_blink_minor_visible] run tag @s remove br_blink_mode_low
execute as @e[type=minecraft:marker,tag=br_blink_minor_visible] run tag @s remove br_blink_mode_medium
execute as @e[type=minecraft:marker,tag=br_blink_minor_visible] run tag @s add br_blink_mode_high
execute as @e[type=minecraft:marker,tag=br_blink_minor_visible] run scoreboard players set @s br_blink_timer 12
