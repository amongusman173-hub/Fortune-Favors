# Delay before next defective-light toggle, according to the anchor profile.
execute if entity @s[tag=br_blink_mode_low] store result score @s br_blink_timer run random value 5..60
execute if entity @s[tag=br_blink_mode_medium] store result score @s br_blink_timer run random value 10..40
execute if entity @s[tag=br_blink_mode_high] store result score @s br_blink_timer run random value 10..30
execute unless entity @s[tag=br_blink_mode_low] unless entity @s[tag=br_blink_mode_medium] unless entity @s[tag=br_blink_mode_high] store result score @s br_blink_timer run random value 10..40
