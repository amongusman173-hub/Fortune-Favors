# Compatibility wrapper: animated anchors now restore through restore_and_kill.
function backrooms:blink_lite/restore_and_kill
