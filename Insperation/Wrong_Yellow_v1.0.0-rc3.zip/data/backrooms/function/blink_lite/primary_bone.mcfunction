# Anchor found: light this inverse lamp, then maybe blink nearby lamps in the same room.
# #blink_minor_mode 2/3 now means forced double/triple for Stress Hard groups.
scoreboard players set #blink_found br_blink_lite 1
function backrooms:blink_lite/apply_bone
# Director group modes: use coherent 2x2 patterns instead of independent random neighbors.
execute if score #blink_minor_mode br_blink_lite matches 2 run function backrooms:blink_lite/neighbor/pattern2
execute if score #blink_minor_mode br_blink_lite matches 3 run function backrooms:blink_lite/neighbor/pattern3
# Legacy/natural mode keeps old small random neighbor chance.
execute store result score #blink_roll br_blink_lite run random value 0..99
execute if score #blink_minor_mode br_blink_lite matches 0 if score #blink_roll br_blink_lite matches 0..19 run function backrooms:blink_lite/neighbor/try_second
execute store result score #blink_roll br_blink_lite run random value 0..99
execute if score #blink_minor_mode br_blink_lite matches 0 if score #blink_roll br_blink_lite matches 0..4 run function backrooms:blink_lite/neighbor/try_third
