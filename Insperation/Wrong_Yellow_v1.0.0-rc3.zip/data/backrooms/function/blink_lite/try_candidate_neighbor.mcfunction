# Nearby candidate around the anchor. One random offset is tested per optional blink.
execute if score #blink_active br_blink_lite matches ..2 unless entity @e[type=minecraft:marker,tag=br_blink_lite_active,distance=..0.5] if block ~ ~ ~ minecraft:ochre_froglight run function backrooms:blink_lite/apply_ochre
execute if score #blink_active br_blink_lite matches ..2 unless entity @e[type=minecraft:marker,tag=br_blink_lite_active,distance=..0.5] if block ~ ~ ~ minecraft:bone_block run function backrooms:blink_lite/apply_bone
