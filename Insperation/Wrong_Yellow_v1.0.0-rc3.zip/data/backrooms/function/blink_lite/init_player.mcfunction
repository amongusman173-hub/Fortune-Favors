# Initialize blink movement tracking without triggering an event on entry.
tag @s add br_blink_lite_ready
execute store result score @s br_blink_x run data get entity @s Pos[0] 1
execute store result score @s br_blink_z run data get entity @s Pos[2] 1
scoreboard players operation @s br_blink_last_x = @s br_blink_x
scoreboard players operation @s br_blink_last_z = @s br_blink_z
scoreboard players set @s br_blink_lite 0
