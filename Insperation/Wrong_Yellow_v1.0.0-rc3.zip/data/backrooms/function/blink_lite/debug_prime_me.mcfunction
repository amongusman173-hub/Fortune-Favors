# Test helper: force this player to be eligible for one natural Blink Lite attempt.
tag @s add br_blink_lite_ready
tag @s add br_blink_lite_opportunity
tag @s add br_blink_lite_eligible
scoreboard players set #blink_cd br_blink_lite 0
tellraw @s {"text":"[Wrong Yellow] Blink Lite primed. Walk or wait one tick in Survival/Adventure inside the Backrooms.","color":"yellow"}
