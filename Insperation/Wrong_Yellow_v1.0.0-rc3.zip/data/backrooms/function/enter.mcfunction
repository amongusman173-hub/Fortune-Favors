function backrooms:runtime/ensure_ready
# no automatic hub/safe-room runtime. Enter the normal Backrooms worldgen only.
function backrooms:entry/teleport_safe
function backrooms:clear_transition_effects
