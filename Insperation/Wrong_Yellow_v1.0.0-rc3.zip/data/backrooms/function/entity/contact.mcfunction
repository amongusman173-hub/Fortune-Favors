# Contact with the attack manifestation. Creative and spectator are ignored.
execute if entity @s[gamemode=creative] run return 0
execute if entity @s[gamemode=spectator] run return 0
execute if predicate backrooms:in_backrooms run function backrooms:entity/contact_backrooms
execute unless predicate backrooms:in_backrooms run function backrooms:entity/fake_death
