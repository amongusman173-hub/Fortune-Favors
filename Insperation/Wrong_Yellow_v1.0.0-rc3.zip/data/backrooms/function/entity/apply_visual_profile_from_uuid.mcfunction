# Apply the selected online-player profile to one hidden pooled mannequin.
$data merge entity @e[type=minecraft:mannequin,tag=br_entity_visual_reusing,limit=1] {profile:{id:$(id)},Invisible:1b,Glowing:0b,Invulnerable:1b,Silent:1b,NoGravity:1b}
