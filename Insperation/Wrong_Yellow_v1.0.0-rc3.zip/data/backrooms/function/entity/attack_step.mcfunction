# Backrooms hostile movement.
# Carpet is the entity's invocation medium:
# - missing carpet under it = rupture/disappearance
# - voluntary chase never leaves brown_carpet
# - forced knockback can push it off brown_carpet; that ruptures it immediately
# 66.27 change: detour is now a persistent local state. It does not cancel on
# the first failed sidestep, and it does not exit just because a frozen forward
# micro-step is briefly carpeted. Direct chase resumes only after a real probe
# toward the hunted player finds a carpeted lane.
execute if entity @s[tag=br_entity_preparing] run return 0

execute unless block ~ ~-0.1 ~ minecraft:brown_carpet run return run function backrooms:entity/forced_carpet_cancel
# Warning state: visible, immobile, non-damaging. It attacks only after 30 continuous ticks of being looked at.
# warning_step decrements its own timeout before refusing dead-screen targeting.
execute if entity @s[tag=br_entity_warning] run return run function backrooms:entity/warning_step

# A dead-screen target no longer drives chase movement or sounds. The active marker keeps its own br_life timeout.
execute unless entity @a[tag=br_hunted,tag=!br_dead_screen,tag=!backrooms_leaving,gamemode=!creative,gamemode=!spectator,distance=..160,limit=1] run return 0

# Runtime scores are created lazily for old worlds/fresh fixtures.
scoreboard players add @s br_entity_kb 0
scoreboard players add @s br_entity_slide 0
scoreboard players add @s br_entity_slide_t 0
scoreboard players set @s br_tmp 0

# Hit reaction: a short scripted knockback phase. It suspends voluntary chase.
execute if score @s br_entity_kb matches 1.. run return run function backrooms:entity/knockback_step

# Detour mode: keep the previous rotation and wall-follow locally. Do not face
# the player until detour_step explicitly decides that a real chase lane is open.
execute if score @s br_entity_slide_t matches 1.. run return run function backrooms:entity/detour_step

# Normal chase: face the target only while not in detour mode.
execute facing entity @a[tag=br_hunted,tag=!br_dead_screen,tag=!backrooms_leaving,gamemode=!creative,gamemode=!spectator,distance=..160,limit=1,sort=nearest] feet rotated ~ 0 run tp @s ~ ~ ~ ~ ~

# Try direct forward step first. Missing carpet ahead behaves as a wall.
function backrooms:entity/move_forward
execute if score @s br_tmp matches 1 run scoreboard players set @s br_entity_slide_t 0
execute if score @s br_tmp matches 1 run function backrooms:sound/entity_footstep
execute if score @s br_tmp matches 1 run return 0

# Direct route is blocked: enter a stable detour lane. The chosen side is kept
# for a burst of about 2.8 blocks at 0.28 block/tick. If that side is invalid,
# detour_step can keep trying, flip, and probe for a real route back to chase.
scoreboard players set @s br_tmp 0
execute store result score @s br_entity_slide run random value 0..1
execute if score @s br_entity_slide matches 0 run scoreboard players set @s br_entity_slide -1
execute if score @s br_entity_slide matches 1 run scoreboard players set @s br_entity_slide 1
scoreboard players set @s br_entity_slide_t 10
function backrooms:entity/detour_step
