# Compatibility wrapper for the old V15b name. V15c returns to the V11 appearance behavior.
function backrooms:entity/appear
