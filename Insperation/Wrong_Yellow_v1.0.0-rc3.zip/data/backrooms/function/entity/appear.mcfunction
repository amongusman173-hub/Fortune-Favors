# appearance wrapper. Backrooms = spawn only on valid brown_carpet. Overworld = preserved V16c behavior.
execute if predicate backrooms:in_backrooms run function backrooms:entity/appear_backrooms_carpet
execute unless predicate backrooms:in_backrooms run function backrooms:entity/appear_overworld
