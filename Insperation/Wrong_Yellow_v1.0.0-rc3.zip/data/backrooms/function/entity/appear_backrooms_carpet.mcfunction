# Backrooms subliminal appearance only on brown_carpet, 4..6 blocks from player, with two air blocks above.
scoreboard players set @s br_tmp 0
execute store result score @s br_rand run random value 0..15
execute if score @s br_rand matches 0 run function backrooms:entity/try_subliminal_carpet/order00
execute if score @s br_rand matches 1 run function backrooms:entity/try_subliminal_carpet/order01
execute if score @s br_rand matches 2 run function backrooms:entity/try_subliminal_carpet/order02
execute if score @s br_rand matches 3 run function backrooms:entity/try_subliminal_carpet/order03
execute if score @s br_rand matches 4 run function backrooms:entity/try_subliminal_carpet/order04
execute if score @s br_rand matches 5 run function backrooms:entity/try_subliminal_carpet/order05
execute if score @s br_rand matches 6 run function backrooms:entity/try_subliminal_carpet/order06
execute if score @s br_rand matches 7 run function backrooms:entity/try_subliminal_carpet/order07
execute if score @s br_rand matches 8 run function backrooms:entity/try_subliminal_carpet/order08
execute if score @s br_rand matches 9 run function backrooms:entity/try_subliminal_carpet/order09
execute if score @s br_rand matches 10 run function backrooms:entity/try_subliminal_carpet/order10
execute if score @s br_rand matches 11 run function backrooms:entity/try_subliminal_carpet/order11
execute if score @s br_rand matches 12 run function backrooms:entity/try_subliminal_carpet/order12
execute if score @s br_rand matches 13 run function backrooms:entity/try_subliminal_carpet/order13
execute if score @s br_rand matches 14 run function backrooms:entity/try_subliminal_carpet/order14
execute if score @s br_rand matches 15 run function backrooms:entity/try_subliminal_carpet/order15
execute if score @s br_tmp matches 1 run scoreboard players set @s br_seen 0
# If no valid brown_carpet spot exists among the candidates, retry soon instead of spamming every tick.
execute unless score @s br_tmp matches 1 run scoreboard players set @s br_timer 10
