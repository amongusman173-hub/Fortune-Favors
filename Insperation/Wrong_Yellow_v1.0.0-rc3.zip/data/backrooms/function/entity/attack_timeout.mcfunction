# clean despawn for an attack entity that reached the end of its lifetime.
execute as @a[tag=br_hunted,distance=..96,sort=nearest,limit=1] run function backrooms:entity/end_hunt_cooldown
function backrooms:entity/vanish_entity
