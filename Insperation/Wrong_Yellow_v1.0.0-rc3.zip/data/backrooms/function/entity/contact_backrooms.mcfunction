# Marker engines have no vanilla attack, so contact damage is explicit and rate-limited.
damage @s 4 minecraft:mob_attack
scoreboard players set @s br_entity_hit_cd 10
playsound minecraft:entity.player.hurt master @s ~ ~ ~ 0.55 0.7
