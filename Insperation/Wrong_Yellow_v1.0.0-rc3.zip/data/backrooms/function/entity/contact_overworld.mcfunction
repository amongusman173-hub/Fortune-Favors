# compatibility: in V15c, Overworld contact uses the V11 fake-death route.
function backrooms:entity/fake_death
