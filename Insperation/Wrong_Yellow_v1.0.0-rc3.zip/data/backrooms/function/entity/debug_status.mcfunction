# Compatibility wrapper.
function backrooms:entity/debug/status
