# return to the V15g/V11-feel Overworld attack.
# Do NOT kill the subliminal appearance: convert it into a hostile.
# This avoids the V15h symptom: missing hostile / zombie pops then dies.
tag @e[tag=br_entity_vanish_pending,distance=..128,limit=1,sort=nearest] add br_entity_attack
tag @e[tag=br_entity_subliminal,distance=..128,limit=1,sort=nearest] add br_entity_attack
tag @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] remove br_entity_vanish_pending
tag @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] remove br_entity_subliminal
scoreboard players set #br_entity_present br_tmp 1
scoreboard players set #br_attack_present br_tmp 1
data merge entity @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] {NoAI:0b,Silent:0b,Glowing:0b,Invulnerable:0b,DeathLootTable:"minecraft:empty",PersistenceRequired:0b,CanPickUpLoot:0b,IsBaby:0b}
attribute @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] minecraft:movement_speed base set 0.45
attribute @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] minecraft:follow_range base set 64
attribute @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] minecraft:attack_damage base set 0
scoreboard players set @s br_seen 0
scoreboard players set @s br_timer 999999
tag @s remove br_debug_fast
scoreboard players set @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] br_life 600

execute at @e[tag=br_entity_attack,distance=..128,limit=1,sort=nearest] unless entity @e[tag=br_entity_visual,distance=..8,limit=1] run function backrooms:entity/attach_visual_here
