# Attach a random online player's profile. Every mannequin stays invisible until its profile and gear are ready.
data remove storage backrooms:entity_visual id
tag @a remove br_entity_visual_src
execute as @a[tag=!br_entity_visual_last,sort=random,limit=1] run tag @s add br_entity_visual_src
execute unless entity @a[tag=br_entity_visual_src,limit=1] as @a[sort=random,limit=1] run tag @s add br_entity_visual_src
execute as @a[tag=br_entity_visual_src,limit=1] run data modify storage backrooms:entity_visual id set from entity @s UUID

# Prefer a pooled hidden mannequin; otherwise summon a new hidden mannequin with the final profile already assigned.
execute unless entity @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1] if entity @e[type=minecraft:mannequin,tag=br_entity_visual_pool,limit=1] run function backrooms:entity/reuse_visual_from_pool
execute as @a[tag=br_entity_visual_src,limit=1] run function backrooms:entity/summon_visual_from_source

# No Steve/Alex fallback: a failed profile creation aborts this manifestation instead of flashing a default skin.
execute if entity @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1,sort=nearest] run function backrooms:entity/prepare_visual_here
team join br_entity_visual @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1,sort=nearest]
tag @a[tag=br_entity_visual_last] remove br_entity_visual_last
tag @a[tag=br_entity_visual_src] add br_entity_visual_last
tag @a remove br_entity_visual_src
