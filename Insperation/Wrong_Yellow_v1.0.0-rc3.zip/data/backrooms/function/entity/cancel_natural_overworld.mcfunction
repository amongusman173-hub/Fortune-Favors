# anti-Overworld safety.
# If a natural Backrooms chase follows the player outside the dimension, cancel it.
# Do not broad-clean nearby manifestations; the shared marker pass resolves them without harming other players.
tag @s remove br_hunted
tag @s remove br_natural_hunt
scoreboard players set @s br_seen 0
scoreboard players set @s br_sight_count 0
scoreboard players set @s br_attack_after 0
scoreboard players set @s br_timer 0
execute store result score @s br_entity_cd run random value 6000..12000
