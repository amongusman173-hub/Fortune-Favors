# shared Backrooms entity work, reached only when an eligible player exists.
# Idle players only pay their long natural cooldown clock once per second.
scoreboard players add #br_entity_idle_tick br_tmp 1
execute if score #br_entity_idle_tick br_tmp matches 20.. run scoreboard players set #br_entity_idle_tick br_tmp 0
execute if score #br_entity_idle_tick br_tmp matches 0 as @a[tag=br_entity_runtime,tag=!br_hunted,tag=!br_dead_screen] at @s run function backrooms:entity/player_idle_tick
execute as @a[tag=br_entity_runtime,tag=br_hunted] at @s run function backrooms:entity/player_tick

# Reconcile loaded manifestation flags once per second, and immediately after old worlds/reloads.
execute unless score #br_entity_present br_tmp matches -2147483648..2147483647 run function backrooms:entity/reconcile_active
scoreboard players add #br_entity_reconcile_tick br_tmp 1
execute if score #br_entity_reconcile_tick br_tmp matches 20.. run scoreboard players set #br_entity_reconcile_tick br_tmp 0
execute if score #br_entity_reconcile_tick br_tmp matches 0 run function backrooms:entity/reconcile_active

scoreboard players set #br_hunted_count br_tmp 0
execute as @a[tag=br_entity_runtime,tag=br_hunted] run scoreboard players add #br_hunted_count br_tmp 1

# Natural Entity scheduling is owned by the Director.

# Dimension-local cleanup happens before the hunted player phases.
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[tag=br_entity,tag=!br_entity_oneshot] at @s unless entity @a[tag=br_entity_runtime,tag=br_hunted,distance=..160,limit=1] run function backrooms:entity/vanish_entity
execute as @a[tag=br_entity_runtime,tag=br_hunted,tag=!br_dead_screen] at @s run function backrooms:entity/player_hunt_tick
execute if score #br_vanish_present br_tmp matches 1.. in backrooms:backrooms as @e[tag=br_entity_vanish_pending] run scoreboard players remove @s br_phase 1
execute if score #br_vanish_present br_tmp matches 1.. in backrooms:backrooms as @e[tag=br_entity_vanish_pending,scores={br_phase=..0}] at @s run function backrooms:entity/vanish_entity


# subliminal idle markers: stay until seen, retry near the hunted player if left behind, abandon after 60s.
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_subliminal,tag=!br_entity_oneshot] at @s run function backrooms:entity/subliminal_idle_tick

# one-shot subliminal ambience markers: idle until seen; retry near player if left behind; no hunt/event lock.
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_oneshot] at @s run function backrooms:entity/oneshot/tick

# actual chase minimum: avoid one-tick fake climaxes if a chase collapses immediately.
execute if score #br_attack_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_attack,tag=!br_entity_warning,scores={br_phase=1..}] run scoreboard players remove @s br_phase 1

# Scripted movement remains 20 Hz while an actual attack marker exists.
execute if score #br_attack_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_attack] at @s run function backrooms:entity/attack_step
execute if score #br_attack_present br_tmp matches 1.. in backrooms:backrooms as @e[tag=br_entity_attack,tag=!br_entity_warning] run scoreboard players remove @s br_life 1
execute if score #br_attack_present br_tmp matches 1.. in backrooms:backrooms as @e[tag=br_entity_attack,tag=!br_entity_warning,scores={br_life=..0}] at @s run function backrooms:entity/attack_timeout

# Hidden profile warmup and delayed pooling are processed explicitly in both supported dimensions.
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pending_reveal,scores={br_entity_cloak=1..}] run scoreboard players remove @s br_entity_cloak 1
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pending_reveal,scores={br_entity_cloak=..0}] at @s run function backrooms:entity/reveal_reused_visuals
execute in minecraft:overworld as @e[type=minecraft:mannequin,tag=br_entity_visual_pending_reveal,scores={br_entity_cloak=1..}] run scoreboard players remove @s br_entity_cloak 1
execute in minecraft:overworld as @e[type=minecraft:mannequin,tag=br_entity_visual_pending_reveal,scores={br_entity_cloak=..0}] at @s run function backrooms:entity/reveal_reused_visuals
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pool_pending,scores={br_entity_cloak=1..}] run scoreboard players remove @s br_entity_cloak 1
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual_pool_pending,scores={br_entity_cloak=..0}] at @s run function backrooms:entity/finish_pool_visual
execute in minecraft:overworld as @e[type=minecraft:mannequin,tag=br_entity_visual_pool_pending,scores={br_entity_cloak=1..}] run scoreboard players remove @s br_entity_cloak 1
execute in minecraft:overworld as @e[type=minecraft:mannequin,tag=br_entity_visual_pool_pending,scores={br_entity_cloak=..0}] at @s run function backrooms:entity/finish_pool_visual

# Visual and hitbox follow only the local engine marker. Large relocations always happen while the visual is hidden.
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity] at @s run tp @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..4,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity] at @s run tp @e[type=minecraft:interaction,tag=br_entity_hitbox,distance=..4,limit=1,sort=nearest] ~ ~ ~ ~ ~
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:interaction,tag=br_entity_hitbox,nbt={attack:{}}] at @s run function backrooms:entity/hitbox_attacked
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual] at @s unless entity @e[type=minecraft:marker,tag=br_entity,distance=..12,limit=1] run function backrooms:entity/vanish_visual_entity
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:interaction,tag=br_entity_hitbox] at @s unless entity @e[type=minecraft:marker,tag=br_entity,distance=..12,limit=1] run kill @s
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity] at @s unless entity @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..4,limit=1] run function backrooms:entity/attach_visual_here
execute if score #br_entity_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity,tag=!br_entity_preparing] at @s if entity @e[type=minecraft:mannequin,tag=br_entity_visual,tag=!br_entity_visual_pending_reveal,distance=..4,limit=1] unless entity @e[type=minecraft:interaction,tag=br_entity_hitbox,distance=..4,limit=1] run function backrooms:entity/ensure_hitbox_here
# Optional debug-only marker/contact visibility for hitbox/visual sync tests.
execute if score #br_entity_hitbox_debug br_tmp matches 1.. if score #br_attack_present br_tmp matches 1.. in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_attack] at @s run function backrooms:entity/debug/hitbox_particles_tick
