# Enable visible hitbox/contact particles for Entity tests. Debug only.
scoreboard players set #br_entity_hitbox_debug br_tmp 1
tellraw @s {"text":"[WY entity] Hitbox/contact debug particles enabled. Disable with /function backrooms:entity/debug/disable_hitbox_debug.","color":"green"}
