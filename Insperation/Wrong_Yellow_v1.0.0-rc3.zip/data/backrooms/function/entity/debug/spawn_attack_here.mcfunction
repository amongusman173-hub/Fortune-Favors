# Deterministic Backrooms hostile smoke test.
# This bypasses the subliminal "seen three times" loop and starts a real chase immediately.
execute unless entity @s run tellraw @a {"text":"[WY entity] Run this function as a player.","color":"red"}
execute unless entity @s run return 0
execute unless predicate backrooms:in_backrooms run tellraw @s {"text":"[WY entity] This debug attack is Backrooms-only.","color":"red"}
execute unless predicate backrooms:in_backrooms run return 0
execute if entity @s[gamemode=creative] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=creative] run return 0
execute if entity @s[gamemode=spectator] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=spectator] run return 0

tag @s remove br_debug_attack_new_hunt
execute unless entity @s[tag=br_hunted] run tag @s add br_debug_attack_new_hunt
tag @s add br_hunted
tag @s add br_debug_fast
scoreboard players set @s br_sight_count 0
scoreboard players set @s br_attack_after 1
scoreboard players set @s br_seen 0
scoreboard players set @s br_tmp 0
function backrooms:entity/spawn_backrooms_hostile
execute if score @s br_tmp matches 1 at @s as @e[type=minecraft:marker,tag=br_entity_attack,distance=..32,limit=1,sort=nearest] run function backrooms:entity/start_chase
execute if score @s br_tmp matches 1 run scoreboard players set #br_entity_present br_tmp 1
execute if score @s br_tmp matches 1 run scoreboard players set #br_attack_present br_tmp 1
execute if score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] Debug hostile spawned and chase started.","color":"green"}
execute unless score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] No valid brown_carpet attack spot found around you. Try a larger carpeted Backrooms area.","color":"red"}
execute unless score @s br_tmp matches 1 if entity @s[tag=br_debug_attack_new_hunt] run tag @s remove br_hunted
execute unless score @s br_tmp matches 1 run tag @s remove br_debug_fast
tag @s remove br_debug_attack_new_hunt
