# helper. Executed at a candidate carpet block with @s = player.
# Spawns the active marker + a non-glowing visible mannequin fixture directly on a
# valid brown_carpet block. This bypasses random spot selection only; the normal
# active_tick / attack_step path drives it afterwards.
execute unless block ~ ~ ~ minecraft:brown_carpet run return 0
execute unless block ~ ~1 ~ #backrooms:entity_spawn_clear run return 0
execute unless block ~ ~2 ~ #backrooms:entity_spawn_clear run return 0
execute if entity @e[type=minecraft:marker,tag=br_entity_attack,distance=..3,limit=1] run return 0

execute store success score @s br_tmp run summon minecraft:marker ~ ~0.1 ~ {Tags:["br_entity","br_entity_attack","br_entity_debug_fixture"]}
execute if score @s br_tmp matches 1 as @e[type=minecraft:marker,tag=br_entity_attack,tag=br_entity_debug_fixture,distance=..3,limit=1,sort=nearest] at @s facing entity @a[tag=br_hunted,gamemode=!creative,gamemode=!spectator,distance=..160,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute if score @s br_tmp matches 1 as @e[type=minecraft:marker,tag=br_entity_attack,tag=br_entity_debug_fixture,distance=..3,limit=1,sort=nearest] run scoreboard players set @s br_life 200
execute if score @s br_tmp matches 1 as @e[type=minecraft:marker,tag=br_entity_attack,tag=br_entity_debug_fixture,distance=..3,limit=1,sort=nearest] run scoreboard players set @s br_phase 0
execute if score @s br_tmp matches 1 as @e[type=minecraft:marker,tag=br_entity_attack,tag=br_entity_debug_fixture,distance=..3,limit=1,sort=nearest] run scoreboard players set @s br_seen 0
# Use the real visual-attachment path so the fixture also tests random-player appearance
# selection and one-time armor/hand item copying. The selected mannequin is not glowing;
# use hitbox debug particles for visibility/sync testing.
execute if score @s br_tmp matches 1 at @e[type=minecraft:marker,tag=br_entity_attack,tag=br_entity_debug_fixture,distance=..3,limit=1,sort=nearest] run function backrooms:entity/attach_visual_here
execute if score @s br_tmp matches 1 run scoreboard players set #br_entity_present br_tmp 1
execute if score @s br_tmp matches 1 run scoreboard players set #br_attack_present br_tmp 1
