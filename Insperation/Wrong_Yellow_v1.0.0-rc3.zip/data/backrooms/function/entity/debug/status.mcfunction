# Numeric status for the existing manifestation runtime.
scoreboard players set #br_dbg_engines br_tmp 0
scoreboard players set #br_dbg_subliminal br_tmp 0
scoreboard players set #br_dbg_attack br_tmp 0
scoreboard players set #br_dbg_visuals br_tmp 0
scoreboard players set #br_dbg_hunted br_tmp 0
scoreboard players set #br_dbg_warning br_tmp 0
scoreboard players set #br_dbg_fixture br_tmp 0
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity] run scoreboard players add #br_dbg_engines br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_subliminal] run scoreboard players add #br_dbg_subliminal br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_attack] run scoreboard players add #br_dbg_attack br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_warning] run scoreboard players add #br_dbg_warning br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_debug_fixture] run scoreboard players add #br_dbg_fixture br_tmp 1
execute in backrooms:backrooms as @e[type=minecraft:mannequin,tag=br_entity_visual] run scoreboard players add #br_dbg_visuals br_tmp 1
execute as @a[tag=br_hunted] at @s if predicate backrooms:in_backrooms run scoreboard players add #br_dbg_hunted br_tmp 1

tellraw @s [{"text":"[WY Entity v1.0.0-rc3 Candidate] engines/subliminal/attack/warning/visuals/hunted/fixture: ","color":"gold"},{"score":{"name":"#br_dbg_engines","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_subliminal","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_attack","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_warning","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_visuals","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_hunted","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_dbg_fixture","objective":"br_tmp"}}]
execute if entity @s run tellraw @s [{"text":"player timer/sights/attack_after/cooldown/hit_cd/deaths: ","color":"aqua"},{"score":{"name":"@s","objective":"br_timer"}},{"text":"/"},{"score":{"name":"@s","objective":"br_sight_count"}},{"text":"/"},{"score":{"name":"@s","objective":"br_attack_after"}},{"text":"/"},{"score":{"name":"@s","objective":"br_entity_cd"}},{"text":"/"},{"score":{"name":"@s","objective":"br_entity_hit_cd"}},{"text":"/"},{"score":{"name":"@s","objective":"br_entity_deaths"}}]
execute if entity @s[tag=br_hunted] run tellraw @s {"text":"player state: HUNTED","color":"red"}
execute unless entity @s[tag=br_hunted] run tellraw @s {"text":"player state: idle","color":"green"}

tellraw @s [{"text":"entity kb/slide/slide_t: ","color":"gray"},{"score":{"name":"@e[type=minecraft:marker,tag=br_entity_attack,limit=1,sort=nearest]","objective":"br_entity_kb"},"color":"yellow"},{"text":"/","color":"gray"},{"score":{"name":"@e[type=minecraft:marker,tag=br_entity_attack,limit=1,sort=nearest]","objective":"br_entity_slide"},"color":"yellow"},{"text":"/","color":"gray"},{"score":{"name":"@e[type=minecraft:marker,tag=br_entity_attack,limit=1,sort=nearest]","objective":"br_entity_slide_t"},"color":"yellow"}]

scoreboard players set #br_hunted_count br_tmp 0
execute as @a[tag=br_hunted] run scoreboard players add #br_hunted_count br_tmp 1
tellraw @s [{"text":"latent hunted players / active entity present: ","color":"gray"},{"score":{"name":"#br_hunted_count","objective":"br_tmp"}},{"text":"/"},{"score":{"name":"#br_entity_present","objective":"br_tmp"}}]

execute if entity @s run tellraw @s [{"text":"natural threshold / entity_cd: ","color":"gray"},{"score":{"name":"@s","objective":"br_attack_after"}},{"text":" / "},{"score":{"name":"@s","objective":"br_entity_cd"}}]
