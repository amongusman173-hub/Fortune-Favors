# Draw one hitbox/contact debug pulse around current active entity markers.
execute in backrooms:backrooms as @e[type=minecraft:marker,tag=br_entity_attack] at @s run function backrooms:entity/debug/hitbox_particles_tick
