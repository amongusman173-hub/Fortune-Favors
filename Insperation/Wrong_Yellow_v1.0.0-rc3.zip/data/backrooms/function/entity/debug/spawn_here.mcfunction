# Debug subliminal spawn on the brown carpet occupied by the executing player.
# For a deterministic hostile/chase smoke test, use:
# /function backrooms:entity/debug/spawn_attack_here
execute unless entity @s run tellraw @a {"text":"[WY entity] Run this function as a player.","color":"red"}
execute unless entity @s run return 0
execute unless predicate backrooms:in_backrooms run tellraw @s {"text":"[WY entity] This debug spawn is Backrooms-only.","color":"red"}
execute unless predicate backrooms:in_backrooms run return 0
execute if entity @s[gamemode=creative] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=creative] run return 0
execute if entity @s[gamemode=spectator] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=spectator] run return 0

# Remember whether this command itself created the hunt state, so a failed debug attempt can clean up safely.
tag @s remove br_debug_spawn_new_hunt
execute unless entity @s[tag=br_hunted] run tag @s add br_debug_spawn_new_hunt
tag @s add br_hunted
tag @s add br_debug_fast
scoreboard players set @s br_sight_count 0
scoreboard players set @s br_attack_after 3
scoreboard players set @s br_tmp 0

# A player standing on carpet has feet roughly 1/16 block above the carpet block.
# Checking at -0.01 reaches the carpet itself; the old -0.1 check fell through into the block below it.
execute positioned ~ ~-0.01 ~ if block ~ ~ ~ minecraft:brown_carpet if block ~ ~1 ~ #backrooms:entity_spawn_clear if block ~ ~2 ~ #backrooms:entity_spawn_clear run function backrooms:entity/spawn_subliminal_here
# Defensive fallback for unusual player poses/precision at a block boundary.
execute if score @s br_tmp matches 0 positioned ~ ~-1.01 ~ if block ~ ~ ~ minecraft:brown_carpet if block ~ ~1 ~ #backrooms:entity_spawn_clear if block ~ ~2 ~ #backrooms:entity_spawn_clear run function backrooms:entity/spawn_subliminal_here

execute if score @s br_tmp matches 1 run scoreboard players set @s br_timer 999999
execute if score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] Subliminal marker + mannequin spawned here. For an immediate hostile test, run /function backrooms:entity/debug/spawn_attack_here","color":"green"}
execute unless score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] No valid brown_carpet at your feet.","color":"red"}

# Do not leave a fake hunt armed when this isolated debug spawn failed.
execute unless score @s br_tmp matches 1 if entity @s[tag=br_debug_spawn_new_hunt] run tag @s remove br_hunted
execute unless score @s br_tmp matches 1 run tag @s remove br_debug_fast
tag @s remove br_debug_spawn_new_hunt
