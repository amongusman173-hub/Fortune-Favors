# Visual-only smoke test.
# Spawns one mannequin at the command runner and applies the same random server-wide appearance logic used by real entities.
execute unless entity @s run tellraw @a {"text":"[WY entity] Run this function as a player.","color":"red"}
execute unless entity @s run return 0
execute at @s run function backrooms:entity/attach_visual_here
execute if entity @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1,sort=nearest] run tellraw @s {"text":"[WY entity] Random visual mannequin spawned here. It will be cleaned by normal entity cleanup or /function backrooms:entity/hide_all_global.","color":"green"}
execute unless entity @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1,sort=nearest] run tellraw @s {"text":"[WY entity] Visual spawn failed; no source profile or mannequin could be created.","color":"red"}
