# Disable visible hitbox/contact particles.
scoreboard players set #br_entity_hitbox_debug br_tmp 0
tellraw @s {"text":"[WY entity] Hitbox/contact debug particles disabled.","color":"yellow"}
