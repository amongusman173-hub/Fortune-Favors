# Debug-only particles for marker/contact vs mannequin visual alignment.
# Executed as/at the attack marker. Normal runtime cost is zero unless the
# #br_entity_hitbox_debug flag is enabled or show_hitbox_once is called manually.
# Low ring: actual marker/contact centre on carpet.
particle minecraft:crit ~ ~0.08 ~ 0.55 0.02 0.55 0 16 force @a[distance=..96]
# Body column: approximate player-contact volume used by the explicit distance check.
particle minecraft:end_rod ~ ~0.75 ~ 0.18 0.70 0.18 0.01 8 force @a[distance=..96]
# Visual mannequin position, to compare appearance and functional marker.
execute as @e[type=minecraft:mannequin,tag=br_entity_visual,distance=..6,limit=1,sort=nearest] at @s run particle minecraft:happy_villager ~ ~1.0 ~ 0.25 0.80 0.25 0 5 force @a[distance=..96]
# Strikeable interaction hitbox position.
execute as @e[type=minecraft:interaction,tag=br_entity_hitbox,distance=..6,limit=1,sort=nearest] at @s run particle minecraft:poof ~ ~1.0 ~ 0.30 0.90 0.30 0 6 force @a[distance=..96]
