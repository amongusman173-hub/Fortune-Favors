# deterministic active-entity fixture.
# Purpose: prove and profile the active scripted entity path without relying on
# random brown_carpet spot selection. Run as a Survival/Adventure player in a
# wide Backrooms room, looking toward an open carpeted lane.
execute unless entity @s run tellraw @a {"text":"[WY entity] Run this function as a player.","color":"red"}
execute unless entity @s run return 0
execute unless predicate backrooms:in_backrooms run tellraw @s {"text":"[WY entity] This forced chase fixture is Backrooms-only.","color":"red"}
execute unless predicate backrooms:in_backrooms run return 0
execute if entity @s[gamemode=creative] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=creative] run return 0
execute if entity @s[gamemode=spectator] run tellraw @s {"text":"[WY entity] Switch out of Creative/Spectator for a targetable debug test.","color":"yellow"}
execute if entity @s[gamemode=spectator] run return 0

# Clean nearby old debug/runtime manifestations so the fixture starts from a known state.
function backrooms:entity/hide_all_nearby

tag @s add br_hunted
tag @s add br_debug_fast
scoreboard players set @s br_seen 0
scoreboard players set @s br_sight_count 99
scoreboard players set @s br_attack_after 1
scoreboard players set @s br_timer 999999
# Avoid killing the tester during the perf fixture. This counts down at 20 Hz.
scoreboard players set @s br_entity_hit_cd 999
scoreboard players set @s br_tmp 0

# Try deterministic positions in front of the player first, then slightly left/right.
# rotated ~ 0 ignores pitch so looking down does not push the fixture into the floor.
execute if score @s br_tmp matches 0 at @s rotated ~ 0 positioned ^ ^ ^12 run function backrooms:entity/debug/force_visible_chase_at_position
execute if score @s br_tmp matches 0 at @s rotated ~ 0 positioned ^ ^ ^10 run function backrooms:entity/debug/force_visible_chase_at_position
execute if score @s br_tmp matches 0 at @s rotated ~ 0 positioned ^ ^ ^8 run function backrooms:entity/debug/force_visible_chase_at_position
execute if score @s br_tmp matches 0 at @s rotated ~ 0 positioned ^4 ^ ^10 run function backrooms:entity/debug/force_visible_chase_at_position
execute if score @s br_tmp matches 0 at @s rotated ~ 0 positioned ^-4 ^ ^10 run function backrooms:entity/debug/force_visible_chase_at_position

execute if score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] Forced visible chase fixture spawned. Start Spark now; cleanup with /function backrooms:admin/perf/disable_entity.","color":"green"}
execute unless score @s br_tmp matches 1 run tellraw @s {"text":"[WY entity] Fixture failed: no valid brown_carpet + 2-block air lane found in front/near you. Use a wider carpeted room and look down an open lane.","color":"red"}
execute unless score @s br_tmp matches 1 run tag @s remove br_hunted
execute unless score @s br_tmp matches 1 run tag @s remove br_debug_fast
