# Switch to attack mode. V15c: V11 behavior in the Overworld, anti-pathfinding inside the Backrooms.
execute if predicate backrooms:in_backrooms run function backrooms:entity/attack_backrooms
execute unless predicate backrooms:in_backrooms run function backrooms:entity/attack_overworld
