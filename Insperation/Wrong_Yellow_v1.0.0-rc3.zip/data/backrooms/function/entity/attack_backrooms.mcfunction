# Backrooms attack uses a mobile hostile like the Overworld, with normal damage and pathfinding 8.
# Important: do not convert a distant subliminal appearance, because follow_range 8 would leave it immobile.
# Hide the subliminal marker, then respawn a hostile marker on brown_carpet within pathfinding range.
function backrooms:entity/hide_all_nearby
scoreboard players set @s br_seen 0
scoreboard players set @s br_timer 999999
function backrooms:entity/spawn_backrooms_hostile
