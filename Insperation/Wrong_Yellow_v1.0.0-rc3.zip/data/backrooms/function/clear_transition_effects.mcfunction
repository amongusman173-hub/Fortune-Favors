# Clear only the transition effects used by portal/roof sequences.
effect clear @s minecraft:slowness
effect clear @s minecraft:darkness
effect clear @s minecraft:levitation
