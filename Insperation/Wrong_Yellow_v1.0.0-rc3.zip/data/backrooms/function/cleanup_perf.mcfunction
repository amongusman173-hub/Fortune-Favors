# Stable V15c cleanup.
kill @e[tag=br_bug_anchor]
kill @e[tag=br_bug_core]
kill @e[tag=br_bug_visual]
kill @e[tag=br_bug_hit]
function backrooms:entity/hide_all_global
tag @a remove br_hunted
tag @a remove br_natural_hunt
tag @a remove br_fake_dying
tag @a remove br_in_bug
scoreboard players set @a br_timer 0
scoreboard players set @a br_seen 0
scoreboard players set @a br_sight_count 0
scoreboard players set @a br_attack_after 0
scoreboard players set @a br_bug_touch 0
scoreboard players set @a br_sound_cut 0
tag @a remove br_sound_anvil_cut
stopsound @a master minecraft:block.anvil.use
stopsound @a master minecraft:item.elytra.flying
stopsound @a hostile minecraft:item.elytra.flying
tag @a remove br_cw_elytra_a
tag @a remove br_cw_elytra_b
execute store result score @e[tag=br_bug_core] br_bug_blink run random value 60..200
scoreboard players set @a br_life 0
scoreboard players set @a br_ai_step 0
scoreboard players set @a br_ai_stuck 0
effect clear @a minecraft:slowness
effect clear @a minecraft:darkness
effect clear @a minecraft:resistance

tag @a remove br_debug_fast
