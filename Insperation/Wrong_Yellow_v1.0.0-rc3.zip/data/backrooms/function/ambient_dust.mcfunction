# Backrooms white ash ambience.
# restored original yellow biome dimension ambience values.
execute as @a at @s if biome ~ ~ ~ backrooms:yellow run particle minecraft:white_ash ~ ~2.2 ~ 6 6 6 6 5 normal @s
